"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { BookOpen, ChevronDown, Globe, Home, Menu, Moon, Search, Sun, Users, X, User, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { useTheme } from "@/components/theme-provider"
import { useAuth } from "@/lib/AuthContext" 
import { logOut } from "@/lib/firebase"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export function MainNav() {
  const pathname = usePathname()
  const { theme, setTheme } = useTheme()
  const { user, loading } = useAuth()
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [isCoursesOpen, setIsCoursesOpen] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    setMounted(true)
  }, [])

  const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/courses", label: "Courses", icon: BookOpen, hasDropdown: true },
    { href: "/about", label: "About", icon: Users },
    { href: "/accessibility", label: "Accessibility", icon: Globe },
  ]

  const courseCategories = [
    "Web Development",
    "Data Science",
    "UI/UX Design",
    "Mobile Development",
    "Business",
    "Marketing",
  ]

  // Add dashboard link if user is logged in
  const getNavItems = () => {
    if (user) {
      return [
        ...navItems,
        { 
          href: "/dashboard", 
          label: "Dashboard", 
          icon: (props: any) => (
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="24" 
              height="24" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              {...props}
            >
              <rect width="7" height="9" x="3" y="3" rx="1" />
              <rect width="7" height="5" x="14" y="3" rx="1" />
              <rect width="7" height="9" x="14" y="12" rx="1" />
              <rect width="7" height="5" x="3" y="16" rx="1" />
            </svg>
          )
        }
      ];
    }
    return navItems;
  };

  return (
    <header
      className={`fixed left-0 right-0 top-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-white/90 shadow-sm backdrop-blur-md dark:bg-gray-950/90" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="mr-2 flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-white"
            >
              <BookOpen className="h-4 w-4" />
            </motion.div>
            <motion.span
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
              className="text-xl font-bold"
            >
              EduFree
            </motion.span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex md:items-center md:space-x-1">
            {getNavItems().map((item) => (
              <div key={item.href} className="relative">
                {item.hasDropdown ? (
                  <div>
                    <button
                      className={`group flex items-center rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-gray-100 dark:hover:bg-gray-800 ${
                        pathname === item.href ? "text-blue-600 dark:text-blue-400" : "text-gray-700 dark:text-gray-300"
                      }`}
                      onClick={() => setIsCoursesOpen(!isCoursesOpen)}
                      aria-expanded={isCoursesOpen}
                      aria-controls="courses-dropdown"
                    >
                      <item.icon className="mr-2 h-4 w-4" />
                      {item.label}
                      <ChevronDown
                        className={`ml-1 h-4 w-4 transition-transform ${isCoursesOpen ? "rotate-180" : ""}`}
                      />
                    </button>
                    <AnimatePresence>
                      {isCoursesOpen && (
                        <motion.div
                          id="courses-dropdown"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 10 }}
                          transition={{ duration: 0.2 }}
                          className="absolute left-0 top-full z-50 mt-1 w-56 rounded-md border border-gray-200 bg-white p-2 shadow-lg dark:border-gray-700 dark:bg-gray-800"
                          onMouseLeave={() => setIsCoursesOpen(false)}
                        >
                          <div className="py-1">
                            <Link
                              href="/courses"
                              className="block rounded-md px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                            >
                              All Courses
                            </Link>
                          </div>
                          <div className="border-t border-gray-100 py-1 dark:border-gray-700">
                            <p className="px-3 py-1 text-xs font-semibold uppercase text-gray-500 dark:text-gray-400">
                              Categories
                            </p>
                            {courseCategories.map((category) => (
                              <Link
                                key={category}
                                href={`/categories/${category.toLowerCase().replace(/\s+/g, "-")}`}
                                className="block rounded-md px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
                              >
                                {category}
                              </Link>
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ) : (
                  <Link
                    href={item.href}
                    className={`flex items-center rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-gray-100 dark:hover:bg-gray-800 ${
                      pathname === item.href ? "text-blue-600 dark:text-blue-400" : "text-gray-700 dark:text-gray-300"
                    }`}
                  >
                    <item.icon className="mr-2 h-4 w-4" />
                    {item.label}
                  </Link>
                )}
              </div>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden items-center space-x-2 md:flex">
            <div className="relative">
              <AnimatePresence>
                {isSearchOpen ? (
                  <motion.div
                    initial={{ width: 0, opacity: 0 }}
                    animate={{ width: 250, opacity: 1 }}
                    exit={{ width: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="relative"
                  >
                    <Input
                      type="search"
                      placeholder="Search courses..."
                      className="pr-8"
                      autoFocus
                      onBlur={() => setIsSearchOpen(false)}
                    />
                    <button
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400"
                      onClick={() => setIsSearchOpen(false)}
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </motion.div>
                ) : (
                  <motion.button
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex h-9 w-9 items-center justify-center rounded-md text-gray-700 transition-colors hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800"
                    onClick={() => setIsSearchOpen(true)}
                    aria-label="Search courses"
                  >
                    <Search className="h-5 w-5" />
                  </motion.button>
                )}
              </AnimatePresence>
            </div>
            <div>
              <button
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="flex h-9 w-9 items-center justify-center rounded-md text-gray-700 transition-colors hover:bg-accent hover:text-accent-foreground dark:text-gray-200"
                aria-label={mounted ? (theme === "dark" ? "Switch to light mode" : "Switch to dark mode") : "Toggle theme"}
              >
                {mounted ? (
                  theme === "dark" ? (
                    <Sun className="h-5 w-5" />
                  ) : (
                    <Moon className="h-5 w-5" />
                  )
                ) : (
                  <div className="h-5 w-5" />
                )}
              </button>
            </div>
            
            {!loading && (
              <>
                {user ? (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="gap-2">
                        {user.photoURL ? (
                          <img src={user.photoURL} alt="Profile" className="h-6 w-6 rounded-full" />
                        ) : (
                          <User className="h-4 w-4" />
                        )}
                        <span className="hidden sm:inline">{user.displayName?.split(' ')[0] || 'Account'}</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem asChild>
                        <Link href="/dashboard">Dashboard</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/profile">Profile</Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem asChild>
                        <Link href="/courses">My Courses</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/dashboard?tab=certificates">Certificates</Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={async () => {
                          await logOut();
                          window.location.href = '/login';
                        }}
                        className="text-red-600 dark:text-red-400"
                      >
                        <LogOut className="mr-2 h-4 w-4" />
                        Log Out
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <>
                    <Button asChild size="sm">
                      <Link href="/login">Log In</Link>
                    </Button>
                    <Button asChild variant="outline" size="sm">
                      <Link href="/signup">Sign Up</Link>
                    </Button>
                  </>
                )}
              </>
            )}
          </div>

          {/* Mobile Menu */}
          <div className="flex items-center md:hidden">
            <button
              className="mr-2 flex h-9 w-9 items-center justify-center rounded-md text-gray-700 transition-colors hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              aria-label={mounted ? (theme === "dark" ? "Switch to light mode" : "Switch to dark mode") : "Toggle theme"}
            >
              {mounted ? (
                theme === "dark" ? (
                  <Sun className="h-5 w-5" />
                ) : (
                  <Moon className="h-5 w-5" />
                )
              ) : (
                <div className="h-5 w-5" />
              )}
            </button>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Open menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <SheetHeader>
                  <SheetTitle>EduFree Menu</SheetTitle>
                </SheetHeader>
                <div className="flex flex-col space-y-4 py-4">
                  <div className="mb-4">
                    <Input type="search" placeholder="Search courses..." />
                  </div>
                  <nav className="flex flex-col space-y-1">
                    {getNavItems().map((item) => (
                      <Link
                        key={item.href}
                        href={item.href}
                        className={`flex items-center rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-gray-100 dark:hover:bg-gray-800 ${
                          pathname === item.href
                            ? "text-blue-600 dark:text-blue-400"
                            : "text-gray-700 dark:text-gray-300"
                        }`}
                      >
                        <item.icon className="mr-2 h-5 w-5" />
                        {item.label}
                      </Link>
                    ))}
                  </nav>
                  <div className="border-t border-gray-100 pt-4 dark:border-gray-800">
                    <p className="mb-2 px-3 text-xs font-semibold uppercase text-gray-500 dark:text-gray-400">
                      Categories
                    </p>
                    <div className="flex flex-col space-y-1">
                      {courseCategories.map((category) => (
                        <Link
                          key={category}
                          href={`/categories/${category.toLowerCase().replace(/\s+/g, "-")}`}
                          className="rounded-md px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800"
                        >
                          {category}
                        </Link>
                      ))}
                    </div>
                  </div>
                  <div className="border-t border-gray-100 pt-4 dark:border-gray-800">
                    <div className="grid grid-cols-2 gap-2">
                      {!loading && (
                        <>
                          {user ? (
                            <>
                              <Button asChild>
                                <Link href="/dashboard">
                                  <svg 
                                    xmlns="http://www.w3.org/2000/svg" 
                                    width="24" 
                                    height="24" 
                                    viewBox="0 0 24 24" 
                                    fill="none" 
                                    stroke="currentColor" 
                                    strokeWidth="2" 
                                    strokeLinecap="round" 
                                    strokeLinejoin="round" 
                                    className="mr-2 h-4 w-4"
                                  >
                                    <rect width="7" height="9" x="3" y="3" rx="1" />
                                    <rect width="7" height="5" x="14" y="3" rx="1" />
                                    <rect width="7" height="9" x="14" y="12" rx="1" />
                                    <rect width="7" height="5" x="3" y="16" rx="1" />
                                  </svg>
                                  Dashboard
                                </Link>
                              </Button>
                              <Button 
                                variant="outline" 
                                className="text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
                                onClick={async () => {
                                  await logOut();
                                  window.location.href = '/login';
                                }}
                              >
                                <LogOut className="mr-2 h-4 w-4" />
                                Log Out
                              </Button>
                            </>
                          ) : (
                            <>
                              <Button asChild>
                                <Link href="/login">Log In</Link>
                              </Button>
                              <Button asChild variant="outline">
                                <Link href="/signup">Sign Up</Link>
                              </Button>
                            </>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  )
}
