"use client";

import { useState, useCallback, useRef } from "react";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { LoaderCircle, Upload, User2, X } from "lucide-react";
import { uploadProfileImage } from "@/lib/cloudinary";
import { useToast } from "@/components/ui/use-toast";

interface ProfileImageUploadProps {
  userId: string;
  currentImageUrl?: string;
  onImageUploaded: (imageUrl: string, publicId: string) => void;
  className?: string;
}

export function ProfileImageUpload({ 
  userId, 
  currentImageUrl, 
  onImageUploaded,
  className 
}: ProfileImageUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [previewUrl, setPreviewUrl] = useState<string | undefined>(currentImageUrl);
  const { toast } = useToast();
  
  // Keep track of file object URLs to prevent memory leaks
  const fileObjUrlRef = useRef<string | null>(null);
  
  // Cleanup function for object URL
  const cleanupPreview = useCallback(() => {
    if (fileObjUrlRef.current) {
      URL.revokeObjectURL(fileObjUrlRef.current);
      fileObjUrlRef.current = null;
    }
  }, []);
  
  // Handle file drops
  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;
    
    const file = acceptedFiles[0];
    
    // Validate file type
    if (!file.type.match(/image\/(jpeg|jpg|png|gif|webp)/i)) {
      toast({
        title: "Invalid file type",
        description: "Please upload an image file (JPEG, PNG, GIF, WebP)",
        variant: "destructive"
      });
      return;
    }
    
    // Validate file size
    if (file.size > 5 * 1024 * 1024) { // 5MB
      toast({
        title: "File too large",
        description: "Image must be less than 5MB",
        variant: "destructive"
      });
      return;
    }
    
    // Create a preview
    cleanupPreview();
    const objectUrl = URL.createObjectURL(file);
    fileObjUrlRef.current = objectUrl;
    setPreviewUrl(objectUrl);
    
    // Upload the image
    try {
      setIsUploading(true);
      setUploadProgress(0);
      
      const result = await uploadProfileImage(
        file,
        userId,
        (progress) => setUploadProgress(progress)
      );
      
      onImageUploaded(result.secure_url, result.public_id);
      
      toast({
        title: "Profile image updated",
        description: "Your profile image has been successfully updated",
      });
    } catch (error) {
      console.error("Error uploading profile image:", error);
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload image",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  }, [userId, onImageUploaded, cleanupPreview, toast]);
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif', '.webp']
    },
    maxFiles: 1,
    disabled: isUploading
  });
  
  // Delete/reset the image
  const handleRemoveImage = () => {
    cleanupPreview();
    setPreviewUrl(undefined);
    // Call the callback with empty values to clear the image
    onImageUploaded('', '');
  };
  
  return (
    <div className={className}>
      <div className="flex flex-col items-center gap-4">
        {/* Avatar display */}
        <Avatar className="w-32 h-32 border-2 border-border relative group">
          <AvatarImage src={previewUrl} />
          <AvatarFallback className="bg-muted">
            <User2 className="w-12 h-12 text-muted-foreground" />
          </AvatarFallback>
          
          {/* Remove button overlay */}
          {previewUrl && !isUploading && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleRemoveImage();
              }}
              className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white rounded-full"
            >
              <X className="w-8 h-8" />
            </button>
          )}
          
          {/* Upload indicator */}
          {isUploading && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white rounded-full">
              <LoaderCircle className="w-8 h-8 animate-spin" />
            </div>
          )}
        </Avatar>
        
        {/* Progress bar for upload */}
        {isUploading && (
          <div className="w-full max-w-xs">
            <Progress value={uploadProgress} className="h-2" />
            <p className="text-xs text-center mt-1">{uploadProgress}%</p>
          </div>
        )}
        
        {/* Upload button/dropzone */}
        <div className="flex gap-2">
          <div
            {...getRootProps()}
            className={`
              cursor-pointer border-2 border-dashed rounded-md p-2 px-3
              transition-colors text-sm
              ${isDragActive 
                ? 'border-primary bg-primary/10' 
                : 'border-border hover:border-primary/50'}
              ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}
            `}
          >
            <input {...getInputProps()} />
            <div className="flex items-center gap-2">
              <Upload className="w-4 h-4" />
              <span>{isDragActive ? 'Drop image here' : 'Upload image'}</span>
            </div>
          </div>
          
          {previewUrl && (
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleRemoveImage}
              disabled={isUploading}
            >
              <X className="w-4 h-4 mr-1" /> Remove
            </Button>
          )}
        </div>
      </div>
    </div>
  );
} 