"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { BookOpen, Clock, Play, CheckCircle, BookMarked, PenLine } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { getImageUrl } from "@/lib/utils"

interface ContinueLearningProps {
  courseId: string
  courseTitle: string
  courseImage: string
  instructorName: string
  progress: number
  nextLesson: {
    id: string
    title: string
    duration: string
    type: "video" | "reading" | "quiz" | "exercise"
    moduleTitle: string
  }
  onNoteClick?: (courseId: string, courseTitle: string) => void
  onBookmarkClick?: (courseId: string) => void
}

export function ContinueLearning({
  courseId,
  courseTitle,
  courseImage,
  instructorName,
  progress,
  nextLesson,
  onNoteClick,
  onBookmarkClick,
}: ContinueLearningProps) {
  const [imgError, setImgError] = useState(false)
  const [videoUrl, setVideoUrl] = useState<string | null>(null)
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null)
  
  // Determine a category based on course title for image selection
  const getCategoryFromTitle = (title: string): string => {
    const lowerTitle = title.toLowerCase();
    if (lowerTitle.includes('web') || lowerTitle.includes('html') || lowerTitle.includes('css') || 
        lowerTitle.includes('javascript') || lowerTitle.includes('react')) {
      return 'Development';
    } else if (lowerTitle.includes('design') || lowerTitle.includes('ux') || lowerTitle.includes('ui')) {
      return 'Design';
    } else if (lowerTitle.includes('business') || lowerTitle.includes('market')) {
      return 'Business';
    } else if (lowerTitle.includes('photo')) {
      return 'Photography';
    } else if (lowerTitle.includes('data') || lowerTitle.includes('analytics')) {
      return 'Data Science';
    }
    return 'default';
  };
  
  // Convert relative paths to absolute URLs using Pexels images
  const category = getCategoryFromTitle(courseTitle);
  const imageUrl = getImageUrl(courseImage, category);
  const fallbackImageUrl = getImageUrl('course-placeholder.jpg', 'default');

  // Generate topic-specific video URL and thumbnail based on course title and lesson type
  useEffect(() => {
    setVideoUrl(getLessonVideoUrl(courseTitle, nextLesson.title, nextLesson.type))
    setThumbnailUrl(getLessonThumbnail(courseTitle, nextLesson.title, nextLesson.type))
  }, [courseTitle, nextLesson])

  // Function to get lesson thumbnail based on course title and lesson type
  const getLessonThumbnail = (courseTitle: string, lessonTitle: string, type: string): string => {
    // Default thumbnail
    let thumbnail = "/course-placeholder.jpg"
    
    // HTML content
    if (courseTitle.toLowerCase().includes('html') || lessonTitle.toLowerCase().includes('html')) {
      thumbnail = "https://images.unsplash.com/photo-1621839673705-6617adf9e890?q=80&w=1932&auto=format&fit=crop"
    }
    // CSS content
    else if (courseTitle.toLowerCase().includes('css') || lessonTitle.toLowerCase().includes('css')) {
      thumbnail = "https://images.unsplash.com/photo-1523437113738-bbd3cc89fb19?q=80&w=2071&auto=format&fit=crop"
    }
    // JavaScript content
    else if (courseTitle.toLowerCase().includes('javascript') || courseTitle.toLowerCase().includes('js') || 
             lessonTitle.toLowerCase().includes('javascript') || lessonTitle.toLowerCase().includes('js')) {
      thumbnail = "https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?q=80&w=2070&auto=format&fit=crop"
    }
    // React content
    else if (courseTitle.toLowerCase().includes('react') || lessonTitle.toLowerCase().includes('react')) {
      thumbnail = "https://images.unsplash.com/photo-1633356122102-3fe601e05bd2?q=80&w=2070&auto=format&fit=crop"
    }
    // Python content
    else if (courseTitle.toLowerCase().includes('python') || lessonTitle.toLowerCase().includes('python')) {
      thumbnail = "https://images.unsplash.com/photo-1526379879527-8559ecfcaec0?q=80&w=2074&auto=format&fit=crop"
    }
    // Data Science content
    else if (courseTitle.toLowerCase().includes('data') || lessonTitle.toLowerCase().includes('data') || 
             courseTitle.toLowerCase().includes('analytics') || lessonTitle.toLowerCase().includes('analytics')) {
      thumbnail = "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop"
    }
    // UX/UI Design content
    else if (courseTitle.toLowerCase().includes('ux') || courseTitle.toLowerCase().includes('ui') || 
             courseTitle.toLowerCase().includes('design') || lessonTitle.toLowerCase().includes('design')) {
      thumbnail = "https://images.unsplash.com/photo-1561070791-2526d30994b5?q=80&w=2000&auto=format&fit=crop"
    }
    
    return thumbnail
  }

  // Function to get video URL based on course title and lesson type
  const getLessonVideoUrl = (courseTitle: string, lessonTitle: string, type: string): string | null => {
    // Only provide video URLs for video type lessons
    if (type.toLowerCase() !== 'video') return null
    
    // Default video (creative commons)
    let videoUrl = "https://www.youtube.com/embed/aqz-KE-bpKQ"
    
    // HTML content
    if (courseTitle.toLowerCase().includes('html') || lessonTitle.toLowerCase().includes('html')) {
      videoUrl = "https://www.youtube.com/embed/qz0aGYrrlhU"
    }
    // CSS content
    else if (courseTitle.toLowerCase().includes('css') || lessonTitle.toLowerCase().includes('css')) {
      videoUrl = "https://www.youtube.com/embed/yfoY53QXEnI"
    }
    // JavaScript content
    else if (courseTitle.toLowerCase().includes('javascript') || courseTitle.toLowerCase().includes('js') || 
             lessonTitle.toLowerCase().includes('javascript') || lessonTitle.toLowerCase().includes('js')) {
      videoUrl = "https://www.youtube.com/embed/hdI2bqOjy3c"
    }
    // React content
    else if (courseTitle.toLowerCase().includes('react') || lessonTitle.toLowerCase().includes('react')) {
      videoUrl = "https://www.youtube.com/embed/w7ejDZ8SWv8"
    }
    // Python content
    else if (courseTitle.toLowerCase().includes('python') || lessonTitle.toLowerCase().includes('python')) {
      videoUrl = "https://www.youtube.com/embed/_uQrJ0TkZlc"
    }
    // Data Science content
    else if (courseTitle.toLowerCase().includes('data') || lessonTitle.toLowerCase().includes('data') || 
             courseTitle.toLowerCase().includes('analytics') || lessonTitle.toLowerCase().includes('analytics')) {
      videoUrl = "https://www.youtube.com/embed/ua-CiDNNj30"
    }
    // UX/UI Design content
    else if (courseTitle.toLowerCase().includes('ux') || courseTitle.toLowerCase().includes('ui') || 
             courseTitle.toLowerCase().includes('design') || lessonTitle.toLowerCase().includes('design')) {
      videoUrl = "https://www.youtube.com/embed/c9Wg6Cb_YlU"
    }
    
    return videoUrl
  }

  // Get icon based on lesson type
  const getLessonTypeIcon = () => {
    switch (nextLesson.type.toLowerCase()) {
      case 'video':
        return <Play className="h-4 w-4" />
      case 'quiz':
        return <FileQuestion className="h-4 w-4" />
      case 'exercise':
        return <PenLine className="h-4 w-4" />
      case 'reading':
      default:
        return <BookOpen className="h-4 w-4" />
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="w-full"
    >
      <Card className="overflow-hidden border-2 border-blue-100 dark:border-blue-900/30 shadow-md hover:shadow-lg transition-all duration-300">
        <div className="flex flex-col md:flex-row">
          <div className="md:w-2/5 lg:w-1/3 relative">
            {/* Course Image or Video Thumbnail */}
            <div className="relative aspect-video w-full overflow-hidden">
              <Image
                src={imgError ? fallbackImageUrl : (thumbnailUrl || imageUrl)}
                alt={courseTitle}
                width={400}
                height={225}
                className="h-full w-full object-cover transition-transform duration-500 ease-in-out hover:scale-105"
                onError={() => setImgError(true)}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-70 transition-opacity duration-300" />
              
              {/* Play Button Overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <Link href={`/courses/${courseId}`} className="rounded-full bg-white/20 p-3 backdrop-blur-sm hover:bg-white/30 transition-all transform hover:scale-110">
                  <Play className="h-8 w-8 text-white" />
                </Link>
              </div>
              
              {/* Progress Badge */}
              <Badge className="absolute top-3 right-3 bg-blue-600 hover:bg-blue-700">
                {progress}% Complete
              </Badge>
            </div>
          </div>
          
          <div className="flex flex-1 flex-col p-5">
            <CardHeader className="p-0 pb-3">
              <CardTitle className="line-clamp-1 text-xl">{courseTitle}</CardTitle>
              <CardDescription className="flex items-center text-sm">
                <span>By {instructorName}</span>
              </CardDescription>
            </CardHeader>
            
            <CardContent className="p-0 pb-4">
              <div className="mt-2 mb-3">
                <h4 className="text-sm font-medium mb-1">Continue Learning:</h4>
                <div className="flex items-center text-sm">
                  <span className="inline-flex items-center rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-800 dark:bg-blue-900/30 dark:text-blue-300 mr-2">
                    {nextLesson.moduleTitle}
                  </span>
                  <span className="font-medium">{nextLesson.title}</span>
                </div>
              </div>
              
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm font-medium">
                  Progress: {progress}%
                </span>
                <span className="flex items-center text-sm text-muted-foreground">
                  <Clock className="mr-1 h-4 w-4" />
                  <span>{nextLesson.duration}</span>
                </span>
              </div>
              
              <Progress value={progress} className="h-2 mb-4" />
              
              {/* Lesson Type and Info */}
              <div className="flex items-center text-sm text-muted-foreground mb-4">
                <div className="flex items-center mr-4">
                  {getLessonTypeIcon()}
                  <span className="ml-1 capitalize">{nextLesson.type}</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="mr-1 h-4 w-4" />
                  <span>Pick up where you left off</span>
                </div>
              </div>
            </CardContent>
            
            <CardFooter className="p-0 mt-auto flex space-x-2">
              <Button asChild className="flex-1">
                <Link href={`/courses/${courseId}`}>
                  <BookOpen className="mr-2 h-4 w-4" />
                  Continue Learning
                </Link>
              </Button>
              
              {onNoteClick && (
                <Button variant="outline" size="icon" onClick={() => onNoteClick(courseId, courseTitle)}>
                  <PenLine className="h-4 w-4" />
                </Button>
              )}
              
              {onBookmarkClick && (
                <Button variant="outline" size="icon" onClick={() => onBookmarkClick(courseId)}>
                  <BookMarked className="h-4 w-4" />
                </Button>
              )}
            </CardFooter>
          </div>
        </div>
      </Card>
    </motion.div>
  )
}

// Missing component declaration
const FileQuestion = ({ className }: { className?: string }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
      <path d="M10 10.3c.2-.4.5-.8.9-1a2.1 2.1 0 0 1 2.6.4c.3.4.5.8.5 1.3 0 1.3-2 2-2 2" />
      <path d="M12 17h.01" />
    </svg>
  )
}