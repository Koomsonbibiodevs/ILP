"use client"

import { useRef } from "react"
import { Award, Download, Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import html2canvas from "html2canvas"

interface CertificateViewProps {
  id: string
  courseTitle: string
  studentName: string
  issueDate: string
  onClose?: () => void
}

export function CertificateView({
  id,
  courseTitle,
  studentName,
  issueDate,
  onClose
}: CertificateViewProps) {
  const certificateRef = useRef<HTMLDivElement>(null)

  const downloadCertificate = async () => {
    if (certificateRef.current) {
      try {
        const canvas = await html2canvas(certificateRef.current, {
          scale: 2,
          backgroundColor: null,
          logging: false
        })
        
        const image = canvas.toDataURL("image/png")
        const link = document.createElement("a")
        link.href = image
        link.download = `${courseTitle.replace(/\s+/g, '-')}-certificate.png`
        link.click()
      } catch (error) {
        console.error("Error downloading certificate:", error)
      }
    }
  }

  const shareCertificate = () => {
    if (navigator.share) {
      navigator.share({
        title: `${courseTitle} Certificate`,
        text: `I've completed the ${courseTitle} course!`,
        url: window.location.href,
      })
      .catch(error => console.error("Error sharing certificate:", error))
    } else {
      alert("Web Share API not supported in your browser")
    }
  }

  const formattedDate = new Date(issueDate).toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  })

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="relative max-h-[90vh] max-w-4xl overflow-auto rounded-lg bg-white p-6 shadow-xl dark:bg-gray-800">
        <div className="mb-4 flex justify-between">
          <h2 className="text-2xl font-bold">Certificate of Completion</h2>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={downloadCertificate}>
              <Download className="mr-2 h-4 w-4" />
              Download
            </Button>
            <Button variant="outline" size="sm" onClick={shareCertificate}>
              <Share2 className="mr-2 h-4 w-4" />
              Share
            </Button>
            {onClose && (
              <Button variant="ghost" size="sm" onClick={onClose}>
                ✕
              </Button>
            )}
          </div>
        </div>
        
        <div 
          ref={certificateRef} 
          className="border-gradient relative min-h-[500px] w-full min-w-[700px] overflow-hidden rounded-lg border-8 border-double border-blue-100 bg-white p-8 dark:border-blue-900/50 dark:bg-gray-900"
        >
          <div className="absolute inset-0 bg-[url('/placeholder.svg?height=500&width=800')] bg-cover bg-center opacity-5"></div>
          
          <div className="relative z-10 flex flex-col items-center justify-center">
            <div className="mb-6 text-center">
              <div className="text-sm font-medium uppercase tracking-wider text-gray-500 dark:text-gray-400">
                EduFree Learning Platform
              </div>
              <div className="mt-1 h-px w-full bg-gradient-to-r from-transparent via-gray-300 to-transparent dark:via-gray-700"></div>
            </div>
            
            <h1 className="mb-2 text-center text-3xl font-bold uppercase tracking-wide text-blue-600 dark:text-blue-400">
              Certificate of Completion
            </h1>
            
            <div className="mb-6 flex justify-center">
              <Award className="h-16 w-16 text-blue-500 dark:text-blue-400" />
            </div>
            
            <p className="mb-2 text-center text-gray-600 dark:text-gray-300">
              This certificate is awarded to
            </p>
            
            <h2 className="mb-6 text-center text-4xl font-bold">{studentName}</h2>
            
            <p className="mb-2 text-center text-gray-600 dark:text-gray-300">
              for successfully completing the course
            </p>
            
            <h3 className="mb-8 text-center text-2xl font-bold text-blue-600 dark:text-blue-400">
              {courseTitle}
            </h3>
            
            <div className="mb-8 h-px w-3/4 bg-gradient-to-r from-transparent via-gray-300 to-transparent dark:via-gray-700"></div>
            
            <div className="grid w-full grid-cols-2 gap-8">
              <div className="text-center">
                <div className="mb-1 h-px w-full bg-gray-200 dark:bg-gray-700"></div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Course Instructor</p>
              </div>
              
              <div className="text-center">
                <div className="mb-1 h-px w-full bg-gray-200 dark:bg-gray-700"></div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Issue Date: {formattedDate}</p>
              </div>
            </div>
            
            <div className="absolute bottom-4 right-4">
              <div className="rounded-full bg-blue-100 p-2 dark:bg-blue-900/30">
                <div className="h-16 w-16 rounded-full bg-blue-500/10 p-2">
                  <div className="flex h-full w-full items-center justify-center rounded-full bg-blue-600/20 text-xs font-bold text-blue-700 dark:bg-blue-500/20 dark:text-blue-300">
                    VERIFIED
                  </div>
                </div>
              </div>
            </div>
            
            <div className="absolute bottom-4 left-4 text-xs text-gray-400">
              Certificate ID: {id}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
} 