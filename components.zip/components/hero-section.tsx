"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { BookOpen, Rocket, Users, Lightbulb } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function HeroSection() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-blue-50 to-white py-20 dark:from-gray-900 dark:to-gray-950">
      <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_top_right,rgba(59,130,246,0.1),transparent)]" />
      <div className="container relative z-10 mx-auto px-4">
        <motion.div
          className="grid items-center gap-12 md:grid-cols-2"
          initial="hidden"
          animate={isVisible ? "visible" : "hidden"}
          variants={containerVariants}
        >
          <motion.div className="flex flex-col space-y-8" variants={containerVariants}>
            <motion.h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl" variants={itemVariants}>
              <span className="block text-blue-600 dark:text-blue-400">Free Education</span>
              <span className="block">For Everyone</span>
            </motion.h1>
            <motion.p className="max-w-md text-lg text-gray-600 dark:text-gray-300" variants={itemVariants}>
              Access high-quality courses completely free. Learn at your own pace with our accessible platform designed
              for all learners.
            </motion.p>
            <motion.div
              className="flex flex-col space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0"
              variants={itemVariants}
            >
              <Button
                asChild
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800"
              >
                <Link href="/courses">
                  <BookOpen className="mr-2 h-5 w-5" />
                  Explore Courses
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/about">
                  <Users className="mr-2 h-5 w-5" />
                  Join Community
                </Link>
              </Button>
            </motion.div>
          </motion.div>
          <motion.div
            className="relative"
            variants={itemVariants}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
          >
            <div className="relative h-[400px] w-full overflow-hidden rounded-2xl bg-gradient-to-br from-blue-100 to-purple-50 shadow-xl dark:from-blue-900 dark:to-purple-900">
              <motion.div
                className="absolute -right-20 -top-20 h-40 w-40 rounded-full bg-blue-400 opacity-60 blur-3xl"
                animate={{
                  x: [0, 30, 0],
                  y: [0, -30, 0],
                }}
                transition={{
                  repeat: Number.POSITIVE_INFINITY,
                  duration: 8,
                  ease: "easeInOut",
                }}
              />
              <motion.div
                className="absolute -bottom-20 -left-20 h-40 w-40 rounded-full bg-purple-400 opacity-60 blur-3xl"
                animate={{
                  x: [0, -30, 0],
                  y: [0, 30, 0],
                }}
                transition={{
                  repeat: Number.POSITIVE_INFINITY,
                  duration: 8,
                  ease: "easeInOut",
                  delay: 1,
                }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  className="grid grid-cols-2 gap-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5, duration: 0.8 }}
                >
                  {[
                    { icon: BookOpen, label: "100+ Free Courses", color: "bg-white dark:bg-gray-800" },
                    { icon: Rocket, label: "Learn at Your Pace", color: "bg-blue-50 dark:bg-blue-900" },
                    { icon: Users, label: "Supportive Community", color: "bg-purple-50 dark:bg-purple-900" },
                    { icon: Lightbulb, label: "Accessible for All", color: "bg-white dark:bg-gray-800" },
                  ].map((item, index) => (
                    <motion.div
                      key={index}
                      className={`flex flex-col items-center justify-center rounded-lg ${item.color} p-6 shadow-lg`}
                      whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.7 + index * 0.1 }}
                    >
                      <item.icon className="mb-2 h-8 w-8 text-blue-600 dark:text-blue-400" />
                      <p className="text-center text-sm font-medium">{item.label}</p>
                    </motion.div>
                  ))}
                </motion.div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
