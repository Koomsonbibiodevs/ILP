"use client"

import { motion } from "framer-motion"
import { CourseCard } from "@/components/course-card"

// Sample course data
const featuredCourses = [
  {
    id: "web-development",
    title: "Web Development Fundamentals",
    description: "Learn the core concepts of HTML, CSS, and JavaScript to build modern websites from scratch.",
    category: "Development",
    level: "Beginner" as const,
    duration: "8 weeks",
    students: 12500,
    rating: 4.8,
    instructor: {
      id: "sarah-johnson",
      name: "Sarah Johnson",
      title: "Web Development Instructor",
      bio: "Frontend developer with 10+ years of experience",
      image: "/placeholder-user.jpg"
    },
    image: "/course-placeholder.jpg",
  },
  {
    id: "data-science",
    title: "Introduction to Data Science",
    description: "Explore the fundamentals of data analysis, visualization, and machine learning algorithms.",
    category: "Data Science",
    level: "Intermediate" as const,
    duration: "10 weeks",
    students: 8750,
    rating: 4.7,
    instructor: {
      id: "michael-chen",
      name: "Michael Chen",
      title: "Data Science Specialist",
      bio: "Data scientist with expertise in machine learning",
      image: "/placeholder-user.jpg"
    },
    image: "/course-placeholder.jpg",
  },
  {
    id: "ui-design",
    title: "UI/UX Design Principles",
    description: "Master the art of creating beautiful, intuitive user interfaces and experiences.",
    category: "Design",
    level: "Beginner" as const,
    duration: "6 weeks",
    students: 9200,
    rating: 4.9,
    instructor: {
      id: "emma-rodriguez",
      name: "Emma Rodriguez",
      title: "UI/UX Designer",
      bio: "Designer with experience at leading tech companies",
      image: "/placeholder-user.jpg"
    },
    image: "/course-placeholder.jpg",
  },
  {
    id: "mobile-dev",
    title: "Mobile App Development",
    description: "Build cross-platform mobile applications using React Native and modern JavaScript.",
    category: "Development",
    level: "Intermediate" as const,
    duration: "12 weeks",
    students: 7800,
    rating: 4.6,
    instructor: {
      id: "david-kim",
      name: "David Kim",
      title: "Mobile Development Expert",
      bio: "Full-stack developer specializing in mobile apps",
      image: "/placeholder-user.jpg"
    },
    image: "/course-placeholder.jpg",
  },
]

export function FeaturedCourses() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  return (
    <section className="bg-white py-20 dark:bg-gray-950">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-12 text-center"
        >
          <h2 className="mb-2 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Featured <span className="text-blue-600 dark:text-blue-400">Free</span> Courses
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-gray-600 dark:text-gray-300">
            Explore our most popular courses, all completely free and accessible to everyone.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4"
        >
          {featuredCourses.map((course) => (
            <CourseCard key={course.id} {...course} />
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-12 text-center"
        >
          <a
            href="/courses"
            className="inline-flex items-center rounded-full bg-blue-50 px-6 py-3 text-blue-700 transition-colors hover:bg-blue-100 dark:bg-blue-950 dark:text-blue-300 dark:hover:bg-blue-900"
          >
            View all courses
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="ml-2 h-4 w-4"
            >
              <path d="M5 12h14" />
              <path d="m12 5 7 7-7 7" />
            </svg>
          </a>
        </motion.div>
      </div>
    </section>
  )
}
