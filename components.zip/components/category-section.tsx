"use client"

import { motion } from "framer-motion"
import { BookOpen, Code, Database, LineChart, Palette, PenTool, Smartphone, Speaker, Users, Video } from "lucide-react"
import Link from "next/link"

const categories = [
  {
    name: "Web Development",
    icon: Code,
    count: 42,
    color: "bg-blue-50 text-blue-600 dark:bg-blue-950 dark:text-blue-400",
  },
  {
    name: "Data Science",
    icon: Database,
    count: 38,
    color: "bg-purple-50 text-purple-600 dark:bg-purple-950 dark:text-purple-400",
  },
  {
    name: "UI/UX Design",
    icon: Palette,
    count: 24,
    color: "bg-pink-50 text-pink-600 dark:bg-pink-950 dark:text-pink-400",
  },
  {
    name: "Mobile Development",
    icon: Smartphone,
    count: 32,
    color: "bg-orange-50 text-orange-600 dark:bg-orange-950 dark:text-orange-400",
  },
  {
    name: "Business",
    icon: LineChart,
    count: 18,
    color: "bg-green-50 text-green-600 dark:bg-green-950 dark:text-green-400",
  },
  { name: "Marketing", icon: Speaker, count: 26, color: "bg-red-50 text-red-600 dark:bg-red-950 dark:text-red-400" },
  {
    name: "Photography",
    icon: PenTool,
    count: 15,
    color: "bg-yellow-50 text-yellow-600 dark:bg-yellow-950 dark:text-yellow-400",
  },
  {
    name: "Video Production",
    icon: Video,
    count: 22,
    color: "bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400",
  },
  {
    name: "Personal Development",
    icon: Users,
    count: 30,
    color: "bg-teal-50 text-teal-600 dark:bg-teal-950 dark:text-teal-400",
  },
  {
    name: "Education",
    icon: BookOpen,
    count: 28,
    color: "bg-cyan-50 text-cyan-600 dark:bg-cyan-950 dark:text-cyan-400",
  },
]

export function CategorySection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.4 },
    },
  }

  return (
    <section className="bg-gray-50 py-20 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-12 text-center"
        >
          <h2 className="mb-2 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Explore by <span className="text-blue-600 dark:text-blue-400">Category</span>
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-gray-600 dark:text-gray-300">
            Discover free courses across a wide range of subjects and disciplines
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5"
        >
          {categories.map((category, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Link href={`/categories/${category.name.toLowerCase().replace(/\s+/g, "-")}`}>
                <motion.div
                  className={`flex flex-col items-center rounded-xl ${category.color} p-6 text-center transition-all duration-300 hover:shadow-lg`}
                  whileHover={{ y: -5, scale: 1.02 }}
                >
                  <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.2 + index * 0.05, duration: 0.3 }}
                  >
                    <category.icon className="mb-4 h-12 w-12" />
                  </motion.div>
                  <h3 className="mb-1 font-semibold">{category.name}</h3>
                  <p className="text-sm opacity-80">{category.count} courses</p>
                </motion.div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
