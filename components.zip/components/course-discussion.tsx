"use client"

import React, { useState } from "react"
import { MessageSquare, Heart, Send, CheckCircle, HelpCircle, MoreHorizontal, Reply } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

export interface DiscussionComment {
  id: string
  userId: string
  userName: string
  userImage?: string
  content: string
  timestamp: string
  likes: number
  replies: DiscussionComment[]
  isInstructor?: boolean
}

export interface DiscussionThread {
  id: string
  title: string
  userId: string
  userName: string
  userImage?: string
  content: string
  timestamp: string
  comments: DiscussionComment[]
  likes: number
  resolved: boolean
  isInstructor?: boolean
}

interface CourseDiscussionProps {
  courseId: string
  courseTitle: string
  discussions: DiscussionThread[]
  currentUserId: string
  currentUserName: string
  currentUserImage?: string
  isInstructor?: boolean
  onCreateThread: (thread: Omit<DiscussionThread, 'id' | 'timestamp' | 'comments' | 'likes' | 'resolved'>) => void
  onAddComment: (threadId: string, comment: Omit<DiscussionComment, 'id' | 'timestamp' | 'likes' | 'replies'>) => void
  onAddReply: (threadId: string, commentId: string, reply: Omit<DiscussionComment, 'id' | 'timestamp' | 'likes' | 'replies'>) => void
  onLikeThread: (threadId: string) => void
  onLikeComment: (threadId: string, commentId: string) => void
  onResolveThread: (threadId: string) => void
}

// Helper function to format date
function formatDate(dateString: string): string {
  const options: Intl.DateTimeFormatOptions = { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }
  return new Date(dateString).toLocaleDateString(undefined, options)
}

// Helper function to get time since post
function getTimeSince(dateString: string): string {
  const now = new Date()
  const postDate = new Date(dateString)
  const diffInSeconds = Math.floor((now.getTime() - postDate.getTime()) / 1000)
  
  if (diffInSeconds < 60) {
    return `${diffInSeconds} second${diffInSeconds !== 1 ? 's' : ''} ago`
  }
  
  const diffInMinutes = Math.floor(diffInSeconds / 60)
  if (diffInMinutes < 60) {
    return `${diffInMinutes} minute${diffInMinutes !== 1 ? 's' : ''} ago`
  }
  
  const diffInHours = Math.floor(diffInMinutes / 60)
  if (diffInHours < 24) {
    return `${diffInHours} hour${diffInHours !== 1 ? 's' : ''} ago`
  }
  
  const diffInDays = Math.floor(diffInHours / 24)
  if (diffInDays < 30) {
    return `${diffInDays} day${diffInDays !== 1 ? 's' : ''} ago`
  }
  
  const diffInMonths = Math.floor(diffInDays / 30)
  if (diffInMonths < 12) {
    return `${diffInMonths} month${diffInMonths !== 1 ? 's' : ''} ago`
  }
  
  const diffInYears = Math.floor(diffInMonths / 12)
  return `${diffInYears} year${diffInYears !== 1 ? 's' : ''} ago`
}

// Helper function to get user initials for avatar
function getUserInitials(name: string): string {
  const parts = name.split(' ')
  if (parts.length === 1) {
    return parts[0].substring(0, 2).toUpperCase()
  }
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

export function CourseDiscussion({
  courseId,
  courseTitle,
  discussions,
  currentUserId,
  currentUserName,
  currentUserImage,
  isInstructor = false,
  onCreateThread,
  onAddComment,
  onAddReply,
  onLikeThread,
  onLikeComment,
  onResolveThread
}: CourseDiscussionProps) {
  const [newThreadTitle, setNewThreadTitle] = useState("")
  const [newThreadContent, setNewThreadContent] = useState("")
  const [newComments, setNewComments] = useState<{[key: string]: string}>({})
  const [replyingToCommentId, setReplyingToCommentId] = useState<string | null>(null)
  const [newReply, setNewReply] = useState("")
  const [activeTab, setActiveTab] = useState<"all" | "solved" | "unsolved">("all")
  
  const handleNewThreadSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!newThreadTitle.trim() || !newThreadContent.trim()) {
      return
    }
    
    onCreateThread({
      title: newThreadTitle,
      userId: currentUserId,
      userName: currentUserName,
      userImage: currentUserImage,
      content: newThreadContent,
      isInstructor
    })
    
    setNewThreadTitle("")
    setNewThreadContent("")
  }
  
  const handleAddComment = (threadId: string) => {
    const comment = newComments[threadId]
    
    if (!comment || !comment.trim()) {
      return
    }
    
    onAddComment(threadId, {
      userId: currentUserId,
      userName: currentUserName,
      userImage: currentUserImage,
      content: comment,
      isInstructor
    })
    
    setNewComments(prev => ({
      ...prev,
      [threadId]: ""
    }))
  }
  
  const handleAddReply = (threadId: string, commentId: string) => {
    if (!newReply.trim() || !replyingToCommentId) {
      return
    }
    
    onAddReply(threadId, commentId, {
      userId: currentUserId,
      userName: currentUserName,
      userImage: currentUserImage,
      content: newReply,
      isInstructor
    })
    
    setNewReply("")
    setReplyingToCommentId(null)
  }
  
  const filteredDiscussions = discussions.filter(discussion => {
    if (activeTab === "solved") return discussion.resolved
    if (activeTab === "unsolved") return !discussion.resolved
    return true
  })
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Course Discussions</h2>
          <p className="text-muted-foreground">
            {courseId === "all" 
              ? "Ask questions and share insights across all your courses" 
              : `Discussions for ${courseTitle}`}
          </p>
        </div>
      </div>
      
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Start a New Discussion</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleNewThreadSubmit} className="space-y-4">
            <div>
              <Input
                placeholder="Discussion title"
                value={newThreadTitle}
                onChange={(e) => setNewThreadTitle(e.target.value)}
                required
              />
            </div>
            <div>
              <Textarea
                placeholder="What's your question or insight?"
                value={newThreadContent}
                onChange={(e) => setNewThreadContent(e.target.value)}
                rows={4}
                required
              />
            </div>
            <div className="flex justify-end">
              <Button type="submit">
                <MessageSquare className="mr-2 h-4 w-4" />
                Post Discussion
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
      
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "all" | "solved" | "unsolved")}>
        <div className="flex items-center justify-between mb-4">
          <TabsList>
            <TabsTrigger value="all">All Discussions</TabsTrigger>
            <TabsTrigger value="solved">Solved</TabsTrigger>
            <TabsTrigger value="unsolved">Unsolved</TabsTrigger>
          </TabsList>
          
          <p className="text-sm text-muted-foreground">
            {filteredDiscussions.length} discussion{filteredDiscussions.length !== 1 ? 's' : ''}
          </p>
        </div>
        
        <TabsContent value="all" className="space-y-4">
          {filteredDiscussions.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-8">
                <MessageSquare className="mb-2 h-12 w-12 text-muted-foreground" />
                <p className="text-muted-foreground">No discussions yet</p>
                <p className="text-sm text-muted-foreground">Be the first to start a discussion!</p>
              </CardContent>
            </Card>
          ) : (
            filteredDiscussions.map((thread) => (
              <ThreadCard
                key={thread.id}
                thread={thread}
                currentUserId={currentUserId}
                isInstructor={isInstructor}
                newCommentText={newComments[thread.id] || ""}
                replyingToCommentId={replyingToCommentId}
                newReplyText={newReply}
                onCommentTextChange={(text) => {
                  setNewComments(prev => ({
                    ...prev,
                    [thread.id]: text
                  }))
                }}
                onSubmitComment={() => handleAddComment(thread.id)}
                onReplyClick={(commentId) => {
                  setReplyingToCommentId(commentId)
                  setNewReply("")
                }}
                onReplyTextChange={setNewReply}
                onSubmitReply={(commentId) => handleAddReply(thread.id, commentId)}
                onLike={() => onLikeThread(thread.id)}
                onLikeComment={(commentId) => onLikeComment(thread.id, commentId)}
                onResolve={() => onResolveThread(thread.id)}
              />
            ))
          )}
        </TabsContent>
        
        <TabsContent value="solved" className="space-y-4">
          {filteredDiscussions.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-8">
                <CheckCircle className="mb-2 h-12 w-12 text-muted-foreground" />
                <p className="text-muted-foreground">No solved discussions yet</p>
              </CardContent>
            </Card>
          ) : (
            filteredDiscussions.map((thread) => (
              <ThreadCard
                key={thread.id}
                thread={thread}
                currentUserId={currentUserId}
                isInstructor={isInstructor}
                newCommentText={newComments[thread.id] || ""}
                replyingToCommentId={replyingToCommentId}
                newReplyText={newReply}
                onCommentTextChange={(text) => {
                  setNewComments(prev => ({
                    ...prev,
                    [thread.id]: text
                  }))
                }}
                onSubmitComment={() => handleAddComment(thread.id)}
                onReplyClick={(commentId) => {
                  setReplyingToCommentId(commentId)
                  setNewReply("")
                }}
                onReplyTextChange={setNewReply}
                onSubmitReply={(commentId) => handleAddReply(thread.id, commentId)}
                onLike={() => onLikeThread(thread.id)}
                onLikeComment={(commentId) => onLikeComment(thread.id, commentId)}
                onResolve={() => onResolveThread(thread.id)}
              />
            ))
          )}
        </TabsContent>
        
        <TabsContent value="unsolved" className="space-y-4">
          {filteredDiscussions.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-8">
                <HelpCircle className="mb-2 h-12 w-12 text-muted-foreground" />
                <p className="text-muted-foreground">No unsolved discussions</p>
              </CardContent>
            </Card>
          ) : (
            filteredDiscussions.map((thread) => (
              <ThreadCard
                key={thread.id}
                thread={thread}
                currentUserId={currentUserId}
                isInstructor={isInstructor}
                newCommentText={newComments[thread.id] || ""}
                replyingToCommentId={replyingToCommentId}
                newReplyText={newReply}
                onCommentTextChange={(text) => {
                  setNewComments(prev => ({
                    ...prev,
                    [thread.id]: text
                  }))
                }}
                onSubmitComment={() => handleAddComment(thread.id)}
                onReplyClick={(commentId) => {
                  setReplyingToCommentId(commentId)
                  setNewReply("")
                }}
                onReplyTextChange={setNewReply}
                onSubmitReply={(commentId) => handleAddReply(thread.id, commentId)}
                onLike={() => onLikeThread(thread.id)}
                onLikeComment={(commentId) => onLikeComment(thread.id, commentId)}
                onResolve={() => onResolveThread(thread.id)}
              />
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

interface ThreadCardProps {
  thread: DiscussionThread
  currentUserId: string
  isInstructor: boolean
  newCommentText: string
  replyingToCommentId: string | null
  newReplyText: string
  onCommentTextChange: (text: string) => void
  onSubmitComment: () => void
  onReplyClick: (commentId: string) => void
  onReplyTextChange: (text: string) => void
  onSubmitReply: (commentId: string) => void
  onLike: () => void
  onLikeComment: (commentId: string) => void
  onResolve: () => void
}

function ThreadCard({
  thread,
  currentUserId,
  isInstructor,
  newCommentText,
  replyingToCommentId,
  newReplyText,
  onCommentTextChange,
  onSubmitComment,
  onReplyClick,
  onReplyTextChange,
  onSubmitReply,
  onLike,
  onLikeComment,
  onResolve
}: ThreadCardProps) {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="px-6 py-4 flex flex-row items-start justify-between bg-muted/30">
        <div className="flex items-start gap-4">
          <Avatar className="h-10 w-10">
            <AvatarImage src={thread.userImage} alt={thread.userName} />
            <AvatarFallback>{getUserInitials(thread.userName)}</AvatarFallback>
          </Avatar>
          
          <div>
            <div className="flex items-center gap-2">
              <CardTitle className="text-lg font-semibold">{thread.title}</CardTitle>
              {thread.resolved && (
                <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                  <CheckCircle className="mr-1 h-3 w-3" />
                  Solved
                </Badge>
              )}
            </div>
            
            <div className="flex items-center gap-2 mt-1">
              <span className="text-sm font-medium">
                {thread.userName}
                {thread.isInstructor && (
                  <Badge variant="secondary" className="ml-1 text-xs">Instructor</Badge>
                )}
              </span>
              <span className="text-xs text-muted-foreground">
                {getTimeSince(thread.timestamp)}
              </span>
            </div>
          </div>
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {(isInstructor || currentUserId === thread.userId) && !thread.resolved && (
              <DropdownMenuItem onClick={onResolve}>
                Mark as Solved
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      
      <CardContent className="px-6 py-4">
        <p className="whitespace-pre-wrap">{thread.content}</p>
        
        <div className="flex items-center gap-2 mt-4">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onLike}
            className="text-muted-foreground hover:text-foreground"
          >
            <Heart className={`mr-1 h-4 w-4 ${thread.likes > 0 ? "fill-current text-rose-500" : ""}`} />
            {thread.likes > 0 && thread.likes}
          </Button>
        </div>
      </CardContent>
      
      {thread.comments.length > 0 && (
        <>
          <Separator />
          <div className="px-6 py-4">
            <h3 className="text-sm font-medium mb-4">
              {thread.comments.length} {thread.comments.length === 1 ? 'Comment' : 'Comments'}
            </h3>
            
            <div className="space-y-6">
              {thread.comments.map((comment) => (
                <div key={comment.id} className="relative space-y-4">
                  <div className="flex gap-4">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={comment.userImage} alt={comment.userName} />
                      <AvatarFallback>{getUserInitials(comment.userName)}</AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">
                          {comment.userName}
                          {comment.isInstructor && (
                            <Badge variant="secondary" className="ml-1 text-xs">Instructor</Badge>
                          )}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {getTimeSince(comment.timestamp)}
                        </span>
                      </div>
                      
                      <p className="text-sm">{comment.content}</p>
                      
                      <div className="flex items-center gap-4">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => onLikeComment(comment.id)}
                          className="h-auto p-0 text-xs text-muted-foreground hover:text-foreground"
                        >
                          <Heart className={`mr-1 h-3 w-3 ${comment.likes > 0 ? "fill-current text-rose-500" : ""}`} />
                          {comment.likes > 0 && comment.likes}
                        </Button>
                        
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => onReplyClick(comment.id)}
                          className="h-auto p-0 text-xs text-muted-foreground hover:text-foreground"
                        >
                          <Reply className="mr-1 h-3 w-3" />
                          Reply
                        </Button>
                      </div>
                      
                      {replyingToCommentId === comment.id && (
                        <div className="mt-2 flex items-center gap-2">
                          <Textarea
                            value={newReplyText}
                            onChange={(e) => onReplyTextChange(e.target.value)}
                            placeholder="Write a reply..."
                            rows={2}
                            className="flex-1 text-sm"
                          />
                          <Button 
                            size="sm"
                            onClick={() => onSubmitReply(comment.id)}
                            disabled={!newReplyText.trim()}
                          >
                            <Send className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                      
                      {comment.replies.length > 0 && (
                        <div className="pl-4 border-l-2 border-muted mt-4 space-y-4">
                          {comment.replies.map((reply) => (
                            <div key={reply.id} className="flex gap-2">
                              <Avatar className="h-6 w-6">
                                <AvatarImage src={reply.userImage} alt={reply.userName} />
                                <AvatarFallback>{getUserInitials(reply.userName)}</AvatarFallback>
                              </Avatar>
                              
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="text-xs font-medium">
                                    {reply.userName}
                                    {reply.isInstructor && (
                                      <Badge variant="secondary" className="ml-1 text-xs">Instructor</Badge>
                                    )}
                                  </span>
                                  <span className="text-xs text-muted-foreground">
                                    {getTimeSince(reply.timestamp)}
                                  </span>
                                </div>
                                
                                <p className="text-xs mt-1">{reply.content}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
      
      <CardFooter className="p-4 bg-muted/30">
        <div className="flex items-center gap-3 w-full">
          <Avatar className="h-8 w-8">
            <AvatarImage src={currentUserImage} alt={currentUserName} />
            <AvatarFallback>{getUserInitials(currentUserName)}</AvatarFallback>
          </Avatar>
          
          <div className="flex items-center gap-2 flex-1">
            <Textarea
              value={newCommentText}
              onChange={(e) => onCommentTextChange(e.target.value)}
              placeholder="Add a comment..."
              className="flex-1 min-h-[2.5rem] text-sm py-2"
            />
            <Button onClick={onSubmitComment} disabled={!newCommentText.trim()} size="sm">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardFooter>
    </Card>
  )
} 