"use client"

import { motion } from "framer-motion"
import { Accessibility, FileText, Globe, Headphones, Languages, Smartphone } from "lucide-react"

export function AccessibilityFeatures() {
  const features = [
    {
      icon: Accessibility,
      title: "Accessible Design",
      description: "Our platform follows WCAG guidelines to ensure all users can navigate and learn with ease.",
    },
    {
      icon: Headphones,
      title: "Screen Reader Compatible",
      description: "All content is optimized for screen readers and assistive technologies.",
    },
    {
      icon: FileText,
      title: "Transcripts & Captions",
      description: "Video courses include accurate transcripts and closed captions.",
    },
    {
      icon: Languages,
      title: "Multiple Languages",
      description: "Courses available in various languages with translation options.",
    },
    {
      icon: Smartphone,
      title: "Mobile Responsive",
      description: "Learn on any device with our fully responsive design.",
    },
    {
      icon: Globe,
      title: "Offline Access",
      description: "Download courses to learn without internet connection.",
    },
  ]

  return (
    <section className="bg-white py-20 dark:bg-gray-950">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-12 text-center"
        >
          <h2 className="mb-2 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            <span className="text-blue-600 dark:text-blue-400">Accessible</span> Learning for All
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-gray-600 dark:text-gray-300">
            We believe education should be accessible to everyone, regardless of ability or circumstance
          </p>
        </motion.div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="rounded-lg border border-gray-100 bg-white p-6 shadow-sm transition-all duration-300 hover:shadow-md dark:border-gray-800 dark:bg-gray-900"
            >
              <div className="mb-4 inline-flex rounded-full bg-blue-50 p-3 text-blue-600 dark:bg-blue-950 dark:text-blue-400">
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="mb-2 text-xl font-semibold">{feature.title}</h3>
              <p className="text-gray-600 dark:text-gray-400">{feature.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-12 rounded-xl bg-blue-50 p-8 dark:bg-blue-950"
        >
          <div className="mx-auto max-w-3xl text-center">
            <h3 className="mb-4 text-2xl font-bold text-blue-700 dark:text-blue-300">
              Our Commitment to Accessibility
            </h3>
            <p className="mb-6 text-blue-700 dark:text-blue-300">
              We continuously work to improve our platform's accessibility features. If you encounter any barriers or
              have suggestions, please contact our support team.
            </p>
            <button className="rounded-full bg-blue-600 px-6 py-3 font-medium text-white transition-colors hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
              Accessibility Statement
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
