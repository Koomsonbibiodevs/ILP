"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Quote } from "lucide-react"

const testimonials = [
  {
    quote:
      "This platform changed my life. I was able to learn web development completely for free and landed my dream job!",
    name: "Alex Johnson",
    title: "Frontend Developer",
    image: "/placeholder.svg?height=100&width=100&text=AJ",
  },
  {
    quote:
      "As someone with a disability, finding accessible learning resources has always been challenging. This platform is a game-changer.",
    name: "Maria Garcia",
    title: "UX Designer",
    image: "/placeholder.svg?height=100&width=100&text=MG",
  },
  {
    quote:
      "The quality of free courses here rivals expensive bootcamps I've tried. I can't believe all this is available at no cost.",
    name: "David Kim",
    title: "Data Scientist",
    image: "/placeholder.svg?height=100&width=100&text=DK",
  },
  {
    quote:
      "Learning at my own pace without financial pressure has been incredible. The accessibility features make it perfect for everyone.",
    name: "Sarah Patel",
    title: "Software Engineer",
    image: "/placeholder.svg?height=100&width=100&text=SP",
  },
]

export function TestimonialSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
    },
  }

  return (
    <section ref={ref} className="bg-gray-50 py-20 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="mb-12 text-center"
        >
          <h2 className="mb-2 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            What Our <span className="text-blue-600 dark:text-blue-400">Learners</span> Say
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-gray-600 dark:text-gray-300">
            Success stories from our community of free education advocates
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid gap-6 md:grid-cols-2 lg:grid-cols-4"
        >
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
              className="rounded-xl bg-white p-6 shadow-sm transition-all duration-300 dark:bg-gray-800"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300">
                <Quote className="h-6 w-6" />
              </div>
              <p className="mb-6 text-gray-600 dark:text-gray-300">"{testimonial.quote}"</p>
              <div className="flex items-center">
                <div className="mr-4 h-12 w-12 overflow-hidden rounded-full">
                  <img
                    src={testimonial.image || "/placeholder.svg"}
                    alt={testimonial.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{testimonial.title}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
