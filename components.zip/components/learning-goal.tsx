"use client"

import { useState } from "react"
import { Calendar, Check, Edit, Plus, Target, Trash2, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export interface LearningGoal {
  id: string
  title: string
  description: string
  targetDate: string
  progress: number
  category: string
}

interface LearningGoalProps {
  goals: LearningGoal[]
  onAddGoal: (goal: LearningGoal) => void
  onUpdateGoal: (goal: LearningGoal) => void
  onDeleteGoal: (goalId: string) => void
  onUpdateProgress: (goalId: string, progress: number) => void
}

export function LearningGoals({ 
  goals, 
  onAddGoal, 
  onUpdateGoal, 
  onDeleteGoal, 
  onUpdateProgress 
}: LearningGoalProps) {
  const [isAddingGoal, setIsAddingGoal] = useState(false)
  const [isEditingGoal, setIsEditingGoal] = useState(false)
  const [currentGoal, setCurrentGoal] = useState<LearningGoal | null>(null)
  const [isUpdatingProgress, setIsUpdatingProgress] = useState(false)

  const handleAddGoal = () => {
    setCurrentGoal({
      id: `goal-${Date.now()}`,
      title: "",
      description: "",
      targetDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 2 weeks from now
      progress: 0,
      category: "technical"
    })
    setIsAddingGoal(true)
  }

  const handleEditGoal = (goal: LearningGoal) => {
    setCurrentGoal(goal)
    setIsEditingGoal(true)
  }

  const handleUpdateProgress = (goal: LearningGoal) => {
    setCurrentGoal(goal)
    setIsUpdatingProgress(true)
  }

  const handleSaveGoal = () => {
    if (!currentGoal?.title) return

    if (isAddingGoal) {
      onAddGoal(currentGoal)
      setIsAddingGoal(false)
    } else if (isEditingGoal) {
      onUpdateGoal(currentGoal)
      setIsEditingGoal(false)
    }
    
    setCurrentGoal(null)
  }

  const handleSaveProgress = () => {
    if (!currentGoal) return
    
    onUpdateProgress(currentGoal.id, currentGoal.progress)
    setIsUpdatingProgress(false)
    setCurrentGoal(null)
  }

  const categories = {
    "technical": { label: "Technical Skills", color: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300" },
    "soft": { label: "Soft Skills", color: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300" },
    "language": { label: "Language", color: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300" },
    "career": { label: "Career", color: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300" },
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
  }

  const daysRemaining = (dateString: string) => {
    const targetDate = new Date(dateString)
    const today = new Date()
    const timeDiff = targetDate.getTime() - today.getTime()
    const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24))
    
    if (daysDiff < 0) return "Overdue"
    if (daysDiff === 0) return "Due today"
    return `${daysDiff} days left`
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h3 className="text-xl font-semibold">Learning Goals</h3>
        <Button onClick={handleAddGoal} size="sm">
          <Plus className="mr-2 h-4 w-4" />
          Add Goal
        </Button>
      </div>

      {goals.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-10 text-center">
            <Target className="mb-4 h-12 w-12 text-gray-400" />
            <h3 className="mb-2 text-lg font-medium">No learning goals yet</h3>
            <p className="mb-6 max-w-md text-sm text-gray-500 dark:text-gray-400">
              Setting learning goals helps you stay motivated and track your progress.
            </p>
            <Button onClick={handleAddGoal}>
              <Plus className="mr-2 h-4 w-4" />
              Create Your First Goal
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {goals.map((goal) => (
            <Card key={goal.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between">
                  <div className={`rounded-full px-2 py-1 text-xs font-medium ${categories[goal.category as keyof typeof categories]?.color || "bg-gray-100 text-gray-700"}`}>
                    {categories[goal.category as keyof typeof categories]?.label || "General"}
                  </div>
                  <div className="flex space-x-1">
                    <Button variant="ghost" size="icon" onClick={() => handleEditGoal(goal)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => onDeleteGoal(goal.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <CardTitle className="mt-2 line-clamp-1 text-base">{goal.title}</CardTitle>
                <CardDescription className="flex items-center">
                  <Calendar className="mr-1 h-3 w-3" />
                  <span className="text-xs">{formatDate(goal.targetDate)} • {daysRemaining(goal.targetDate)}</span>
                </CardDescription>
              </CardHeader>
              <CardContent className="pb-2">
                <p className="line-clamp-2 text-sm text-gray-600 dark:text-gray-300">{goal.description}</p>
                <div className="mt-4 flex items-center justify-between text-sm">
                  <span className="font-medium">Progress: {goal.progress}%</span>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-7 text-xs"
                    onClick={() => handleUpdateProgress(goal)}
                  >
                    Update
                  </Button>
                </div>
                <Progress value={goal.progress} className="mt-2 h-2" />
              </CardContent>
              <CardFooter className="pt-0">
                {goal.progress === 100 ? (
                  <div className="flex w-full items-center justify-center rounded-md bg-green-100 py-1 text-sm font-medium text-green-700 dark:bg-green-900/20 dark:text-green-300">
                    <Check className="mr-1 h-4 w-4" /> Completed
                  </div>
                ) : goal.progress >= 75 ? (
                  <div className="flex w-full items-center justify-center rounded-md bg-blue-100 py-1 text-sm font-medium text-blue-700 dark:bg-blue-900/20 dark:text-blue-300">
                    Almost there!
                  </div>
                ) : goal.progress >= 25 ? (
                  <div className="flex w-full items-center justify-center rounded-md bg-amber-100 py-1 text-sm font-medium text-amber-700 dark:bg-amber-900/20 dark:text-amber-300">
                    In progress
                  </div>
                ) : (
                  <div className="flex w-full items-center justify-center rounded-md bg-gray-100 py-1 text-sm font-medium text-gray-700 dark:bg-gray-800 dark:text-gray-300">
                    Just started
                  </div>
                )}
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {/* Add Goal Dialog */}
      <Dialog open={isAddingGoal} onOpenChange={setIsAddingGoal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Learning Goal</DialogTitle>
            <DialogDescription>
              Set a specific, measurable goal to enhance your learning journey.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="title">Goal Title</Label>
              <Input
                id="title"
                placeholder="e.g., Master React Hooks"
                value={currentGoal?.title || ""}
                onChange={(e) => setCurrentGoal(prev => prev ? {...prev, title: e.target.value} : null)}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Describe what you want to achieve..."
                value={currentGoal?.description || ""}
                onChange={(e) => setCurrentGoal(prev => prev ? {...prev, description: e.target.value} : null)}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="category">Category</Label>
                <Select 
                  value={currentGoal?.category || "technical"}
                  onValueChange={(value) => setCurrentGoal(prev => prev ? {...prev, category: value} : null)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technical">Technical Skills</SelectItem>
                    <SelectItem value="soft">Soft Skills</SelectItem>
                    <SelectItem value="language">Language</SelectItem>
                    <SelectItem value="career">Career</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="targetDate">Target Date</Label>
                <Input
                  id="targetDate"
                  type="date"
                  value={currentGoal?.targetDate || ""}
                  onChange={(e) => setCurrentGoal(prev => prev ? {...prev, targetDate: e.target.value} : null)}
                />
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddingGoal(false)}>Cancel</Button>
            <Button onClick={handleSaveGoal}>Save Goal</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Goal Dialog */}
      <Dialog open={isEditingGoal} onOpenChange={setIsEditingGoal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Learning Goal</DialogTitle>
            <DialogDescription>
              Update your learning goal details.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-title">Goal Title</Label>
              <Input
                id="edit-title"
                value={currentGoal?.title || ""}
                onChange={(e) => setCurrentGoal(prev => prev ? {...prev, title: e.target.value} : null)}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={currentGoal?.description || ""}
                onChange={(e) => setCurrentGoal(prev => prev ? {...prev, description: e.target.value} : null)}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-category">Category</Label>
                <Select 
                  value={currentGoal?.category || "technical"}
                  onValueChange={(value) => setCurrentGoal(prev => prev ? {...prev, category: value} : null)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technical">Technical Skills</SelectItem>
                    <SelectItem value="soft">Soft Skills</SelectItem>
                    <SelectItem value="language">Language</SelectItem>
                    <SelectItem value="career">Career</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-targetDate">Target Date</Label>
                <Input
                  id="edit-targetDate"
                  type="date"
                  value={currentGoal?.targetDate || ""}
                  onChange={(e) => setCurrentGoal(prev => prev ? {...prev, targetDate: e.target.value} : null)}
                />
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditingGoal(false)}>Cancel</Button>
            <Button onClick={handleSaveGoal}>Update Goal</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Update Progress Dialog */}
      <Dialog open={isUpdatingProgress} onOpenChange={setIsUpdatingProgress}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Goal Progress</DialogTitle>
            <DialogDescription>
              Track your progress toward completing this goal.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <h3 className="mb-2 text-base font-medium">{currentGoal?.title}</h3>
            <p className="mb-6 text-sm text-gray-500 dark:text-gray-400">{currentGoal?.description}</p>
            
            <div className="grid gap-4">
              <Label htmlFor="progress">Current Progress: {currentGoal?.progress || 0}%</Label>
              <Input
                id="progress"
                type="range"
                min="0"
                max="100"
                step="5"
                value={currentGoal?.progress || 0}
                onChange={(e) => setCurrentGoal(prev => prev ? {...prev, progress: parseInt(e.target.value)} : null)}
                className="w-full"
              />
              
              <div className="flex justify-between text-sm">
                <span>0%</span>
                <span>25%</span>
                <span>50%</span>
                <span>75%</span>
                <span>100%</span>
              </div>
              
              <div className="mt-2">
                <Progress value={currentGoal?.progress || 0} className="h-2" />
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsUpdatingProgress(false)}>Cancel</Button>
            <Button onClick={handleSaveProgress}>Save Progress</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
} 