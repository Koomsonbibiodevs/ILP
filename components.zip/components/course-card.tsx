"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { BookOpen, Clock, Star, Users } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { getImageUrl } from "@/lib/utils"

interface CourseCardProps {
  id: string
  title: string
  description: string
  category: string
  level: "Beginner" | "Intermediate" | "Advanced"
  duration: string
  students: number
  rating: number
  instructor: {
    id: string
    name: string
    title: string
    bio: string
    image: string
  }
  image: string
}

export function CourseCard({
  id,
  title,
  description,
  category,
  level,
  duration,
  students,
  rating,
  instructor,
  image,
}: CourseCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [imgError, setImgError] = useState(false)
  
  // Convert relative paths to absolute URLs - use Pexels images based on category
  const imageUrl = getImageUrl(image, category);
  const fallbackImageUrl = getImageUrl('course-placeholder.jpg', 'default');
  
  return (
    <motion.div
      whileHover={{ y: -8 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <Card className="h-full overflow-hidden transition-all duration-300 hover:shadow-lg">
        <div className="relative aspect-video overflow-hidden">
          {/* Handle different image loading scenarios */}
          <Image
            src={imgError ? fallbackImageUrl : imageUrl}
            alt={title}
            width={400}
            height={225}
            className="h-full w-full object-cover transition-transform duration-500 ease-in-out hover:scale-105"
            onError={() => setImgError(true)}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 transition-opacity duration-300 hover:opacity-100" />
          <Badge className="absolute left-3 top-3 bg-blue-600 hover:bg-blue-700">{category}</Badge>
          <Badge className="absolute right-3 top-3" variant="outline">
            {level}
          </Badge>
          <Badge className="absolute left-3 bottom-3 bg-green-600 hover:bg-green-700">FREE</Badge>
        </div>
        <CardHeader>
          <CardTitle className="line-clamp-1 text-xl">{title}</CardTitle>
          <CardDescription className="flex items-center text-sm">
            <span>By {instructor.name}</span>
            <span className="ml-auto flex items-center">
              {Array(5)
                .fill(0)
                .map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${i < Math.floor(rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                  />
                ))}
              <span className="ml-1 text-sm font-medium">{rating.toFixed(1)}</span>
            </span>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="line-clamp-2 text-sm text-gray-500 dark:text-gray-400">{description}</p>
          <div className="mt-4 flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
            <div className="flex items-center">
              <Clock className="mr-1 h-4 w-4" />
              <span>{duration}</span>
            </div>
            <div className="flex items-center">
              <Users className="mr-1 h-4 w-4" />
              <span>{students.toLocaleString()} students</span>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button asChild className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
            <Link href={`/courses/${id}`}>
              <BookOpen className="mr-2 h-4 w-4" />
              Start Learning
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  )
}
