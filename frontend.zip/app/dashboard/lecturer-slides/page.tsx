"use client"

import React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useAuth } from "@/lib/AuthContext"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { FileIcon, DownloadIcon, EyeIcon, SearchIcon, BookOpenIcon } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { toast } from "@/components/ui/use-toast"
import { 
  getAllLectureSlides, 
  incrementSlideViewCount, 
  incrementSlideDownloadCount,
  getProperViewUrl,
  getProperDownloadUrl
} from "@/lib/lecture-slides"
import { Loader2 } from "lucide-react"

// Type definitions
interface LectureSlide {
  id: string;
  courseId: string;
  title: string;
  description: string;
  fileUrl: string;
  fileName: string;
  uploadedBy: string;
  uploadedByName: string;
  createdAt: any;
  tags?: string[];
  downloadCount: number;
  viewCount: number;
  isPdf: boolean;
  storageProvider: string;
}

export default function LecturerSlidesPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);
  const [slides, setSlides] = useState<LectureSlide[]>([]);
  const [iframeError, setIframeError] = useState(false);
  
  useEffect(() => {
    // Redirect if not authenticated
    if (!loading && !user) {
      router.push("/login");
      return;
    }
    
    // Fetch slides data here
    const fetchSlides = async () => {
      try {
        setIsLoading(true);
        // Actually fetch the slides data
        const data = await getAllLectureSlides();
        console.log("Fetched slides:", data);
        setSlides(data);
      } catch (error) {
        console.error("Error fetching slides:", error);
        toast({
          title: "Error",
          description: "Failed to load lecture slides.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    if (user) {
      fetchSlides();
    }
  }, [user, loading, router]);
  
  const [selectedSlide, setSelectedSlide] = useState<LectureSlide | null>(null);
const [isDialogOpen, setIsDialogOpen] = useState(false);

// Reset iframe error state when dialog closes
useEffect(() => {
  if (!isDialogOpen) {
    setIframeError(false);
  }
}, [isDialogOpen]);

const handleViewSlide = async (slide: LectureSlide) => {
  try {
    // Reset iframe error state when opening a new slide
    setIframeError(false);
    
    // Determine if this is a PDF file
    const isPdf = slide.isPdf || slide.fileName.toLowerCase().endsWith('.pdf');
    
    // Update the slide object with isPdf flag if needed
    const slideWithPdfFlag = {
      ...slide,
      isPdf: isPdf
    };
    
    // Get the proper URL for viewing
    const viewUrl = getProperViewUrl(slide.fileUrl, slide.fileName, isPdf);
    console.log('Generated view URL:', viewUrl);
    console.log('File is PDF:', isPdf);
    
    // Set the selected slide first with updated PDF flag
    console.log('Setting selected slide:', slideWithPdfFlag);
    setSelectedSlide(slideWithPdfFlag);
    
    // Use setTimeout to ensure the state is updated before opening the dialog
    setTimeout(() => {
      console.log('Opening dialog for slide:', slide.id);
      setIsDialogOpen(true);
      
      // Update view count after dialog is confirmed open
      incrementSlideViewCount(slide.id)
        .then(() => console.log('View count incremented for slide:', slide.id))
        .catch(err => console.error('Error incrementing view count:', err));
    }, 0);
  } catch (error) {
    console.error("Error viewing slide:", error);
    toast({
      title: "Error",
      description: "Failed to open slide for viewing.",
      variant: "destructive",
    });
  }
};
  
  const handleDownloadSlide = async (slide: LectureSlide) => {
    try {
      console.log('Starting download for slide:', slide.id);
      
      // Determine if this is a PDF file
      const isPdf = slide.isPdf || slide.fileName.toLowerCase().endsWith('.pdf');
      console.log('File is PDF:', isPdf);
      
      // Get the proper URL for downloading
      const downloadUrl = getProperDownloadUrl(slide.fileUrl, slide.fileName, isPdf);
      console.log('Generated download URL:', downloadUrl);
      
      // Create download link with more explicit attributes
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = slide.fileName || (isPdf ? 'slide.pdf' : 'slide');
      a.target = '_blank'; // Open in new tab as fallback
      a.rel = 'noopener noreferrer';
      a.style.display = 'none';
      
      // Append to body, click, and remove
      document.body.appendChild(a);
      console.log('Download link created and appended to body');
      
      // Use setTimeout to ensure the link is properly added to the DOM
      setTimeout(() => {
        console.log('Clicking download link');
        a.click();
        document.body.removeChild(a);
        
        // Update download count after click
        incrementSlideDownloadCount(slide.id)
          .then(() => console.log('Download count incremented for slide:', slide.id))
          .catch(err => console.error('Error incrementing download count:', err));
      }, 100);
      
      // Show success toast
      toast({
        title: "Download Started",
        description: `Downloading ${slide.fileName || (isPdf ? 'PDF slide' : 'slide')}...`,
      });
    } catch (error) {
      console.error("Error downloading slide:", error);
      toast({
        title: "Error",
        description: "Failed to download slide.",
        variant: "destructive",
      });
    }
  };
  
  if (loading || isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <span className="ml-2">Loading slides...</span>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-6">
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl h-[90vh]">
          <DialogHeader>
            <DialogTitle>{selectedSlide?.title}</DialogTitle>
            <DialogDescription>{selectedSlide?.description}</DialogDescription>
          </DialogHeader>
          {selectedSlide && (
            <div className="w-full h-full">
              {selectedSlide.fileUrl.startsWith('blob:') ? (
                <div className="flex flex-col items-center justify-center h-full">
                  <p className="text-center mb-4">This file cannot be viewed directly in the browser.</p>
                  <Button 
                    onClick={() => handleDownloadSlide(selectedSlide)}
                    className="flex items-center"
                  >
                    <DownloadIcon className="h-4 w-4 mr-1" /> Download to View
                  </Button>
                </div>
              ) : (
                <div className="w-full h-full relative">
                  {iframeError ? (
                    <div className="flex flex-col items-center justify-center h-full">
                      <p className="text-center mb-4">Unable to preview this file in the browser.</p>
                      <Button 
                        onClick={() => handleDownloadSlide(selectedSlide)}
                        className="flex items-center"
                      >
                        <DownloadIcon className="h-4 w-4 mr-1" /> Download to View
                      </Button>
                    </div>
                  ) : (
                    <>
                      {selectedSlide.isPdf ? (
                        // Enhanced PDF viewer with better Cloudinary support
                        <div className="w-full h-full flex flex-col">
                          <div className="flex-1 relative">
                            <iframe 
                              src={getProperViewUrl(selectedSlide.fileUrl, selectedSlide.fileName, true)}
                              className="w-full h-full border-0"
                              title={selectedSlide.title}
                              sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-downloads"
                              referrerPolicy="no-referrer"
                              allow="fullscreen"
                              onLoad={(e) => {
                                console.log('PDF iframe loaded');
                              }}
                              onError={() => {
                                console.error('PDF iframe failed to load');
                                setIframeError(true);
                                toast({
                                  title: "Error",
                                  description: "Failed to load the PDF. Please try downloading instead.",
                                  variant: "destructive",
                                });
                              }}
                            />
                          </div>
                          <div className="p-2 flex justify-end">
                            <Button 
                              onClick={() => handleDownloadSlide(selectedSlide)}
                              variant="secondary"
                              className="flex items-center"
                            >
                              <DownloadIcon className="h-4 w-4 mr-1" /> Download PDF
                            </Button>
                          </div>
                        </div>
                      ) : (
                        // Standard iframe for non-PDF content
                        <>
                          <iframe 
                            src={getProperViewUrl(selectedSlide.fileUrl, selectedSlide.fileName, selectedSlide.isPdf)}
                            className="w-full h-full border-0"
                            title={selectedSlide.title}
                            sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-downloads"
                            referrerPolicy="no-referrer"
                            allow="fullscreen"
                            onLoad={(e) => {
                              try {
                                const iframeDoc = (e.target as HTMLIFrameElement).contentDocument;
                                if (!iframeDoc) {
                                  console.log('Cannot access iframe document - likely due to CORS');
                                }
                              } catch (err) {
                                console.error('Iframe access error:', err);
                              }
                            }}
                            onError={() => {
                              console.error('Iframe failed to load');
                              setIframeError(true);
                              toast({
                                title: "Error",
                                description: "Failed to load the content. Please try downloading instead.",
                                variant: "destructive",
                              });
                            }}
                          />
                          <div className="absolute bottom-4 right-4">
                            <Button 
                              onClick={() => handleDownloadSlide(selectedSlide)}
                              variant="secondary"
                              className="flex items-center"
                            >
                              <DownloadIcon className="h-4 w-4 mr-1" /> Download
                            </Button>
                          </div>
                        </>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
      
      <h1 className="text-3xl font-bold">Lecturer Slides</h1>
      <p className="text-gray-600 mb-6">Access lecture slides uploaded by your lecturers</p>
      
      <div className="mb-6 flex justify-between">
        <Button asChild>
          <Link href="/dashboard">Back to Dashboard</Link>
        </Button>
      </div>
      
      {slides.length === 0 ? (
        <div className="text-center p-8 border rounded-md">
          <FileIcon className="mx-auto h-12 w-12 text-gray-400" />
          <h2 className="mt-4 text-lg font-medium">No slides available</h2>
          <p className="mt-2 text-gray-500">Check back later for lecture materials.</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {slides.map((slide) => (
            <Card key={slide.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">{slide.title}</CardTitle>
                <CardDescription>{slide.uploadedByName}</CardDescription>
              </CardHeader>
              
              <CardContent>
                <p className="text-sm text-gray-600 line-clamp-2">{slide.description}</p>
                {slide.tags && slide.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {slide.tags.map((tag, i) => (
                      <Badge key={i} variant="secondary">{tag}</Badge>
                    ))}
                  </div>
                )}
              </CardContent>
              
              <CardFooter className="flex justify-between border-t pt-4">
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <span className="flex items-center">
                    <EyeIcon className="h-4 w-4 mr-1" /> {slide.viewCount}
                  </span>
                </div>
                <div className="flex space-x-2">
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => handleViewSlide(slide)}
                  >
                    View
                  </Button>
                  <Button 
                    size="sm" 
                    onClick={() => handleDownloadSlide(slide)}
                  >
                    <DownloadIcon className="h-4 w-4 mr-1" /> Download
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}