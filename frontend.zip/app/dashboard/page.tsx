"use client"

import { useState, useEffect, Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { useAuth } from "@/lib/AuthContext"
import { 
  BookOpen, Award, Clock, CheckCircle, Calendar, GraduationCap, Book, 
  BarChart3, Star, BookMarked, Lightbulb, PenLine, X, FileText, LucideIcon, Target, MessageSquare, Loader2
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { allCourses, Course } from "@/data/courses"
import { CertificateView } from "@/components/certificate-view"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { LearningGoals, LearningGoal } from "@/components/learning-goal"
import { CourseDiscussion, DiscussionThread, DiscussionComment } from "@/components/course-discussion"
import { 
  getUserData, 
  listenToUserData, 
  saveUserNote,
  deleteUserNote, 
  saveUserBookmark, 
  deleteUserBookmark,
  saveUserGoal,
  deleteUserGoal,
  updateLearningStats,
  updateUserDiscussions
} from "@/lib/firestore"
import { toast } from "@/components/ui/use-toast"

// Interface for course notes
interface CourseNote {
  id: string;
  courseId: string;
  title: string;
  content: string;
  createdAt: string;
}

// Interface for bookmark
interface Bookmark {
  id: string;
  courseId: string;
  lessonId: string;
  moduleTitle: string;
  lessonTitle: string;
  timestamp: string;
  createdAt: string;
}

function DashboardContent() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const tabParam = searchParams.get('tab')
  const [activeTab, setActiveTab] = useState<string>(tabParam === 'certificates' ? 'certificates' : 'courses')
  const [enrolledCourses, setEnrolledCourses] = useState<Course[]>([])
  const [certificates, setCertificates] = useState<{id: string, courseTitle: string, issueDate: string}[]>([])
  const [showCertificate, setShowCertificate] = useState<string | null>(null)
  const [isEditingNote, setIsEditingNote] = useState(false)
  const [currentNote, setCurrentNote] = useState<CourseNote | null>(null)
  const [notes, setNotes] = useState<CourseNote[]>([])
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([])
  const [recommendedCourses, setRecommendedCourses] = useState<Course[]>([])
  const [learningGoals, setLearningGoals] = useState<LearningGoal[]>([])
  const [discussions, setDiscussions] = useState<DiscussionThread[]>([])
  const [courseProgress, setCourseProgress] = useState<{[key: string]: number}>({})
  const [learningStats, setLearningStats] = useState({
    totalTimeSpent: "0h 0m",
    averageSessionLength: "0h 0m",
    completedLessons: 0,
    weeklyActivity: [0, 0, 0, 0, 0, 0, 0],
    weeklyGoal: 10,
    weeklyProgress: 0,
    streakDays: 0,
  })
  const [isLoading, setIsLoading] = useState(true)
  
  // Helper function to get category-specific image IDs
  const getCategoryImage = (category: string): string => {
    const categoryMap: Record<string, string> = {
      'Development': '1587620962725-abab7fe55159',
      'Design': '1561070791-2526d30994b5',
      'Business': '1507679799987-c73779587ccf',
      'Marketing': '1533750516457-a7f992034fec',
      'Photography': '1542038784456-1ea8e935640e',
      'Music': '1511379938547-c1f69419868d',
      'Health': '1505576399279-565b52d4ac71',
      'Data Science': '1551288049-bebda4e38f71',
      'Cybersecurity': '1563013544-824ae1b704d3',
      'Finance': '1565514020179-026bfa9ff9ac',
    };
    
    // Clean up category name and look for matches
    const cleanCategory = category ? category.trim() : '';
    
    if (cleanCategory) {
      // Check for exact match
      if (categoryMap[cleanCategory]) {
        return categoryMap[cleanCategory];
      }
      
      // Check for partial matches
      for (const [key, value] of Object.entries(categoryMap)) {
        if (cleanCategory.toLowerCase().includes(key.toLowerCase()) || 
            key.toLowerCase().includes(cleanCategory.toLowerCase())) {
          return value;
        }
      }
    }
    
    // Default education image
    return '1524995997946-a1c2e315a42f';
  };
  
  // Load user data from Firebase
  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
      return
    } 
    
    if (user) {
      // Set up real-time listener for user data
      const unsubscribe = listenToUserData(user.uid, (userData) => {
        if (userData) {
          // Process enrolled courses
          if (userData.enrolledCourses && Array.isArray(userData.enrolledCourses)) {
      const userEnrolledCourses = allCourses
              .filter(course => userData.enrolledCourses.includes(course.id))
        .map(course => ({...course, enrolled: true}))
      setEnrolledCourses(userEnrolledCourses)
      
            // Recommend courses not enrolled in
      const userRecommended = allCourses
              .filter(course => !userData.enrolledCourses.includes(course.id))
        .slice(0, 3)
      setRecommendedCourses(userRecommended)
          } else {
            // If no enrolledCourses from Firebase, try localStorage
            try {
              const userSpecificKey = `enrolledCourses_${user.uid}`
              const storedEnrolledCourses = localStorage.getItem(userSpecificKey)
              
              if (storedEnrolledCourses) {
                const enrolledCourseIds = JSON.parse(storedEnrolledCourses)
                const userEnrolledCourses = allCourses
                  .filter(course => enrolledCourseIds.includes(course.id))
                  .map(course => ({...course, enrolled: true}))
                setEnrolledCourses(userEnrolledCourses)
                
                // Recommend courses not enrolled in
                const userRecommended = allCourses
                  .filter(course => !enrolledCourseIds.includes(course.id))
                  .slice(0, 3)
                setRecommendedCourses(userRecommended)
              } else {
                setEnrolledCourses([])
                setRecommendedCourses(allCourses.slice(0, 3))
              }
            } catch (err) {
              console.error('Error checking localStorage for enrolled courses:', err)
              setEnrolledCourses([])
              setRecommendedCourses(allCourses.slice(0, 3))
            }
          }
          
          // Process other user data
          setCertificates(userData.certificates || [])
          setNotes(userData.notes || [])
          setBookmarks(userData.bookmarks || [])
          setLearningGoals(userData.learningGoals || [])
          setCourseProgress(userData.courseProgress || {})
          setLearningStats(userData.learningStats || {
            totalTimeSpent: "0h 0m",
            averageSessionLength: "0h 0m",
            completedLessons: 0,
            weeklyActivity: [0, 0, 0, 0, 0, 0, 0],
            weeklyGoal: 10,
            weeklyProgress: 0,
            streakDays: 0,
          })
          setDiscussions(userData.discussions || [])
        } else {
          // Initialize with empty data for new users - also try localStorage first
          try {
            const userSpecificKey = `enrolledCourses_${user.uid}`
            const storedEnrolledCourses = localStorage.getItem(userSpecificKey)
            
            if (storedEnrolledCourses) {
              const enrolledCourseIds = JSON.parse(storedEnrolledCourses)
              const userEnrolledCourses = allCourses
                .filter(course => enrolledCourseIds.includes(course.id))
                .map(course => ({...course, enrolled: true}))
              setEnrolledCourses(userEnrolledCourses)
              
              // Recommend courses not enrolled in
              const userRecommended = allCourses
                .filter(course => !enrolledCourseIds.includes(course.id))
                .slice(0, 3)
              setRecommendedCourses(userRecommended)
            } else {
              setEnrolledCourses([])
              setRecommendedCourses(allCourses.slice(0, 3))
            }
          } catch (err) {
            console.error('Error checking localStorage for enrolled courses:', err)
            setEnrolledCourses([])
            setRecommendedCourses(allCourses.slice(0, 3))
          }
          
          setCertificates([])
          setNotes([])
          setBookmarks([])
          setLearningGoals([])
          setCourseProgress({})
          setLearningStats({
            totalTimeSpent: "0h 0m",
            averageSessionLength: "0h 0m",
            completedLessons: 0,
            weeklyActivity: [0, 0, 0, 0, 0, 0, 0],
            weeklyGoal: 10, 
            weeklyProgress: 0,
            streakDays: 0,
          })
          setDiscussions([])
          
          // Create user data in Firebase
          getUserData(user.uid).catch(err => {
            console.error("Error creating user data in Firebase:", err)
            toast({
              title: "Firebase Error",
              description: "There was an error connecting to the database. Using local storage instead.",
              variant: "destructive"
            })
          })
        }
        
        setIsLoading(false)
      }, (error) => {
        // Handle Firebase permission errors by falling back to localStorage
        console.error("Firebase error:", error)
        
        // Try to get enrolled courses from localStorage
        try {
          const userSpecificKey = `enrolledCourses_${user.uid}`
          const storedEnrolledCourses = localStorage.getItem(userSpecificKey)
          
          if (storedEnrolledCourses) {
            const enrolledCourseIds = JSON.parse(storedEnrolledCourses)
            const userEnrolledCourses = allCourses
              .filter(course => enrolledCourseIds.includes(course.id))
              .map(course => ({...course, enrolled: true}))
            setEnrolledCourses(userEnrolledCourses)
            
            const userRecommended = allCourses
              .filter(course => !enrolledCourseIds.includes(course.id))
              .slice(0, 3)
            setRecommendedCourses(userRecommended)
          } else {
            setEnrolledCourses([])
            setRecommendedCourses(allCourses.slice(0, 3))
          }
        } catch (err) {
          console.error('Error checking localStorage for enrolled courses:', err)
          setEnrolledCourses([])
          setRecommendedCourses(allCourses.slice(0, 3))
        }
        
        // Set default values for other user data
        setCertificates([])
        setNotes([])
        setBookmarks([])
        setLearningGoals([])
        setCourseProgress({})
        setLearningStats({
          totalTimeSpent: "0h 0m",
          averageSessionLength: "0h 0m",
          completedLessons: 0,
          weeklyActivity: [0, 0, 0, 0, 0, 0, 0],
          weeklyGoal: 10,
          weeklyProgress: 0,
          streakDays: 0,
        })
        setDiscussions([])
        
        // Show error toast
        toast({
          title: "Firebase Error",
          description: "There was an error connecting to the database. Using local storage instead.",
          variant: "destructive"
        })
        
        setIsLoading(false)
      })
      
      // Clean up subscription
      return () => {
        unsubscribe()
      }
    }
  }, [user, loading, router])

  // Update the active tab when URL parameter changes
  useEffect(() => {
    if (tabParam === 'certificates') {
      setActiveTab('certificates')
    } else if (tabParam === 'analytics') {
      setActiveTab('analytics')
    } else if (tabParam === 'notes') {
      setActiveTab('notes')
    } else if (tabParam === 'goals') {
      setActiveTab('goals')
    } else if (tabParam === 'discussions') {
      setActiveTab('discussions')
    } else if (tabParam === 'lecturer-slides') {
      setActiveTab('lecturer-slides')
      router.push('/dashboard/lecturer-slides')
    } else {
      setActiveTab('courses')
    }
  }, [tabParam])

  const handleAddNote = () => {
    setCurrentNote({
      id: `note-${Date.now()}`,
      courseId: "",
      title: "",
      content: "",
      createdAt: new Date().toISOString()
    })
    setIsEditingNote(true)
  }

  const handleEditNote = (note: CourseNote) => {
    setCurrentNote(note)
    setIsEditingNote(true)
  }

  const handleSaveNote = async () => {
    if (!currentNote?.title || !currentNote.content || !user) return

    try {
      // Update local state first for immediate feedback
      let updatedNotes;
    if (notes.find(note => note.id === currentNote.id)) {
      // Update existing note
        updatedNotes = notes.map(note => 
        note.id === currentNote.id ? currentNote : note
        );
    } else {
      // Add new note
        updatedNotes = [...notes, currentNote];
      }
      
      setNotes(updatedNotes);
      
      // Save to Firebase
      await saveUserNote(user.uid, currentNote);
      
      setIsEditingNote(false);
      setCurrentNote(null);
    } catch (error) {
      console.error("Error saving note:", error);
      toast({
        title: "Error saving note",
        description: "There was a problem saving your note. Please try again.",
        variant: "destructive"
      });
    }
  }

  const handleDeleteNote = async (noteId: string) => {
    if (!user) return;
    
    try {
      // Update local state first for immediate feedback
      const updatedNotes = notes.filter(note => note.id !== noteId);
      setNotes(updatedNotes);
      
      // Delete from Firebase
      await deleteUserNote(user.uid, noteId);
    } catch (error) {
      console.error("Error deleting note:", error);
      toast({
        title: "Error deleting note",
        description: "There was a problem deleting your note. Please try again.",
        variant: "destructive"
      });
    }
  }

  const handleDeleteBookmark = async (bookmarkId: string) => {
    if (!user) return;
    
    try {
      // Update local state first for immediate feedback
      const updatedBookmarks = bookmarks.filter(bookmark => bookmark.id !== bookmarkId);
      setBookmarks(updatedBookmarks);
      
      // Delete from Firebase
      await deleteUserBookmark(user.uid, bookmarkId);
    } catch (error) {
      console.error("Error deleting bookmark:", error);
      toast({
        title: "Error deleting bookmark",
        description: "There was a problem deleting your bookmark. Please try again.",
        variant: "destructive"
      });
    }
  }

  const findCourseById = (courseId: string) => {
    return allCourses.find(course => course.id === courseId)
  }

  // Handler functions for learning goals
  const handleAddGoal = async (goal: LearningGoal) => {
    if (!user) return;
    
    try {
      // Update local state first for immediate feedback
      const updatedGoals = [...learningGoals, goal];
      setLearningGoals(updatedGoals);
      
      // Save to Firebase
      await saveUserGoal(user.uid, goal);
    } catch (error) {
      console.error("Error adding goal:", error);
      toast({
        title: "Error adding goal",
        description: "There was a problem adding your goal. Please try again.",
        variant: "destructive"
      });
    }
  }
  
  const handleUpdateGoal = async (goal: LearningGoal) => {
    if (!user) return;
    
    try {
      // Update local state first for immediate feedback
      const updatedGoals = learningGoals.map(g => g.id === goal.id ? goal : g);
      setLearningGoals(updatedGoals);
      
      // Save to Firebase
      await saveUserGoal(user.uid, goal);
    } catch (error) {
      console.error("Error updating goal:", error);
      toast({
        title: "Error updating goal",
        description: "There was a problem updating your goal. Please try again.",
        variant: "destructive"
      });
    }
  }
  
  const handleDeleteGoal = async (goalId: string) => {
    if (!user) return;
    
    try {
      // Update local state first for immediate feedback
      const updatedGoals = learningGoals.filter(goal => goal.id !== goalId);
      setLearningGoals(updatedGoals);
      
      // Delete from Firebase
      await deleteUserGoal(user.uid, goalId);
    } catch (error) {
      console.error("Error deleting goal:", error);
      toast({
        title: "Error deleting goal",
        description: "There was a problem deleting your goal. Please try again.",
        variant: "destructive"
      });
    }
  }
  
  const handleUpdateGoalProgress = async (goalId: string, progress: number) => {
    if (!user) return;
    
    try {
      // Update local state first for immediate feedback
      const updatedGoals = learningGoals.map(goal => 
      goal.id === goalId ? {...goal, progress} : goal
      );
      setLearningGoals(updatedGoals);
      
      // Find the goal and update it in Firebase
      const goalToUpdate = updatedGoals.find(goal => goal.id === goalId);
      if (goalToUpdate) {
        await saveUserGoal(user.uid, goalToUpdate);
      }
    } catch (error) {
      console.error("Error updating goal progress:", error);
      toast({
        title: "Error updating progress",
        description: "There was a problem updating your progress. Please try again.",
        variant: "destructive"
      });
    }
  }

  // Discussion handlers
  const handleCreateThread = async (thread: Omit<DiscussionThread, 'id' | 'timestamp' | 'comments' | 'likes' | 'resolved'>) => {
    if (!user) return;
    
    try {
    const newThread: DiscussionThread = {
      ...thread,
      id: `disc-${Date.now()}`,
      timestamp: new Date().toISOString(),
      comments: [],
      likes: 0,
      resolved: false
    }
    
      // Update local state first for immediate feedback
      const updatedDiscussions = [newThread, ...discussions];
      setDiscussions(updatedDiscussions);
      
      // Save to Firebase
      await updateUserDiscussions(user.uid, updatedDiscussions);
    } catch (error) {
      console.error("Error creating thread:", error);
      toast({
        title: "Error creating discussion",
        description: "There was a problem creating your discussion. Please try again.",
        variant: "destructive"
      });
    }
  }
  
  const handleAddComment = async (threadId: string, comment: Omit<DiscussionComment, 'id' | 'timestamp' | 'likes' | 'replies'>) => {
    if (!user) return;
    
    try {
    const newComment: DiscussionComment = {
      ...comment,
      id: `comment-${Date.now()}`,
      timestamp: new Date().toISOString(),
      likes: 0,
      replies: []
    }
    
      // Update local state first for immediate feedback
      const updatedDiscussions = discussions.map(thread => 
      thread.id === threadId 
        ? { ...thread, comments: [...thread.comments, newComment] }
        : thread
      );
      
      setDiscussions(updatedDiscussions);
      
      // Save to Firebase
      await updateUserDiscussions(user.uid, updatedDiscussions);
    } catch (error) {
      console.error("Error adding comment:", error);
      toast({
        title: "Error adding comment",
        description: "There was a problem adding your comment. Please try again.",
        variant: "destructive"
      });
    }
  }
  
  const handleAddReply = async (threadId: string, commentId: string, reply: Omit<DiscussionComment, 'id' | 'timestamp' | 'likes' | 'replies'>) => {
    if (!user) return;
    
    try {
    const newReply: DiscussionComment = {
      ...reply,
      id: `reply-${Date.now()}`,
      timestamp: new Date().toISOString(),
      likes: 0,
      replies: []
    }
    
      // Update local state first for immediate feedback
      const updatedDiscussions = discussions.map(thread => 
      thread.id === threadId 
        ? {
            ...thread,
            comments: thread.comments.map(comment => 
              comment.id === commentId
                ? { ...comment, replies: [...comment.replies, newReply] }
                : comment
            )
          }
        : thread
      );
      
      setDiscussions(updatedDiscussions);
      
      // Save to Firebase
      await updateUserDiscussions(user.uid, updatedDiscussions);
    } catch (error) {
      console.error("Error adding reply:", error);
      toast({
        title: "Error adding reply",
        description: "There was a problem adding your reply. Please try again.",
        variant: "destructive"
      });
    }
  }
  
  const handleLikeThread = async (threadId: string) => {
    if (!user) return;
    
    try {
      // Update local state first for immediate feedback
      const updatedDiscussions = discussions.map(thread => 
      thread.id === threadId 
        ? { ...thread, likes: thread.likes + 1 }
        : thread
      );
      
      setDiscussions(updatedDiscussions);
      
      // Save to Firebase
      await updateUserDiscussions(user.uid, updatedDiscussions);
    } catch (error) {
      console.error("Error liking thread:", error);
      toast({
        title: "Error liking discussion",
        description: "There was a problem registering your like. Please try again.",
        variant: "destructive"
      });
    }
  }
  
  const handleLikeComment = async (threadId: string, commentId: string) => {
    if (!user) return;
    
    try {
      // Update local state first for immediate feedback
      const updatedDiscussions = discussions.map(thread => 
      thread.id === threadId 
        ? {
            ...thread,
            comments: thread.comments.map(comment => 
              comment.id === commentId
                ? { ...comment, likes: comment.likes + 1 }
                : comment
            )
          }
        : thread
      );
      
      setDiscussions(updatedDiscussions);
      
      // Save to Firebase
      await updateUserDiscussions(user.uid, updatedDiscussions);
    } catch (error) {
      console.error("Error liking comment:", error);
      toast({
        title: "Error liking comment",
        description: "There was a problem registering your like. Please try again.",
        variant: "destructive"
      });
    }
  }
  
  const handleResolveThread = async (threadId: string) => {
    if (!user) return;
    
    try {
      // Update local state first for immediate feedback
      const updatedDiscussions = discussions.map(thread => 
      thread.id === threadId 
        ? { ...thread, resolved: true }
        : thread
      );
      
      setDiscussions(updatedDiscussions);
      
      // Save to Firebase
      await updateUserDiscussions(user.uid, updatedDiscussions);
    } catch (error) {
      console.error("Error resolving thread:", error);
      toast({
        title: "Error resolving discussion",
        description: "There was a problem resolving this discussion. Please try again.",
        variant: "destructive"
      });
    }
  }

  if (loading || isLoading) {
    return (
      <div className="container flex h-screen max-w-screen-xl flex-col items-center justify-center px-4 py-16">
        <div className="flex flex-col items-center">
          <Loader2 className="h-12 w-12 animate-spin text-blue-600" />
          <p className="mt-4 text-lg">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return null // Will be handled by the useEffect redirect
  }

  // Get the certificate being viewed
  const viewingCertificate = showCertificate 
    ? certificates.find(cert => cert.id === showCertificate) 
    : null

  // Activity heatmap - simplified version
  const ActivityItem = ({ value }: { value: number }) => {
    let bgClass = 'bg-gray-100 dark:bg-gray-800'
    
    if (value > 0) {
      if (value < 2) bgClass = 'bg-green-100 dark:bg-green-900/30'
      else if (value < 4) bgClass = 'bg-green-200 dark:bg-green-800/40'
      else bgClass = 'bg-green-300 dark:bg-green-700/50'
    }
    
    return <div className={`h-3 w-3 rounded-sm ${bgClass}`}></div>
  }

  // Stat card component for analytics page
  const StatCard = ({ icon: Icon, title, value, description }: { 
    icon: LucideIcon, 
    title: string, 
    value: string | number, 
    description?: string 
  }) => (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center">
          <div className="mr-2 rounded-md bg-blue-100 p-1.5 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300">
            <Icon className="h-4 w-4" />
          </div>
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {description && <p className="text-xs text-muted-foreground">{description}</p>}
      </CardContent>
    </Card>
  )

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Student Dashboard</h1>
        <p className="text-muted-foreground">Welcome back, {user.displayName || user.email}</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Enrolled Courses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{enrolledCourses.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Certificates Earned</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{certificates.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Avg. Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {Object.values(courseProgress).length > 0
                ? Math.round(Object.values(courseProgress).reduce((a, b) => a + b, 0) / Object.values(courseProgress).length)
                : 0}%
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Learning Streak</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{learningStats.streakDays} days</div>
            <div className="flex space-x-1 pt-2">
              {learningStats.weeklyActivity.map((value, i) => (
                <ActivityItem key={i} value={value} />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-8">
        <TabsList className="mb-6">
          <TabsTrigger value="courses" onClick={() => router.push('/dashboard')}>
            <Book className="mr-2 h-4 w-4" />
            My Courses
          </TabsTrigger>
          <TabsTrigger value="certificates" onClick={() => router.push('/dashboard?tab=certificates')}>
            <Award className="mr-2 h-4 w-4" />
            Certificates
          </TabsTrigger>
          <TabsTrigger value="analytics" onClick={() => router.push('/dashboard?tab=analytics')}>
            <BarChart3 className="mr-2 h-4 w-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="notes" onClick={() => router.push('/dashboard?tab=notes')}>
            <PenLine className="mr-2 h-4 w-4" />
            Notes & Bookmarks
          </TabsTrigger>
          <TabsTrigger value="goals" onClick={() => router.push('/dashboard?tab=goals')}>
            <Target className="mr-2 h-4 w-4" />
            Goals
          </TabsTrigger>
          <TabsTrigger value="discussions" onClick={() => router.push('/dashboard?tab=discussions')}>
            <MessageSquare className="mr-2 h-4 w-4" />
            Discussions
          </TabsTrigger>
          <TabsTrigger value="lecturer-slides" onClick={() => router.push('/dashboard/lecturer-slides')}>
            <FileText className="mr-2 h-4 w-4" />
            Lecturer Slides
          </TabsTrigger>
        </TabsList>
        
        {/* Courses Tab */}
        <TabsContent value="courses">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <h2 className="mb-4 text-2xl font-bold">My Courses</h2>
              <Button variant="outline" size="sm" asChild>
                <Link href="/courses">Browse More Courses</Link>
              </Button>
            </div>
            
            {enrolledCourses.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-gray-300 py-12 text-center dark:border-gray-700">
                <GraduationCap className="mb-4 h-12 w-12 text-gray-400" />
                <h3 className="mb-2 text-lg font-medium">No courses yet</h3>
                <p className="mb-4 max-w-md text-gray-500 dark:text-gray-400">
                  You haven't enrolled in any courses yet. Explore our course catalog to start learning.
                </p>
                <Button asChild>
                  <Link href="/courses">Browse Courses</Link>
                </Button>
              </div>
            ) : (
              <div className="grid gap-6 lg:grid-cols-2">
                {enrolledCourses.map((course) => (
                  <Card key={course.id} className="overflow-hidden">
                    <div className="flex flex-col md:flex-row">
                      <div className="md:w-1/3">
                        <img
                          src={course.image && course.image.startsWith('http') 
                            ? course.image 
                            : `https://images.unsplash.com/photo-${getCategoryImage(course.category)}?w=800&auto=format&fit=crop`}
                          alt={course.title}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div className="flex flex-1 flex-col p-6">
                        <CardTitle className="line-clamp-1 mb-2 text-xl">{course.title}</CardTitle>
                        <CardDescription className="mb-4">{course.instructor.name}</CardDescription>
                        
                        <div className="mb-4 flex items-center space-x-4 text-sm text-muted-foreground">
                          <div className="flex items-center">
                            <Clock className="mr-1 h-4 w-4" />
                            <span>{course.duration}</span>
                          </div>
                          <div className="flex items-center">
                            <CheckCircle className="mr-1 h-4 w-4" />
                            <span>
                              {course.modules.reduce((total, module) => total + module.lessons.length, 0)} lessons
                            </span>
                          </div>
                        </div>
                        
                        <div className="mb-3 flex items-center justify-between">
                          <span className="text-sm font-medium">
                            Progress: {courseProgress[course.id] || 0}%
                          </span>
                        </div>
                        <Progress value={courseProgress[course.id] || 0} className="mb-4 h-2" />
                        
                        <div className="mt-auto flex space-x-2">
                          <Button asChild className="flex-1">
                            <Link href={`/courses/${course.id}`}>
                              <BookOpen className="mr-2 h-4 w-4" />
                              {courseProgress[course.id] > 0 ? "Continue" : "Start"}
                            </Link>
                          </Button>
                          <Button variant="outline" size="icon" asChild>
                            <Link href="#" onClick={(e) => {
                              e.preventDefault();
                              const newNote = {
                                id: `note-${Date.now()}`,
                                courseId: course.id,
                                title: `Notes for ${course.title}`,
                                content: "",
                                createdAt: new Date().toISOString()
                              };
                              setCurrentNote(newNote);
                              setIsEditingNote(true);
                            }}>
                              <PenLine className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button variant="outline" size="icon" asChild>
                            <Link href={`/courses/${course.id}#bookmark`}>
                              <BookMarked className="h-4 w-4" />
                            </Link>
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Recommended Courses Section */}
          <div className="mt-12">
            <h2 className="mb-6 text-2xl font-bold">Recommended For You</h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {recommendedCourses.map((course) => (
                <Card key={course.id} className="overflow-hidden">
                  <div className="relative aspect-video overflow-hidden">
                    <img
                      src={course.image && course.image.startsWith('http') 
                        ? course.image 
                        : `https://images.unsplash.com/photo-${getCategoryImage(course.category)}?w=800&auto=format&fit=crop`}
                      alt={course.title}
                      className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
                    />
                    <Badge className="absolute left-3 top-3 bg-blue-600 hover:bg-blue-700">{course.category}</Badge>
                    <Badge className="absolute right-3 top-3" variant="outline">{course.level}</Badge>
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle className="line-clamp-1 text-xl">{course.title}</CardTitle>
                    <CardDescription className="flex items-center">
                      <span>By {course.instructor.name}</span>
                      <span className="ml-auto flex items-center">
                        <Star className="mr-1 h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{course.rating.toFixed(1)}</span>
                      </span>
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <p className="line-clamp-2 text-sm text-gray-500 dark:text-gray-400">{course.description}</p>
                  </CardContent>
                  <CardFooter>
                    <Button asChild className="w-full">
                      <Link href={`/courses/${course.id}`}>
                        <Lightbulb className="mr-2 h-4 w-4" />
                        Explore Course
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>
        
        {/* Certificates Tab */}
        <TabsContent value="certificates">
          <h2 className="mb-6 text-2xl font-bold">My Certificates</h2>
          {certificates.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-gray-300 py-12 text-center dark:border-gray-700">
              <Award className="mb-4 h-12 w-12 text-gray-400" />
              <h3 className="mb-2 text-lg font-medium">No certificates yet</h3>
              <p className="mb-4 max-w-md text-gray-500 dark:text-gray-400">
                Complete courses to earn certificates. Keep learning to showcase your achievements!
              </p>
              <Button asChild>
                <Link href="/courses">Browse Courses</Link>
              </Button>
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {certificates.map((certificate) => (
                <Card key={certificate.id} className="overflow-hidden">
                  <div className="relative aspect-[4/3] bg-gradient-to-br from-blue-100 to-blue-50 dark:from-blue-900 dark:to-blue-800">
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                      <Award className="mb-4 h-12 w-12 text-blue-600 dark:text-blue-400" />
                      <h3 className="mb-2 text-xl font-bold">{certificate.courseTitle}</h3>
                      <p className="text-sm text-muted-foreground">
                        Successfully completed on {new Date(certificate.issueDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <CardFooter className="flex justify-between p-4">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setShowCertificate(certificate.id)}
                    >
                      View Certificate
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Calendar className="mr-2 h-4 w-4" />
                      {new Date(certificate.issueDate).toLocaleDateString()}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        {/* Analytics Tab */}
        <TabsContent value="analytics">
          <h2 className="mb-6 text-2xl font-bold">Learning Analytics</h2>
          
          {/* Weekly Goal Progress */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Weekly Goal Progress</CardTitle>
              <CardDescription>You've completed {learningStats.weeklyProgress}% of your weekly goal ({learningStats.weeklyGoal} hours)</CardDescription>
            </CardHeader>
            <CardContent>
              <Progress value={learningStats.weeklyProgress} className="h-3" />
              
              <div className="mt-6 grid grid-cols-7 gap-1 text-center">
                {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, i) => (
                  <div key={`${day}-${i}`} className="flex flex-col items-center">
                    <div className="text-xs font-medium text-muted-foreground">{day}</div>
                    <div className={`mt-2 h-16 w-full rounded-md ${
                      learningStats.weeklyActivity[i] > 0 
                        ? `bg-blue-100 dark:bg-blue-900/30` 
                        : `bg-gray-100 dark:bg-gray-800`
                    }`} style={{ height: `${Math.max(8, learningStats.weeklyActivity[i] * 20)}px` }} />
                    <div className="mt-1 text-xs">{learningStats.weeklyActivity[i]}h</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          {/* Stats Grid */}
          <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard 
              icon={Clock} 
              title="Total Learning Time" 
              value={learningStats.totalTimeSpent} 
              description="Since you joined" 
            />
            <StatCard 
              icon={Clock} 
              title="Avg. Session Length" 
              value={learningStats.averageSessionLength}
            />
            <StatCard 
              icon={CheckCircle} 
              title="Completed Lessons" 
              value={learningStats.completedLessons}
            />
            <StatCard 
              icon={GraduationCap} 
              title="Course Completion Rate" 
              value="67%" 
              description="Courses you've finished"
            />
          </div>
          
          {/* Course Progress */}
          <h3 className="mb-4 text-xl font-semibold">Course Progress Breakdown</h3>
          <div className="space-y-6">
            {enrolledCourses.map((course) => (
              <Card key={course.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-base">{course.title}</CardTitle>
                      <CardDescription>
                        {courseProgress[course.id] || 0}% complete
                      </CardDescription>
                    </div>
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/courses/${course.id}`}>
                        Continue
                      </Link>
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <Progress value={courseProgress[course.id] || 0} className="h-2" />
                  
                  <div className="mt-4 flex justify-between text-sm text-muted-foreground">
                    <div>Started: 3 weeks ago</div>
                    <div>Est. completion: {courseProgress[course.id] < 50 ? '2 weeks' : '4 days'}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        {/* Notes & Bookmarks Tab */}
        <TabsContent value="notes">
          <div className="flex items-center justify-between">
            <h2 className="mb-6 text-2xl font-bold">My Notes & Bookmarks</h2>
            <Button onClick={handleAddNote}>
              <PenLine className="mr-2 h-4 w-4" />
              Add Note
            </Button>
          </div>
          
          {/* Notes Section */}
          <div className="mb-8">
            <h3 className="mb-4 text-xl font-semibold">Notes</h3>
            
            {notes.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-gray-300 py-8 text-center dark:border-gray-700">
                <FileText className="mb-4 h-8 w-8 text-gray-400" />
                <h3 className="mb-2 text-base font-medium">No notes yet</h3>
                <p className="mb-4 max-w-md text-sm text-gray-500 dark:text-gray-400">
                  Add notes to keep track of important concepts while learning.
                </p>
                <Button size="sm" onClick={handleAddNote}>Add Your First Note</Button>
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {notes.map((note) => {
                  const relatedCourse = findCourseById(note.courseId)
                  
                  return (
                    <Card key={note.id} className="flex flex-col">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <CardTitle className="text-base">{note.title}</CardTitle>
                          <div className="flex">
                            <Button variant="ghost" size="icon" onClick={() => handleEditNote(note)}>
                              <PenLine className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDeleteNote(note.id)}>
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        {relatedCourse && (
                          <CardDescription>
                            From: {relatedCourse.title}
                          </CardDescription>
                        )}
                      </CardHeader>
                      <CardContent className="pb-3 pt-0">
                        <p className="text-sm text-gray-700 dark:text-gray-300">
                          {note.content}
                        </p>
                      </CardContent>
                      <CardFooter className="mt-auto pt-0">
                        <p className="text-xs text-muted-foreground">
                          {new Date(note.createdAt).toLocaleDateString()}
                        </p>
                      </CardFooter>
                    </Card>
                  )
                })}
              </div>
            )}
          </div>
          
          {/* Bookmarks Section */}
          <div>
            <h3 className="mb-4 text-xl font-semibold">Bookmarks</h3>
            
            {bookmarks.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-gray-300 py-8 text-center dark:border-gray-700">
                <BookMarked className="mb-4 h-8 w-8 text-gray-400" />
                <h3 className="mb-2 text-base font-medium">No bookmarks yet</h3>
                <p className="mb-4 max-w-md text-sm text-gray-500 dark:text-gray-400">
                  Bookmarks help you quickly return to important sections in your courses.
                </p>
              </div>
            ) : (
              <div className="divide-y dark:divide-gray-700">
                {bookmarks.map((bookmark) => {
                  const relatedCourse = findCourseById(bookmark.courseId)
                  
                  return (
                    <div key={bookmark.id} className="flex items-center justify-between py-4">
                      <div className="flex flex-col">
                        <div className="flex items-center">
                          <BookMarked className="mr-2 h-4 w-4 text-blue-600 dark:text-blue-400" />
                          <span className="font-medium">{bookmark.lessonTitle}</span>
                        </div>
                        <div className="mt-1 text-sm text-muted-foreground">
                          {relatedCourse?.title} • {bookmark.moduleTitle} • {bookmark.timestamp}
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/courses/${bookmark.courseId}/learn?lesson=${bookmark.lessonId}&t=${bookmark.timestamp}`}>
                            Go to Bookmark
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteBookmark(bookmark.id)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </TabsContent>
        
        {/* Goals Tab */}
        <TabsContent value="goals">
          <div className="mb-6">
            <h2 className="mb-6 text-2xl font-bold">Learning Goals</h2>
            <p className="mb-8 text-gray-500 dark:text-gray-400">
              Set personal learning goals to track your progress and stay motivated on your learning journey.
            </p>
            
            <LearningGoals 
              goals={learningGoals}
              onAddGoal={handleAddGoal}
              onUpdateGoal={handleUpdateGoal}
              onDeleteGoal={handleDeleteGoal}
              onUpdateProgress={handleUpdateGoalProgress}
            />
          </div>
        </TabsContent>
        
        {/* Discussions Tab */}
        <TabsContent value="discussions">
          <CourseDiscussion
            courseId="all"
            courseTitle="All Courses"
            discussions={discussions}
            currentUserId={user?.uid || ""}
            currentUserName={user?.displayName || user?.email?.split('@')[0] || "Student"}
            currentUserImage={user?.photoURL || undefined}
            isInstructor={false}
            onCreateThread={handleCreateThread}
            onAddComment={handleAddComment}
            onAddReply={handleAddReply}
            onLikeThread={handleLikeThread}
            onLikeComment={handleLikeComment}
            onResolveThread={handleResolveThread}
          />
        </TabsContent>
      </Tabs>
      
      {/* Note Edit Dialog */}
      <AlertDialog open={isEditingNote} onOpenChange={setIsEditingNote}>
        <AlertDialogContent className="sm:max-w-[500px]">
          <AlertDialogHeader>
            <AlertDialogTitle>{currentNote?.id.includes('note-') && !currentNote?.title ? 'Add New Note' : 'Edit Note'}</AlertDialogTitle>
            <AlertDialogDescription>
              {currentNote?.id.includes('note-') && !currentNote?.title 
                ? 'Create a new note to help you remember important concepts.'
                : 'Update your existing note with new information.'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="course">Related Course</Label>
              <select 
                id="course"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                value={currentNote?.courseId || ""}
                onChange={e => setCurrentNote(prev => prev ? {...prev, courseId: e.target.value} : null)}
              >
                <option value="">Select a course</option>
                {enrolledCourses.map(course => (
                  <option key={course.id} value={course.id}>{course.title}</option>
                ))}
              </select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="title">Title</Label>
              <Input 
                id="title" 
                placeholder="Note title"
                value={currentNote?.title || ""}
                onChange={e => setCurrentNote(prev => prev ? {...prev, title: e.target.value} : null)}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="content">Content</Label>
              <Textarea 
                id="content" 
                placeholder="Write your note here..."
                className="min-h-[120px]"
                value={currentNote?.content || ""}
                onChange={e => setCurrentNote(prev => prev ? {...prev, content: e.target.value} : null)}
              />
            </div>
          </div>
          
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleSaveNote}>Save Note</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Certificate Viewer */}
      {viewingCertificate && (
        <CertificateView
          id={viewingCertificate.id}
          courseTitle={viewingCertificate.courseTitle}
          studentName={user.displayName || user.email?.split('@')[0] || "Student"}
          issueDate={viewingCertificate.issueDate}
          onClose={() => setShowCertificate(null)}
        />
      )}
    </div>
  )
}

export default function DashboardPage() {
  return (
    <Suspense fallback={<div className="container flex h-screen max-w-screen-xl flex-col items-center justify-center px-4 py-16">
      <p>Loading dashboard...</p>
    </div>}>
      <DashboardContent />
    </Suspense>
  )
} 