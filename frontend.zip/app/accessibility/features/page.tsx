"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { 
  Accessibility, 
  FileText, 
  Globe, 
  Headphones, 
  Languages, 
  Smartphone, 
  Keyboard, 
  Eye, 
  Volume2, 
  Hand, 
  Type, 
  Zap 
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { AccessibilityFeatures } from "@/components/accessibility-features"

export default function AccessibilityFeaturesPage() {
  const featureGroups = [
    {
      title: "Vision",
      icon: Eye,
      features: [
        {
          title: "Color Contrast",
          description: "Our platform follows WCAG guidelines for color contrast to ensure text is legible against backgrounds for users with low vision or color blindness."
        },
        {
          title: "Text Resizing",
          description: "All text can be resized up to 200% without loss of content or functionality."
        },
        {
          title: "Screen Reader Support",
          description: "Our platform is optimized for screen readers with proper semantic HTML, ARIA attributes, and descriptive text."
        },
        {
          title: "Dark Mode",
          description: "Toggle between light and dark modes to reduce eye strain and improve visibility in different lighting conditions."
        }
      ]
    },
    {
      title: "Hearing",
      icon: Volume2,
      features: [
        {
          title: "Video Captions",
          description: "All video content includes accurate closed captions that can be toggled on/off."
        },
        {
          title: "Transcripts",
          description: "Full text transcripts are available for all audio and video content."
        },
        {
          title: "Visual Notifications",
          description: "Important information is conveyed visually as well as audibly."
        },
        {
          title: "Adjustable Volume",
          description: "Users can control audio levels independently for different types of content."
        }
      ]
    },
    {
      title: "Mobility",
      icon: Hand,
      features: [
        {
          title: "Keyboard Navigation",
          description: "All functionality can be accessed using only a keyboard, with visible focus indicators."
        },
        {
          title: "Large Click Targets",
          description: "Buttons and interactive elements are sized and spaced appropriately for users with motor control difficulties."
        },
        {
          title: "Voice Commands",
          description: "Support for browser-based voice command technologies."
        },
        {
          title: "Time Controls",
          description: "Users can adjust or disable time limits for timed activities and assessments."
        }
      ]
    },
    {
      title: "Cognitive",
      icon: Type,
      features: [
        {
          title: "Clear Navigation",
          description: "Consistent and simple navigation structure throughout the platform."
        },
        {
          title: "Reading Level",
          description: "Content is written at an accessible reading level with definitions for technical terms."
        },
        {
          title: "Distraction Reduction",
          description: "Options to minimize animations and distracting elements."
        },
        {
          title: "Structured Content",
          description: "Information is organized with clear headings, lists, and sections for better comprehension."
        }
      ]
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Accessibility Features</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Detailed information about our platform's accessibility features
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-12 text-center"
        >
          <h2 className="mb-4 text-2xl font-bold">Making Learning Accessible for Everyone</h2>
          <p className="mx-auto max-w-3xl text-gray-700 dark:text-gray-300">
            We've implemented a comprehensive set of accessibility features to ensure that all users, 
            regardless of ability, can fully engage with our learning platform. Our features are grouped by the 
            type of accessibility need they address.
          </p>
        </motion.div>

        {featureGroups.map((group, groupIndex) => (
          <motion.div
            key={group.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 + (0.1 * groupIndex) }}
            className="mb-16"
          >
            <div className="mb-6 flex items-center">
              <div className="mr-4 rounded-full bg-blue-100 p-3 text-blue-600 dark:bg-blue-900 dark:text-blue-400">
                <group.icon className="h-6 w-6" />
              </div>
              <h2 className="text-2xl font-bold">{group.title} Accessibility</h2>
            </div>
            <div className="grid gap-6 md:grid-cols-2">
              {group.features.map((feature, featureIndex) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 + (0.05 * (groupIndex * 4 + featureIndex)) }}
                  className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800"
                >
                  <h3 className="mb-2 text-xl font-semibold">{feature.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        ))}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-16 rounded-xl bg-blue-50 p-8 dark:bg-blue-950"
        >
          <div className="mx-auto max-w-3xl text-center">
            <h3 className="mb-4 text-2xl font-bold text-blue-700 dark:text-blue-300">
              Need Additional Accommodations?
            </h3>
            <p className="mb-6 text-blue-700 dark:text-blue-300">
              We're committed to making our platform accessible to all users. If you need additional accommodations
              or have suggestions for improving our accessibility features, please let us know.
            </p>
            <Link href="/accessibility/feedback">
              <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
                Contact Our Accessibility Team
              </Button>
            </Link>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="mt-12 text-center"
        >
          <Link href="/accessibility">
            <Button variant="outline">
              Back to Accessibility Statement
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  )
} 