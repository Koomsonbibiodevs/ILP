"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { Accessibility, FileText, Globe, Headphones, Languages, Monitor, Smartphone, Users, Keyboard, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function AccessibilityPage() {
  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Accessibility Statement</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Our commitment to creating an inclusive learning experience for all users
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="mx-auto max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mb-8"
          >
            <h2 className="mb-4 text-2xl font-bold">Our Commitment to Accessibility</h2>
            <p className="mb-4 text-gray-700 dark:text-gray-300">
              At EduFree, we believe that education should be accessible to everyone, regardless of ability or circumstance. 
              We are committed to ensuring that our platform is usable by people of all abilities and disabilities.
            </p>
            <p className="mb-4 text-gray-700 dark:text-gray-300">
              We strive to conform to the Web Content Accessibility Guidelines (WCAG) 2.1 Level AA standards. Our 
              goal is to make our content perceivable, operable, understandable, and robust for all users.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mb-8"
          >
            <h2 className="mb-4 text-2xl font-bold">Accessibility Features</h2>
            <p className="mb-4 text-gray-700 dark:text-gray-300">
              Our platform includes various accessibility features to help all users access our content:
            </p>
            <ul className="mb-4 list-inside list-disc space-y-2 text-gray-700 dark:text-gray-300">
              <li>Screen reader compatibility</li>
              <li>Keyboard navigation support</li>
              <li>Transcripts and closed captions for video content</li>
              <li>Color contrast for readability</li>
              <li>Resizable text without loss of functionality</li>
              <li>Alternative text for images</li>
            </ul>
            <div className="mt-6">
              <Link href="/accessibility/features">
                <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
                  Learn More About Our Accessibility Features
                </Button>
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="mb-8"
          >
            <h2 className="mb-4 text-2xl font-bold">Continuous Improvement</h2>
            <p className="mb-4 text-gray-700 dark:text-gray-300">
              We are constantly working to improve the accessibility of our platform. We regularly audit our site,
              test with assistive technologies, and incorporate user feedback to make our platform more accessible.
            </p>
            <p className="mb-4 text-gray-700 dark:text-gray-300">
              If you encounter any barriers to accessibility on our platform, we encourage you to let us know.
              Your feedback helps us identify and address accessibility issues.
            </p>
            <div className="mt-6">
              <Link href="/accessibility/feedback">
                <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
                  Provide Accessibility Feedback
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Quick Links */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-12"
        >
          <h2 className="mb-6 text-center text-2xl font-bold">Accessibility Resources</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Card className="transition-all duration-300 hover:shadow-md">
              <CardContent className="p-6">
                <div className="mb-4 flex items-center">
                  <div className="mr-4 rounded-full bg-blue-100 p-2 text-blue-600 dark:bg-blue-900 dark:text-blue-400">
                    <Monitor className="h-5 w-5" />
                  </div>
                  <h3 className="text-lg font-medium">Features</h3>
                </div>
                <p className="mb-4 text-sm text-gray-600 dark:text-gray-400">
                  Learn about the accessibility features available on our platform.
                </p>
                <Link href="/accessibility/features">
                  <Button variant="outline" className="w-full">View Features</Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="transition-all duration-300 hover:shadow-md">
              <CardContent className="p-6">
                <div className="mb-4 flex items-center">
                  <div className="mr-4 rounded-full bg-blue-100 p-2 text-blue-600 dark:bg-blue-900 dark:text-blue-400">
                    <Keyboard className="h-5 w-5" />
                  </div>
                  <h3 className="text-lg font-medium">Keyboard Shortcuts</h3>
                </div>
                <p className="mb-4 text-sm text-gray-600 dark:text-gray-400">
                  Discover keyboard shortcuts to navigate our platform more efficiently.
                </p>
                <Link href="/accessibility/keyboard-shortcuts">
                  <Button variant="outline" className="w-full">View Shortcuts</Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="transition-all duration-300 hover:shadow-md">
              <CardContent className="p-6">
                <div className="mb-4 flex items-center">
                  <div className="mr-4 rounded-full bg-blue-100 p-2 text-blue-600 dark:bg-blue-900 dark:text-blue-400">
                    <Headphones className="h-5 w-5" />
                  </div>
                  <h3 className="text-lg font-medium">Screen Readers</h3>
                </div>
                <p className="mb-4 text-sm text-gray-600 dark:text-gray-400">
                  Information on screen reader compatibility and usage with our platform.
                </p>
                <Link href="/accessibility/screen-readers">
                  <Button variant="outline" className="w-full">Learn More</Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="transition-all duration-300 hover:shadow-md">
              <CardContent className="p-6">
                <div className="mb-4 flex items-center">
                  <div className="mr-4 rounded-full bg-blue-100 p-2 text-blue-600 dark:bg-blue-900 dark:text-blue-400">
                    <MessageSquare className="h-5 w-5" />
                  </div>
                  <h3 className="text-lg font-medium">Feedback</h3>
                </div>
                <p className="mb-4 text-sm text-gray-600 dark:text-gray-400">
                  Share your experiences and help us improve our accessibility.
                </p>
                <Link href="/accessibility/feedback">
                  <Button variant="outline" className="w-full">Provide Feedback</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </div>
    </div>
  )
} 