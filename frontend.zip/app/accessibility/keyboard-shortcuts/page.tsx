"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { 
  Keyboard,
  ArrowLeft,
  ArrowRight,
  Search,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  SkipBack,
  SkipForward
} from "lucide-react"
import { Button } from "@/components/ui/button"

export default function KeyboardShortcutsPage() {
  const shortcutGroups = [
    {
      title: "General Navigation",
      shortcuts: [
        { key: "Tab", description: "Move forward through focusable elements" },
        { key: "Shift + Tab", description: "Move backward through focusable elements" },
        { key: "Enter", description: "Activate selected element or button" },
        { key: "Space", description: "Activate selected element or scroll down" },
        { key: "Esc", description: "Close modal dialogs or cancel actions" },
        { key: "/", description: "Focus on search box" },
        { key: "Alt + Home", description: "Go to the homepage" },
        { key: "Alt + 1-9", description: "Jump to main navigation items" }
      ]
    },
    {
      title: "Course Navigation",
      shortcuts: [
        { key: "←", description: "Previous slide/page" },
        { key: "→", description: "Next slide/page" },
        { key: "Ctrl + ←", description: "Previous lesson" },
        { key: "Ctrl + →", description: "Next lesson" },
        { key: "Shift + ←", description: "Previous module" },
        { key: "Shift + →", description: "Next module" },
        { key: "Home", description: "Go to first slide/page in lesson" },
        { key: "End", description: "Go to last slide/page in lesson" }
      ]
    },
    {
      title: "Video Player Controls",
      shortcuts: [
        { key: "Space", description: "Play/Pause video" },
        { key: "K", description: "Play/Pause video (alternative)" },
        { key: "M", description: "Mute/Unmute" },
        { key: "F", description: "Toggle fullscreen" },
        { key: "J", description: "Rewind 10 seconds" },
        { key: "L", description: "Forward 10 seconds" },
        { key: "↑", description: "Increase volume" },
        { key: "↓", description: "Decrease volume" },
        { key: "C", description: "Toggle captions" },
        { key: "Shift + <", description: "Decrease playback rate" },
        { key: "Shift + >", description: "Increase playback rate" }
      ]
    },
    {
      title: "Reading Content",
      shortcuts: [
        { key: "Ctrl + F", description: "Find in page" },
        { key: "Page Down", description: "Scroll down one page" },
        { key: "Page Up", description: "Scroll up one page" },
        { key: "Ctrl + Home", description: "Go to top of page" },
        { key: "Ctrl + End", description: "Go to bottom of page" },
        { key: "Ctrl + +", description: "Zoom in" },
        { key: "Ctrl + -", description: "Zoom out" },
        { key: "Ctrl + 0", description: "Reset zoom" }
      ]
    },
    {
      title: "Accessibility Shortcuts",
      shortcuts: [
        { key: "Alt + Shift + A", description: "Toggle high contrast mode" },
        { key: "Alt + Shift + C", description: "Toggle screen reader optimized mode" },
        { key: "Alt + Shift + M", description: "Toggle motion reduction" },
        { key: "Alt + Shift + T", description: "Toggle text size" },
        { key: "Alt + Shift + D", description: "Toggle dark/light mode" }
      ]
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Keyboard Shortcuts</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Navigate our platform efficiently with these keyboard shortcuts
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-12 text-center"
        >
          <h2 className="mb-4 text-2xl font-bold">Keyboard Navigation Guide</h2>
          <p className="mx-auto max-w-3xl text-gray-700 dark:text-gray-300">
            Our platform is designed to be fully keyboard accessible. Whether you prefer keyboard navigation or require 
            it due to mobility impairments, these shortcuts will help you move efficiently through our content.
          </p>
        </motion.div>

        <div className="grid gap-8 md:grid-cols-2">
          {shortcutGroups.map((group, groupIndex) => (
            <motion.div
              key={group.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 + (0.1 * groupIndex) }}
              className="rounded-lg border border-gray-200 bg-white shadow-sm dark:border-gray-700 dark:bg-gray-800"
            >
              <div className="border-b border-gray-200 bg-gray-50 px-6 py-4 dark:border-gray-700 dark:bg-gray-800/60">
                <h3 className="text-lg font-semibold">{group.title}</h3>
              </div>
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {group.shortcuts.map((shortcut, index) => (
                  <div 
                    key={index} 
                    className="flex items-center justify-between px-6 py-3"
                  >
                    <span className="text-gray-700 dark:text-gray-300">{shortcut.description}</span>
                    <kbd className="ml-2 rounded border border-gray-300 bg-gray-100 px-2 py-1 text-sm font-mono text-gray-900 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200">
                      {shortcut.key}
                    </kbd>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-16 rounded-xl bg-blue-50 p-8 dark:bg-blue-950"
        >
          <div className="mx-auto max-w-3xl text-center">
            <h3 className="mb-4 text-2xl font-bold text-blue-700 dark:text-blue-300">
              Customize Your Keyboard Experience
            </h3>
            <p className="mb-6 text-blue-700 dark:text-blue-300">
              You can customize some keyboard shortcuts in your account settings. We also support custom keyboard 
              configurations through assistive technologies for users with specific accessibility needs.
            </p>
            <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
              Go to Account Settings
            </Button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="mt-12 text-center"
        >
          <Link href="/accessibility">
            <Button variant="outline">
              Back to Accessibility Statement
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  )
} 