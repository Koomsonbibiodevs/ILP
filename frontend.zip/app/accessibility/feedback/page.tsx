"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { 
  MessageSquare,
  Send,
  CheckCircle,
  AlertCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function AccessibilityFeedbackPage() {
  // State for form fields and submission status
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    issueType: "",
    deviceType: "",
    assistiveTech: "",
    pageUrl: "",
    description: "",
    contactConsent: false
  });
  
  const [formStatus, setFormStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [formError, setFormError] = useState<string | null>(null);

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle select changes
  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle checkbox changes
  const handleCheckboxChange = (checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      contactConsent: checked
    }));
  };

  // Submit form
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.name || !formData.email || !formData.issueType || !formData.description) {
      setFormError("Please fill in all required fields.");
      return;
    }
    
    setFormStatus("submitting");
    
    // Simulate API call
    setTimeout(() => {
      // In a real app, you would send this data to your backend
      console.log("Form data submitted:", formData);
      setFormStatus("success");
      
      // Reset form after success
      setFormData({
        name: "",
        email: "",
        issueType: "",
        deviceType: "",
        assistiveTech: "",
        pageUrl: "",
        description: "",
        contactConsent: false
      });
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Accessibility Feedback</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Help us improve our platform's accessibility by sharing your experiences
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-12 text-center"
        >
          <h2 className="mb-4 text-2xl font-bold">We Value Your Feedback</h2>
          <p className="mx-auto max-w-3xl text-gray-700 dark:text-gray-300">
            If you've encountered an accessibility barrier or have suggestions for improving our platform's 
            accessibility, please let us know. Your feedback helps us create a better experience for all users.
          </p>
        </motion.div>

        {formStatus === "success" ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mx-auto max-w-2xl"
          >
            <Alert className="bg-green-50 dark:bg-green-900/20">
              <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
              <AlertTitle className="text-green-800 dark:text-green-400">Feedback Submitted Successfully</AlertTitle>
              <AlertDescription className="text-green-700 dark:text-green-300">
                Thank you for your feedback! We appreciate your input and will use it to improve our platform's accessibility.
                Our team will review your submission and may contact you if you've provided consent.
              </AlertDescription>
            </Alert>
            <div className="mt-8 text-center">
              <Link href="/accessibility">
                <Button variant="outline">
                  Back to Accessibility Statement
                </Button>
              </Link>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mx-auto max-w-2xl rounded-lg border border-gray-200 bg-white p-8 shadow-sm dark:border-gray-700 dark:bg-gray-800"
          >
            {formError && (
              <Alert className="mb-6 bg-red-50 dark:bg-red-900/20">
                <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
                <AlertTitle className="text-red-800 dark:text-red-400">Error</AlertTitle>
                <AlertDescription className="text-red-700 dark:text-red-300">
                  {formError}
                </AlertDescription>
              </Alert>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm font-medium">
                    Name <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    placeholder="Your name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium">
                    Email <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="Your email address"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="issueType" className="text-sm font-medium">
                  Type of Feedback <span className="text-red-500">*</span>
                </Label>
                <Select 
                  value={formData.issueType} 
                  onValueChange={(value) => handleSelectChange("issueType", value)}
                  required
                >
                  <SelectTrigger id="issueType">
                    <SelectValue placeholder="Select the type of feedback" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="barrier">Accessibility Barrier</SelectItem>
                    <SelectItem value="improvement">Suggestion for Improvement</SelectItem>
                    <SelectItem value="positive">Positive Experience</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="deviceType" className="text-sm font-medium">
                    Device Type
                  </Label>
                  <Select 
                    value={formData.deviceType} 
                    onValueChange={(value) => handleSelectChange("deviceType", value)}
                  >
                    <SelectTrigger id="deviceType">
                      <SelectValue placeholder="What device were you using?" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="desktop">Desktop Computer</SelectItem>
                      <SelectItem value="laptop">Laptop</SelectItem>
                      <SelectItem value="tablet">Tablet</SelectItem>
                      <SelectItem value="mobile">Mobile Phone</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="assistiveTech" className="text-sm font-medium">
                    Assistive Technology
                  </Label>
                  <Select 
                    value={formData.assistiveTech} 
                    onValueChange={(value) => handleSelectChange("assistiveTech", value)}
                  >
                    <SelectTrigger id="assistiveTech">
                      <SelectValue placeholder="Any assistive technology used?" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="screenreader">Screen Reader</SelectItem>
                      <SelectItem value="magnifier">Screen Magnifier</SelectItem>
                      <SelectItem value="voice">Voice Recognition</SelectItem>
                      <SelectItem value="keyboard">Keyboard Only</SelectItem>
                      <SelectItem value="switch">Switch Control</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                      <SelectItem value="none">None</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="pageUrl" className="text-sm font-medium">
                  Page URL
                </Label>
                <Input
                  id="pageUrl"
                  name="pageUrl"
                  placeholder="URL of the page where you experienced the issue"
                  value={formData.pageUrl}
                  onChange={handleInputChange}
                  className="w-full"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description" className="text-sm font-medium">
                  Description <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  id="description"
                  name="description"
                  placeholder="Please describe your experience or suggestion in detail"
                  value={formData.description}
                  onChange={handleInputChange}
                  className="h-32 w-full"
                  required
                />
              </div>
              
              <div className="flex items-start space-x-2">
                <Checkbox
                  id="contactConsent"
                  checked={formData.contactConsent}
                  onCheckedChange={handleCheckboxChange}
                />
                <Label
                  htmlFor="contactConsent"
                  className="text-sm text-gray-600 dark:text-gray-400"
                >
                  I consent to being contacted about my feedback if needed for follow-up or clarification.
                </Label>
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800"
                disabled={formStatus === "submitting"}
              >
                {formStatus === "submitting" ? (
                  <span className="flex items-center">
                    <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-opacity-20 border-t-white"></span>
                    Submitting...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <Send className="mr-2 h-4 w-4" />
                    Submit Feedback
                  </span>
                )}
              </Button>
            </form>
            
            <div className="mt-8 text-center">
              <Link href="/accessibility">
                <Button variant="outline">
                  Back to Accessibility Statement
                </Button>
              </Link>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
} 