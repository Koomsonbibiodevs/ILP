"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { 
  ScreenShare,
  Headphones,
  Monitor,
  Settings,
  CheckSquare,
  AlertTriangle,
  Info,
  HelpCircle,
  List,
  Laptop,
  ArrowRight
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ScreenReadersPage() {
  // List of supported screen readers
  const supportedScreenReaders = [
    {
      name: "NVDA",
      description: "Free, open-source screen reader for Windows",
      compatibility: "Full support",
      icon: CheckSquare,
      status: "recommended",
      downloadUrl: "https://www.nvaccess.org/download/",
      notes: "Our platform is regularly tested with NVDA to ensure full compatibility."
    },
    {
      name: "JAWS",
      description: "Commercial screen reader for Windows",
      compatibility: "Full support",
      icon: CheckSquare,
      status: "recommended",
      downloadUrl: "https://www.freedomscientific.com/products/software/jaws/",
      notes: "All features work well with JAWS, which is one of our primary testing platforms."
    },
    {
      name: "VoiceOver (macOS/iOS)",
      description: "Built-in screen reader for Apple devices",
      compatibility: "Full support",
      icon: CheckSquare,
      status: "recommended",
      downloadUrl: null,
      notes: "All features are compatible with VoiceOver on macOS and iOS devices."
    },
    {
      name: "TalkBack (Android)",
      description: "Built-in screen reader for Android devices",
      compatibility: "Full support",
      icon: CheckSquare,
      status: "recommended",
      downloadUrl: null,
      notes: "Our mobile experience is optimized for TalkBack users."
    },
    {
      name: "Narrator (Windows)",
      description: "Built-in screen reader for Windows",
      compatibility: "Partial support",
      icon: AlertTriangle,
      status: "partial",
      downloadUrl: null,
      notes: "Most features work with Narrator, but some advanced functionality may be limited."
    },
    {
      name: "Orca",
      description: "Screen reader for Linux environments",
      compatibility: "Partial support",
      icon: AlertTriangle,
      status: "partial",
      downloadUrl: "https://wiki.gnome.org/Projects/Orca",
      notes: "Basic functionality works well with Orca, but some advanced features may have reduced functionality."
    }
  ];

  // Tips for screen reader users
  const screenReaderTips = [
    {
      title: "Using Headings",
      description: "Our content is structured with proper heading levels (H1-H6) for easy navigation. Use your screen reader's heading navigation shortcuts to jump between sections.",
      icon: List
    },
    {
      title: "ARIA Landmarks",
      description: "We implement ARIA landmark roles (navigation, main, complementary, etc.) to help you quickly navigate to different areas of the page.",
      icon: Laptop
    },
    {
      title: "Skip Links",
      description: "Press Tab when first loading a page to access our skip links, which allow you to bypass navigation and jump directly to main content.",
      icon: ArrowRight
    },
    {
      title: "Form Labels",
      description: "All form fields have proper labels and descriptive text. If you encounter any unlabeled controls, please report them via our feedback form.",
      icon: Info
    },
    {
      title: "Video Content",
      description: "Video players include accessible controls and all videos have text transcripts that can be accessed via the 'Transcript' button near each video.",
      icon: Headphones
    },
    {
      title: "Alternative Text",
      description: "All meaningful images have descriptive alternative text. Decorative images are marked appropriately to be ignored by screen readers.",
      icon: Monitor
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Screen Reader Support</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Information and resources for users of screen readers and other assistive technologies
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-12 text-center"
        >
          <h2 className="mb-4 text-2xl font-bold">Making Our Content Accessible</h2>
          <p className="mx-auto max-w-3xl text-gray-700 dark:text-gray-300">
            We're committed to ensuring our platform works well with screen readers and other assistive technologies. 
            Our developers regularly test with popular screen readers to identify and fix accessibility issues.
          </p>
        </motion.div>

        <Tabs defaultValue="supported" className="mb-16">
          <TabsList className="mx-auto mb-8 w-full max-w-md">
            <TabsTrigger value="supported" className="flex-1">Supported Screen Readers</TabsTrigger>
            <TabsTrigger value="tips" className="flex-1">Usage Tips</TabsTrigger>
          </TabsList>
          
          <TabsContent value="supported">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
            >
              {supportedScreenReaders.map((reader, index) => (
                <Card key={reader.name} className="transition-all duration-300 hover:shadow-md">
                  <CardContent className="p-6">
                    <div className="mb-4 flex items-center justify-between">
                      <h3 className="text-xl font-semibold">{reader.name}</h3>
                      <div className={`rounded-full p-1 ${
                        reader.status === 'recommended' 
                          ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400' 
                          : 'bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400'
                      }`}>
                        <reader.icon className="h-5 w-5" />
                      </div>
                    </div>
                    <p className="mb-2 text-sm text-gray-600 dark:text-gray-400">{reader.description}</p>
                    <div className="mb-4">
                      <span className={`inline-block rounded-full px-2 py-1 text-xs font-medium ${
                        reader.status === 'recommended'
                          ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300'
                      }`}>
                        {reader.compatibility}
                      </span>
                    </div>
                    <p className="mb-4 text-xs text-gray-600 dark:text-gray-400">{reader.notes}</p>
                    {reader.downloadUrl && (
                      <a 
                        href={reader.downloadUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-block text-sm font-medium text-blue-600 hover:underline dark:text-blue-400"
                      >
                        Download {reader.name}
                      </a>
                    )}
                  </CardContent>
                </Card>
              ))}
            </motion.div>
          </TabsContent>

          <TabsContent value="tips">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
            >
              {screenReaderTips.map((tip, index) => (
                <Card key={tip.title} className="transition-all duration-300 hover:shadow-md">
                  <CardContent className="p-6">
                    <div className="mb-4 flex items-center">
                      <div className="mr-3 rounded-full bg-blue-100 p-2 text-blue-700 dark:bg-blue-900/50 dark:text-blue-400">
                        <tip.icon className="h-5 w-5" />
                      </div>
                      <h3 className="text-lg font-semibold">{tip.title}</h3>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{tip.description}</p>
                  </CardContent>
                </Card>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-16 rounded-xl bg-blue-50 p-8 dark:bg-blue-950"
        >
          <div className="mx-auto max-w-3xl text-center">
            <h3 className="mb-4 text-2xl font-bold text-blue-700 dark:text-blue-300">
              Need Additional Assistance?
            </h3>
            <p className="mb-6 text-blue-700 dark:text-blue-300">
              If you're experiencing issues with your screen reader on our platform, or have suggestions for improvement,
              please contact our accessibility team. We're committed to addressing barriers and continuously improving our platform.
            </p>
            <Link href="/accessibility/feedback">
              <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
                Contact Accessibility Support
              </Button>
            </Link>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="mt-12 text-center"
        >
          <Link href="/accessibility">
            <Button variant="outline">
              Back to Accessibility Statement
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  )
} 