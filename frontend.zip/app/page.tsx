import { HeroSection } from "@/components/hero-section"
import { FeaturedCourses } from "@/components/featured-courses"
import { CategorySection } from "@/components/category-section"
import { TestimonialSection } from "@/components/testimonial-section"
import { AccessibilityFeatures } from "@/components/accessibility-features"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <HeroSection />
      <FeaturedCourses />
      <CategorySection />
      <AccessibilityFeatures />
      <TestimonialSection />
    </div>
  )
}
