"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { 
  Briefcase,
  MapPin,
  Clock,
  Search,
  Filter,
  Users,
  Heart,
  Lightbulb,
  Globe,
  Rocket,
  BookOpen,
  ArrowRight,
  Coffee
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function CareersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [locationFilter, setLocationFilter] = useState<string | null>(null);
  const [departmentFilter, setDepartmentFilter] = useState<string | null>(null);

  // Sample job listings
  const jobs = [
    {
      id: "curriculum-designer",
      title: "Curriculum Designer",
      department: "Education",
      location: "Remote",
      type: "Full-time",
      posted: "2 weeks ago",
      description: "Design and develop educational content for our platform, ensuring it's engaging, accessible, and meets learning objectives.",
    },
    {
      id: "frontend-engineer",
      title: "Frontend Engineer",
      department: "Engineering",
      location: "Accra, Ghana",
      type: "Full-time",
      posted: "3 weeks ago",
      description: "Build intuitive, responsive interfaces for our learning platform using React, Next.js, and modern frontend technologies.",
    },
    {
      id: "accessibility-specialist",
      title: "Accessibility Specialist",
      department: "Product",
      location: "Remote",
      type: "Full-time",
      posted: "1 month ago",
      description: "Ensure our platform follows accessibility best practices and is usable by people of all abilities.",
    },
    {
      id: "content-partnerships-manager",
      title: "Content Partnerships Manager",
      department: "Operations",
      location: "Accra, Ghana",
      type: "Full-time",
      posted: "2 months ago",
      description: "Develop and manage relationships with educational content providers to expand our course offerings.",
    },
    {
      id: "data-scientist",
      title: "Data Scientist",
      department: "Engineering",
      location: "Remote",
      type: "Full-time",
      posted: "2 weeks ago",
      description: "Analyze learning patterns to help improve our platform and personalize the learning experience.",
    },
    {
      id: "community-manager",
      title: "Community Manager",
      department: "Marketing",
      location: "Remote",
      type: "Part-time",
      posted: "3 weeks ago",
      description: "Build and nurture our community of learners, facilitating discussions and gathering feedback.",
    }
  ];

  // Extract unique locations and departments
  const locations = Array.from(new Set(jobs.map(job => job.location)));
  const departments = Array.from(new Set(jobs.map(job => job.department)));

  // Filter jobs based on search, location, and department
  const filteredJobs = jobs.filter(job => {
    const matchesSearch = searchTerm === "" || 
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesLocation = locationFilter === null || job.location === locationFilter;
    const matchesDepartment = departmentFilter === null || job.department === departmentFilter;
    
    return matchesSearch && matchesLocation && matchesDepartment;
  });

  // Company values for the "Culture" tab
  const companyValues = [
    {
      title: "Mission-Driven",
      description: "We're united by our mission to make quality education accessible to everyone, regardless of their background or financial situation.",
      icon: Heart
    },
    {
      title: "Innovation",
      description: "We embrace new ideas and technologies to continuously improve our platform and reach more learners worldwide.",
      icon: Lightbulb
    },
    {
      title: "Inclusivity",
      description: "We value diverse perspectives and create an environment where everyone feels welcome and able to contribute.",
      icon: Users
    },
    {
      title: "Global Mindset",
      description: "We think globally, designing our platform and content to serve learners from different cultures and backgrounds.",
      icon: Globe
    },
    {
      title: "Growth-Oriented",
      description: "We encourage continuous learning and provide opportunities for personal and professional development.",
      icon: Rocket
    },
    {
      title: "Impact-Focused",
      description: "We measure our success by our impact on learners' lives, not just by traditional business metrics.",
      icon: BookOpen
    }
  ];

  // Benefits for the "Benefits" tab
  const benefits = [
    {
      title: "Remote-First Culture",
      description: "Work from anywhere with flexible hours that fit your life. We believe in results, not rigid schedules.",
      icon: Coffee
    },
    {
      title: "Learning Stipend",
      description: "Annual budget for courses, books, and conferences to support your professional growth.",
      icon: BookOpen
    },
    {
      title: "Competitive Compensation",
      description: "Competitive salary packages that reflect the value you bring to our mission.",
      icon: Briefcase
    },
    {
      title: "Health & Wellness",
      description: "Comprehensive health coverage and wellness programs to keep you at your best.",
      icon: Heart
    },
    {
      title: "Team Retreats",
      description: "Regular global gatherings to connect, collaborate, and celebrate our achievements.",
      icon: Users
    },
    {
      title: "Social Impact",
      description: "Work on a platform that makes a genuine difference in people's lives every day.",
      icon: Globe
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Join Our Team</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Help us make quality education accessible to everyone around the world
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <Tabs defaultValue="openings" className="mb-12">
          <TabsList className="mx-auto mb-8 w-full max-w-md">
            <TabsTrigger value="openings" className="flex-1">Open Positions</TabsTrigger>
            <TabsTrigger value="culture" className="flex-1">Our Culture</TabsTrigger>
            <TabsTrigger value="benefits" className="flex-1">Benefits</TabsTrigger>
          </TabsList>
          
          <TabsContent value="openings">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mb-8"
            >
              <h2 className="mb-6 text-2xl font-bold">Current Openings</h2>
              
              {/* Search and Filters */}
              <div className="mb-8 rounded-lg border border-gray-200 bg-white p-6 dark:border-gray-700 dark:bg-gray-800">
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="md:col-span-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                      <Input
                        type="search"
                        placeholder="Search positions..."
                        className="pl-9"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Select 
                      value={locationFilter || ""} 
                      onValueChange={(value) => setLocationFilter(value === "" ? null : value)}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Location" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Locations</SelectItem>
                        {locations.map(location => (
                          <SelectItem key={location} value={location}>{location}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Select 
                      value={departmentFilter || ""} 
                      onValueChange={(value) => setDepartmentFilter(value === "" ? null : value)}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Department" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Departments</SelectItem>
                        {departments.map(department => (
                          <SelectItem key={department} value={department}>{department}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              
              {/* Job Listings */}
              {filteredJobs.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="rounded-lg border border-dashed border-gray-300 py-16 text-center dark:border-gray-700"
                >
                  <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-800">
                    <Search className="h-6 w-6 text-gray-400" />
                  </div>
                  <h3 className="mb-2 text-lg font-medium">No positions found</h3>
                  <p className="mb-4 text-gray-500 dark:text-gray-400">
                    We couldn't find any positions matching your criteria. Try adjusting your filters or check back later.
                  </p>
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setSearchTerm("");
                      setLocationFilter(null);
                      setDepartmentFilter(null);
                    }}
                  >
                    Clear Filters
                  </Button>
                </motion.div>
              ) : (
                <div className="space-y-6">
                  {filteredJobs.map((job, index) => (
                    <motion.div
                      key={job.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 0.3 + (index * 0.1) }}
                      className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800"
                    >
                      <div className="sm:flex sm:items-start sm:justify-between">
                        <div>
                          <div className="mb-1 flex items-center">
                            <h3 className="text-xl font-semibold">
                              <Link 
                                href={`/careers/${job.id}`}
                                className="hover:text-blue-600 dark:hover:text-blue-400"
                              >
                                {job.title}
                              </Link>
                            </h3>
                            <Badge className="ml-3">{job.type}</Badge>
                          </div>
                          <div className="mb-3 flex flex-wrap items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                            <div className="flex items-center">
                              <Briefcase className="mr-1 h-4 w-4" />
                              <span>{job.department}</span>
                            </div>
                            <div className="flex items-center">
                              <MapPin className="mr-1 h-4 w-4" />
                              <span>{job.location}</span>
                            </div>
                            <div className="flex items-center">
                              <Clock className="mr-1 h-4 w-4" />
                              <span>Posted {job.posted}</span>
                            </div>
                          </div>
                          <p className="mb-4 text-gray-600 dark:text-gray-300">{job.description}</p>
                        </div>
                        <div className="mt-4 sm:mt-0">
                          <Link href={`/careers/${job.id}`}>
                            <Button className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800 sm:w-auto">
                              View Details
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="rounded-xl bg-blue-50 p-8 dark:bg-blue-950"
            >
              <div className="mx-auto max-w-3xl text-center">
                <h3 className="mb-4 text-2xl font-bold text-blue-700 dark:text-blue-300">
                  Don't See a Position That Fits?
                </h3>
                <p className="mb-6 text-blue-700 dark:text-blue-300">
                  We're always looking for talented individuals who are passionate about making education accessible. 
                  Send us your resume, and we'll keep you in mind for future opportunities.
                </p>
                <Link href="/contact">
                  <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
                    Contact Us
                  </Button>
                </Link>
              </div>
            </motion.div>
          </TabsContent>
          
          <TabsContent value="culture">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mb-8"
            >
              <h2 className="mb-4 text-2xl font-bold">Our Culture</h2>
              <p className="mx-auto mb-8 max-w-3xl text-center text-gray-700 dark:text-gray-300">
                At EduFree, we're building a team of passionate individuals who share our mission of making 
                quality education accessible to everyone. Our culture is shaped by these core values:
              </p>
              
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {companyValues.map((value, index) => (
                  <motion.div
                    key={value.title}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.3 + (index * 0.1) }}
                  >
                    <Card className="h-full transition-all duration-300 hover:shadow-md">
                      <CardContent className="p-6">
                        <div className="mb-4 flex items-center">
                          <div className="mr-4 rounded-full bg-blue-100 p-2 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400">
                            <value.icon className="h-5 w-5" />
                          </div>
                          <h3 className="text-xl font-semibold">{value.title}</h3>
                        </div>
                        <p className="text-gray-600 dark:text-gray-400">{value.description}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="rounded-xl bg-gradient-to-r from-blue-500 to-blue-700 p-8 text-white dark:from-blue-800 dark:to-blue-900"
            >
              <div className="mx-auto max-w-3xl text-center">
                <h3 className="mb-4 text-2xl font-bold">Join Our Mission</h3>
                <p className="mb-6">
                  We're a team of educators, engineers, designers, and lifelong learners working together 
                  to transform lives through education. If our mission and values resonate with you, 
                  we'd love to have you on our team.
                </p>
                <Link href="#openings">
                  <Button className="bg-white text-blue-700 hover:bg-gray-100 dark:bg-gray-900 dark:text-blue-400 dark:hover:bg-gray-800">
                    View Open Positions
                  </Button>
                </Link>
              </div>
            </motion.div>
          </TabsContent>
          
          <TabsContent value="benefits">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mb-8"
            >
              <h2 className="mb-4 text-2xl font-bold">Benefits & Perks</h2>
              <p className="mx-auto mb-8 max-w-3xl text-center text-gray-700 dark:text-gray-300">
                We believe in taking care of our team members so they can focus on our mission. 
                Here's what you can expect when you join EduFree:
              </p>
              
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {benefits.map((benefit, index) => (
                  <motion.div
                    key={benefit.title}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.3 + (index * 0.1) }}
                  >
                    <Card className="h-full transition-all duration-300 hover:shadow-md">
                      <CardContent className="p-6">
                        <div className="mb-4 flex items-center">
                          <div className="mr-4 rounded-full bg-green-100 p-2 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                            <benefit.icon className="h-5 w-5" />
                          </div>
                          <h3 className="text-xl font-semibold">{benefit.title}</h3>
                        </div>
                        <p className="text-gray-600 dark:text-gray-400">{benefit.description}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="rounded-xl bg-green-50 p-8 dark:bg-green-950"
            >
              <div className="mx-auto max-w-3xl text-center">
                <h3 className="mb-4 text-2xl font-bold text-green-700 dark:text-green-300">
                  Work With Purpose
                </h3>
                <p className="mb-6 text-green-700 dark:text-green-300">
                  Beyond competitive compensation and great benefits, EduFree offers something even more valuable: 
                  the opportunity to make a meaningful impact on people's lives through education.
                </p>
                <Link href="#openings">
                  <Button className="bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-800">
                    Explore Opportunities
                  </Button>
                </Link>
              </div>
            </motion.div>
          </TabsContent>
        </Tabs>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.9 }}
          className="mt-12 text-center"
        >
          <Link href="/about">
            <Button variant="ghost" className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300">
              <ArrowRight className="mr-2 h-4 w-4" />
              Learn More About Our Team
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  )
} 