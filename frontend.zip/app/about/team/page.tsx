"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Linkedin, Twitter, GithubIcon, Globe } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function TeamPage() {
  const leadershipTeam = [
    {
      name: "Hanamel Achumboro",
      title: "Founder & CEO",
      bio: "Hanamel founded EduFree with a vision to make quality education accessible to everyone. With a background in education technology and a passion for social impact, he leads our overall strategy and mission.",
      image: "/placeholder-user.jpg",
      social: {
        linkedin: "#",
        twitter: "#",
        website: "#"
      }
    },
    {
      name: "Sarah Johnson",
      title: "Chief Learning Officer",
      bio: "Sarah oversees our educational content and curriculum development. With 15 years of experience in curriculum design and online learning, she ensures our courses meet the highest standards of quality.",
      image: "/placeholder-user.jpg",
      social: {
        linkedin: "#",
        twitter: "#"
      }
    },
    {
      name: "Michael Chen",
      title: "Chief Technology Officer",
      bio: "Michael leads our technology team, building and maintaining our learning platform. His expertise in educational technology and AI helps us create an effective and accessible learning experience.",
      image: "/placeholder-user.jpg",
      social: {
        linkedin: "#",
        github: "#"
      }
    },
    {
      name: "Aisha Patel",
      title: "Chief Partnerships Officer",
      bio: "Aisha develops and manages our partnerships with educational institutions, organizations, and content creators. Her network and strategic approach help us expand our course offerings.",
      image: "/placeholder-user.jpg",
      social: {
        linkedin: "#",
        twitter: "#"
      }
    }
  ];

  const educationalTeam = [
    {
      name: "Dr. James Wilson",
      title: "Head of Science & Technology",
      bio: "Dr. Wilson leads our science and technology curriculum team. With a PhD in Computer Science and years of teaching experience, he ensures our technical courses are both rigorous and accessible.",
      image: "/placeholder-user.jpg"
    },
    {
      name: "Prof. Elena Rodriguez",
      title: "Head of Arts & Humanities",
      bio: "Prof. Rodriguez oversees our arts and humanities courses. Her background in comparative literature and cultural studies brings a multidisciplinary approach to our non-technical offerings.",
      image: "/placeholder-user.jpg"
    },
    {
      name: "Dr. Kwame Osei",
      title: "Head of Business & Economics",
      bio: "Dr. Osei leads our business and economics curriculum. His expertise in international economics and entrepreneurship helps us develop practical courses for aspiring business professionals.",
      image: "/placeholder-user.jpg"
    },
    {
      name: "Prof. Lin Wei",
      title: "Head of Languages",
      bio: "Prof. Wei directs our language learning programs. With expertise in linguistics and language acquisition, she develops effective methodologies for our diverse language courses.",
      image: "/placeholder-user.jpg"
    }
  ];

  const techTeam = [
    {
      name: "Raj Patel",
      title: "Lead Full-Stack Developer",
      bio: "Raj leads the development of our learning platform, focusing on creating a seamless user experience across all devices and ensuring our technology stack remains cutting-edge.",
      image: "/placeholder-user.jpg"
    },
    {
      name: "Emma Thompson",
      title: "Head of UX/UI Design",
      bio: "Emma ensures our platform is intuitive and accessible to all users. Her expertise in inclusive design helps us create an interface that works for people of all abilities.",
      image: "/placeholder-user.jpg"
    },
    {
      name: "Diego Sanchez",
      title: "Data Science Lead",
      bio: "Diego analyzes learning patterns and user behavior to help us improve our platform and personalize the learning experience for each student.",
      image: "/placeholder-user.jpg"
    },
    {
      name: "Sophia Kim",
      title: "Accessibility Specialist",
      bio: "Sophia works across teams to ensure our platform meets the highest accessibility standards, making our content available to users with diverse needs and abilities.",
      image: "/placeholder-user.jpg"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Our Team</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Meet the passionate individuals dedicated to making education accessible for everyone
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-12 text-center"
        >
          <h2 className="mb-4 text-2xl font-bold">Who We Are</h2>
          <p className="mx-auto max-w-3xl text-gray-700 dark:text-gray-300">
            We're a diverse team of educators, technologists, and lifelong learners united by our belief 
            in the transformative power of education. Coming from various backgrounds and disciplines, 
            we work together to create an accessible learning platform that serves learners worldwide.
          </p>
        </motion.div>

        <Tabs defaultValue="leadership" className="mb-16">
          <TabsList className="mx-auto mb-8 w-full max-w-md">
            <TabsTrigger value="leadership" className="flex-1">Leadership</TabsTrigger>
            <TabsTrigger value="educational" className="flex-1">Educational Team</TabsTrigger>
            <TabsTrigger value="technology" className="flex-1">Technology Team</TabsTrigger>
          </TabsList>
          
          <TabsContent value="leadership">
            <div className="grid gap-8 md:grid-cols-2">
              {leadershipTeam.map((member, index) => (
                <motion.div
                  key={member.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 + (index * 0.1) }}
                  className="rounded-lg border border-gray-200 bg-white overflow-hidden shadow-sm dark:border-gray-700 dark:bg-gray-800"
                >
                  <div className="flex flex-col md:flex-row">
                    <div className="md:w-1/3">
                      <div className="relative h-60 w-full md:h-full">
                        <Image
                          src={member.image}
                          alt={member.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                    </div>
                    <div className="flex flex-1 flex-col p-6">
                      <h3 className="text-xl font-semibold">{member.name}</h3>
                      <p className="mb-4 text-blue-600 dark:text-blue-400">{member.title}</p>
                      <p className="mb-4 text-sm text-gray-600 dark:text-gray-400">{member.bio}</p>
                      <div className="mt-auto flex space-x-2">
                        {member.social.linkedin && (
                          <a href={member.social.linkedin} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                            <Linkedin className="h-5 w-5" />
                          </a>
                        )}
                        {member.social.twitter && (
                          <a href={member.social.twitter} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-blue-500 dark:text-gray-400 dark:hover:text-blue-400">
                            <Twitter className="h-5 w-5" />
                          </a>
                        )}
                        {member.social.github && (
                          <a href={member.social.github} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white">
                            <GithubIcon className="h-5 w-5" />
                          </a>
                        )}
                        {member.social.website && (
                          <a href={member.social.website} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-purple-600 dark:text-gray-400 dark:hover:text-purple-400">
                            <Globe className="h-5 w-5" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="educational">
            <div className="grid gap-8 md:grid-cols-2">
              {educationalTeam.map((member, index) => (
                <motion.div
                  key={member.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 + (index * 0.1) }}
                  className="rounded-lg border border-gray-200 bg-white overflow-hidden shadow-sm dark:border-gray-700 dark:bg-gray-800"
                >
                  <div className="flex flex-col md:flex-row">
                    <div className="md:w-1/3">
                      <div className="relative h-60 w-full md:h-full">
                        <Image
                          src={member.image}
                          alt={member.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                    </div>
                    <div className="flex flex-1 flex-col p-6">
                      <h3 className="text-xl font-semibold">{member.name}</h3>
                      <p className="mb-4 text-green-600 dark:text-green-400">{member.title}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{member.bio}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="technology">
            <div className="grid gap-8 md:grid-cols-2">
              {techTeam.map((member, index) => (
                <motion.div
                  key={member.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 + (index * 0.1) }}
                  className="rounded-lg border border-gray-200 bg-white overflow-hidden shadow-sm dark:border-gray-700 dark:bg-gray-800"
                >
                  <div className="flex flex-col md:flex-row">
                    <div className="md:w-1/3">
                      <div className="relative h-60 w-full md:h-full">
                        <Image
                          src={member.image}
                          alt={member.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                    </div>
                    <div className="flex flex-1 flex-col p-6">
                      <h3 className="text-xl font-semibold">{member.name}</h3>
                      <p className="mb-4 text-purple-600 dark:text-purple-400">{member.title}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{member.bio}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="rounded-xl bg-blue-50 p-8 dark:bg-blue-950"
        >
          <div className="mx-auto max-w-3xl text-center">
            <h3 className="mb-4 text-2xl font-bold text-blue-700 dark:text-blue-300">
              Join Our Team
            </h3>
            <p className="mb-6 text-blue-700 dark:text-blue-300">
              We're always looking for passionate individuals who share our mission to make education accessible for all. 
              If you're interested in joining our team, check out our current openings.
            </p>
            <Link href="/careers">
              <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
                View Open Positions
              </Button>
            </Link>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.9 }}
          className="mt-12 text-center"
        >
          <Link href="/about">
            <Button variant="ghost" className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300">
              <ArrowRight className="mr-2 h-4 w-4" />
              Back to About
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  )
} 