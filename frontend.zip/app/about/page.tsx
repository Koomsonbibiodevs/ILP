"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { 
  Presentation, 
  Users, 
  Building, 
  Bookmark, 
  Briefcase, 
  Mail 
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function AboutPage() {
  const sections = [
    {
      title: "Our Mission",
      description: "Learn about our purpose and vision for accessible education",
      icon: Presentation,
      href: "/about/mission",
      color: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
    },
    {
      title: "Our Team",
      description: "Meet the passionate people behind our platform",
      icon: Users,
      href: "/about/team",
      color: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
    },
    {
      title: "Partners",
      description: "Organizations that collaborate with us to provide free education",
      icon: Building,
      href: "/about/partners",
      color: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400"
    },
    {
      title: "Blog",
      description: "Latest news and insights about education and our platform",
      icon: Bookmark,
      href: "/blog",
      color: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400"
    },
    {
      title: "Careers",
      description: "Join our team and help make education accessible for everyone",
      icon: Briefcase,
      href: "/careers",
      color: "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400"
    },
    {
      title: "Contact Us",
      description: "Get in touch with our team for questions or support",
      icon: Mail,
      href: "/contact",
      color: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">About EduFree</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Working to make high-quality education accessible to everyone, everywhere
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-12 text-center"
        >
          <h2 className="mb-4 text-2xl font-bold">Our Story</h2>
          <p className="mx-auto max-w-3xl text-gray-700 dark:text-gray-300">
            EduFree was founded in 2023 with a simple but powerful mission: to break down the barriers 
            that prevent people from accessing quality education. We believe that knowledge should be 
            freely available to everyone, regardless of their financial situation, location, or background.
          </p>
          <p className="mx-auto mt-4 max-w-3xl text-gray-700 dark:text-gray-300">
            Today, we're proud to offer hundreds of free courses created by experts and teachers from 
            around the world. Our platform continues to grow as we work towards our vision of a world 
            where quality education is truly accessible to all.
          </p>
        </motion.div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {sections.map((section, index) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 + (index * 0.1) }}
            >
              <Link href={section.href} className="block h-full">
                <Card className="h-full transition-all duration-300 hover:shadow-md">
                  <CardContent className="p-6">
                    <div className="mb-4 flex items-center">
                      <div className={`mr-4 rounded-full p-2 ${section.color}`}>
                        <section.icon className="h-5 w-5" />
                      </div>
                      <h3 className="text-xl font-semibold">{section.title}</h3>
                    </div>
                    <p className="mb-4 text-gray-600 dark:text-gray-400">{section.description}</p>
                    <div className="flex justify-end">
                      <Button variant="ghost" className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300">
                        Learn more
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="mt-16 rounded-xl bg-blue-50 p-8 dark:bg-blue-950"
        >
          <div className="mx-auto max-w-3xl text-center">
            <h3 className="mb-4 text-2xl font-bold text-blue-700 dark:text-blue-300">
              Join Our Community
            </h3>
            <p className="mb-6 text-blue-700 dark:text-blue-300">
              Become part of our global community of learners and educators. Together, we can make 
              education accessible to everyone around the world.
            </p>
            <Link href="/signup">
              <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
                Sign Up for Free
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  )
} 