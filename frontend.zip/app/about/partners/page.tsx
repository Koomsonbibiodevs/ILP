"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Globe, Building, Handshake, Users, BookOpen } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function PartnersPage() {
  const educationalPartners = [
    {
      name: "University of Professional Studies",
      description: "A leading institution providing academic expertise and curriculum development for our business and management courses.",
      logo: "/placeholder-logo.png",
      website: "#"
    },
    {
      name: "Global STEM Initiative",
      description: "An international non-profit organization helping us develop high-quality science and technology courses.",
      logo: "/placeholder-logo.png",
      website: "#"
    },
    {
      name: "Arts & Humanities Consortium",
      description: "A network of humanities scholars contributing to our arts, philosophy, and literature courses.",
      logo: "/placeholder-logo.png",
      website: "#"
    },
    {
      name: "World Language Institute",
      description: "Experts in language acquisition helping us create effective language learning courses in multiple languages.",
      logo: "/placeholder-logo.png",
      website: "#"
    }
  ];

  const technicalPartners = [
    {
      name: "CloudTech Solutions",
      description: "Providing cloud infrastructure and technical support to ensure our platform remains reliable and scalable.",
      logo: "/placeholder-logo.png",
      website: "#"
    },
    {
      name: "AccessibilityPlus",
      description: "Specialists in digital accessibility working with us to make our platform usable by people of all abilities.",
      logo: "/placeholder-logo.png",
      website: "#"
    },
    {
      name: "SecureLearn",
      description: "Cybersecurity experts ensuring the protection of our platform and user data.",
      logo: "/placeholder-logo.png",
      website: "#"
    },
    {
      name: "DataSense Analytics",
      description: "Providing data analytics tools and expertise to help us understand learning patterns and improve our platform.",
      logo: "/placeholder-logo.png",
      website: "#"
    }
  ];

  const ngoPartners = [
    {
      name: "Education For All Foundation",
      description: "Working with us to bring educational resources to underserved communities worldwide.",
      logo: "/placeholder-logo.png",
      website: "#"
    },
    {
      name: "Digital Bridge Initiative",
      description: "Helping provide technology access to communities with limited internet connectivity.",
      logo: "/placeholder-logo.png",
      website: "#"
    },
    {
      name: "Youth Empowerment Network",
      description: "Connecting young people from disadvantaged backgrounds with educational opportunities.",
      logo: "/placeholder-logo.png",
      website: "#"
    },
    {
      name: "Global Teachers Alliance",
      description: "A network of educators volunteering their expertise to create and review course content.",
      logo: "/placeholder-logo.png",
      website: "#"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Our Partners</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              The organizations and institutions helping us make education accessible for everyone
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-12 text-center"
        >
          <h2 className="mb-4 text-2xl font-bold">Collaboration for Impact</h2>
          <p className="mx-auto max-w-3xl text-gray-700 dark:text-gray-300">
            EduFree partners with educational institutions, technology companies, and non-profit organizations 
            to provide high-quality educational content and ensure our platform reaches those who need it most. 
            Our partners share our vision of making education accessible to everyone and contribute their expertise 
            to help us achieve this mission.
          </p>
        </motion.div>

        <Tabs defaultValue="educational" className="mb-16">
          <TabsList className="mx-auto mb-8 w-full max-w-md">
            <TabsTrigger value="educational" className="flex-1">Educational Partners</TabsTrigger>
            <TabsTrigger value="technical" className="flex-1">Technical Partners</TabsTrigger>
            <TabsTrigger value="ngo" className="flex-1">NGO Partners</TabsTrigger>
          </TabsList>
          
          <TabsContent value="educational">
            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {educationalPartners.map((partner, index) => (
                <motion.div
                  key={partner.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 + (index * 0.1) }}
                  className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800"
                >
                  <div className="mb-4 flex h-16 items-center justify-center">
                    <div className="relative h-16 w-32">
                      <Image
                        src={partner.logo}
                        alt={partner.name}
                        fill
                        className="object-contain"
                      />
                    </div>
                  </div>
                  <h3 className="mb-2 text-center text-lg font-semibold">{partner.name}</h3>
                  <p className="mb-4 text-sm text-gray-600 dark:text-gray-400">{partner.description}</p>
                  <div className="text-center">
                    <a 
                      href={partner.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                    >
                      <Globe className="mr-1 h-4 w-4" />
                      Visit Website
                    </a>
                  </div>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="technical">
            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {technicalPartners.map((partner, index) => (
                <motion.div
                  key={partner.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 + (index * 0.1) }}
                  className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800"
                >
                  <div className="mb-4 flex h-16 items-center justify-center">
                    <div className="relative h-16 w-32">
                      <Image
                        src={partner.logo}
                        alt={partner.name}
                        fill
                        className="object-contain"
                      />
                    </div>
                  </div>
                  <h3 className="mb-2 text-center text-lg font-semibold">{partner.name}</h3>
                  <p className="mb-4 text-sm text-gray-600 dark:text-gray-400">{partner.description}</p>
                  <div className="text-center">
                    <a 
                      href={partner.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                    >
                      <Globe className="mr-1 h-4 w-4" />
                      Visit Website
                    </a>
                  </div>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="ngo">
            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {ngoPartners.map((partner, index) => (
                <motion.div
                  key={partner.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 + (index * 0.1) }}
                  className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800"
                >
                  <div className="mb-4 flex h-16 items-center justify-center">
                    <div className="relative h-16 w-32">
                      <Image
                        src={partner.logo}
                        alt={partner.name}
                        fill
                        className="object-contain"
                      />
                    </div>
                  </div>
                  <h3 className="mb-2 text-center text-lg font-semibold">{partner.name}</h3>
                  <p className="mb-4 text-sm text-gray-600 dark:text-gray-400">{partner.description}</p>
                  <div className="text-center">
                    <a 
                      href={partner.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                    >
                      <Globe className="mr-1 h-4 w-4" />
                      Visit Website
                    </a>
                  </div>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="rounded-xl bg-blue-50 p-8 dark:bg-blue-950"
        >
          <div className="mx-auto max-w-3xl text-center">
            <h3 className="mb-4 text-2xl font-bold text-blue-700 dark:text-blue-300">
              Become a Partner
            </h3>
            <p className="mb-6 text-blue-700 dark:text-blue-300">
              If your organization shares our mission of making quality education accessible to everyone, 
              we'd love to explore partnership opportunities. Together, we can make a greater impact.
            </p>
            <Link href="/contact">
              <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
                <Handshake className="mr-2 h-5 w-5" />
                Contact Us About Partnerships
              </Button>
            </Link>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.9 }}
          className="mt-12 text-center"
        >
          <Link href="/about">
            <Button variant="ghost" className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300">
              <ArrowRight className="mr-2 h-4 w-4" />
              Back to About
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  )
} 