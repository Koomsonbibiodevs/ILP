"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Globe, BookOpen, Users, Target, Award, Lightbulb } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function MissionPage() {
  const values = [
    {
      title: "Accessibility",
      description: "Making education available to everyone, regardless of financial circumstances",
      icon: Globe,
      color: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
    },
    {
      title: "Quality",
      description: "Providing high-quality educational content created by experts in their fields",
      icon: Award,
      color: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
    },
    {
      title: "Inclusivity",
      description: "Creating an inclusive learning environment for people of all backgrounds and abilities",
      icon: Users,
      color: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400"
    },
    {
      title: "Innovation",
      description: "Constantly improving our platform to enhance the learning experience",
      icon: Lightbulb,
      color: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Our Mission</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Making quality education accessible to everyone, everywhere
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-12"
        >
          <div className="mx-auto max-w-3xl">
            <h2 className="mb-6 text-center text-3xl font-bold">Our Purpose</h2>
            <p className="mb-6 text-lg text-gray-700 dark:text-gray-300">
              At EduFree, we believe that education is a fundamental right, not a privilege. Our mission is to 
              break down the barriers that prevent people from accessing quality education and create a platform 
              where anyone can learn valuable skills, regardless of their financial situation, geographic location, 
              or background.
            </p>
            <p className="text-lg text-gray-700 dark:text-gray-300">
              We are committed to providing high-quality educational content, created by experts and experienced 
              teachers, completely free of charge. By collaborating with educational institutions, industry professionals, 
              and dedicated individuals, we've built a diverse library of courses that covers a wide range of subjects 
              and skills.
            </p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mb-20"
        >
          <div className="mx-auto max-w-3xl">
            <h2 className="mb-6 text-center text-3xl font-bold">Our Vision</h2>
            <p className="mb-6 text-lg text-gray-700 dark:text-gray-300">
              We envision a world where anyone with an internet connection can access quality education that 
              empowers them to improve their lives, support their families, and contribute to their communities. 
              We believe that education has the power to transform lives and create a more equitable society.
            </p>
            <p className="text-lg text-gray-700 dark:text-gray-300">
              By 2030, we aim to have reached over 100 million learners worldwide and to have expanded our course 
              offerings to include thousands of courses in multiple languages. We are working to make our platform 
              accessible to underserved communities by developing offline learning capabilities and partnering with 
              organizations that can provide the necessary infrastructure.
            </p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mb-20"
        >
          <h2 className="mb-10 text-center text-3xl font-bold">Our Core Values</h2>
          <div className="grid gap-8 md:grid-cols-2">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.5 + (index * 0.1) }}
                className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800"
              >
                <div className="mb-4 flex items-center">
                  <div className={`mr-4 rounded-full p-3 ${value.color}`}>
                    <value.icon className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold">{value.title}</h3>
                </div>
                <p className="text-gray-600 dark:text-gray-400">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="rounded-xl bg-blue-50 p-8 dark:bg-blue-950"
        >
          <div className="mx-auto max-w-3xl text-center">
            <h3 className="mb-4 text-2xl font-bold text-blue-700 dark:text-blue-300">
              Join Us in Our Mission
            </h3>
            <p className="mb-6 text-blue-700 dark:text-blue-300">
              Whether you're a learner, educator, or supporter, we invite you to join us in our mission to make 
              education accessible to everyone. Together, we can create a world where quality education knows no boundaries.
            </p>
            <div className="flex flex-col items-center justify-center space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0">
              <Link href="/courses">
                <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
                  Start Learning
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50 dark:border-blue-400 dark:text-blue-400 dark:hover:bg-blue-950/50">
                  Get Involved
                </Button>
              </Link>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.9 }}
          className="mt-12 text-center"
        >
          <Link href="/about">
            <Button variant="ghost" className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300">
              <ArrowRight className="mr-2 h-4 w-4" />
              Back to About
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  )
} 