"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/lib/AuthContext";
import { updateProfileImage, getUserProfile, saveUserProfile, UserProfile } from "@/lib/user-profile";
import { ProfileImageUpload } from "@/components/profile/upload-image";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/components/ui/use-toast";
import { useRouter } from "next/navigation";
import { ArrowLeft, Save } from "lucide-react";

export default function ProfileSettingsPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [formValues, setFormValues] = useState({
    displayName: "",
    bio: "",
    title: "",
    twitter: "",
    linkedin: "",
    github: "",
    website: ""
  });

  // Fetch user profile data when component loads
  useEffect(() => {
    const fetchUserProfile = async () => {
      if (user?.uid) {
        try {
          const profile = await getUserProfile(user.uid);
          if (profile) {
            setUserProfile(profile);
            setFormValues({
              displayName: profile.displayName || user.displayName || "",
              bio: profile.bio || "",
              title: profile.title || "",
              twitter: profile.socialLinks?.twitter || "",
              linkedin: profile.socialLinks?.linkedin || "",
              github: profile.socialLinks?.github || "",
              website: profile.socialLinks?.website || ""
            });
          }
        } catch (error) {
          console.error("Error fetching user profile:", error);
          toast({
            title: "Error",
            description: "Failed to load profile data",
            variant: "destructive"
          });
        }
      }
    };

    if (!loading && user) {
      fetchUserProfile();
    }
  }, [user, loading, toast]);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!loading && !user) {
      router.push("/login");
    }
  }, [user, loading, router]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormValues(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user?.uid) return;
    
    setIsSubmitting(true);
    
    try {
      // Update profile with form values
      const updatedProfile = await saveUserProfile({
        uid: user.uid,
        displayName: formValues.displayName,
        bio: formValues.bio,
        title: formValues.title,
        socialLinks: {
          twitter: formValues.twitter,
          linkedin: formValues.linkedin,
          github: formValues.github,
          website: formValues.website
        }
      });
      
      setUserProfile(updatedProfile);
      
      toast({
        title: "Profile Updated",
        description: "Your profile has been successfully updated"
      });
    } catch (error) {
      console.error("Error updating profile:", error);
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleImageUploaded = async (imageUrl: string, publicId: string) => {
    if (!user?.uid) return;
    
    try {
      const updatedProfile = await updateProfileImage(user.uid, imageUrl, publicId);
      if (updatedProfile) {
        setUserProfile(updatedProfile);
      }
    } catch (error) {
      console.error("Error updating profile image in database:", error);
      toast({
        title: "Error",
        description: "Failed to save profile image to your account",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <div className="container flex min-h-[calc(100vh-4rem)] max-w-screen-xl flex-col items-center justify-center px-4 py-8">
        <p>Loading...</p>
      </div>
    );
  }

  if (!user) {
    return null; // This will be handled by the useEffect redirect
  }

  return (
    <div className="container flex min-h-[calc(100vh-4rem)] max-w-screen-xl flex-col px-4 py-8">
      <div className="mb-6">
        <Button 
          variant="ghost" 
          onClick={() => router.push("/profile")}
          className="pl-0"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Profile
        </Button>
      </div>
      
      <div className="flex flex-col items-center space-y-2 text-center mb-8">
        <h1 className="text-3xl font-bold">Profile Settings</h1>
        <p className="text-sm text-muted-foreground">
          Update your profile information and preferences
        </p>
      </div>
      
      <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
        {/* Profile Image Section */}
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Profile Image</CardTitle>
            <CardDescription>
              Upload a profile picture to personalize your account
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ProfileImageUpload 
              userId={user.uid}
              currentImageUrl={userProfile?.photoURL || user.photoURL}
              onImageUploaded={handleImageUploaded}
            />
          </CardContent>
        </Card>
        
        {/* Profile Information Section */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
            <CardDescription>
              Update your personal details and biography
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="displayName">Display Name</Label>
                    <Input
                      id="displayName"
                      name="displayName"
                      value={formValues.displayName}
                      onChange={handleInputChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="title">Title / Position</Label>
                    <Input
                      id="title"
                      name="title"
                      placeholder="e.g. Software Engineer, Student"
                      value={formValues.title}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="bio">Biography</Label>
                  <Textarea
                    id="bio"
                    name="bio"
                    placeholder="Tell us about yourself"
                    className="min-h-[120px]"
                    value={formValues.bio}
                    onChange={handleInputChange}
                  />
                </div>
                
                <Separator className="my-6" />
                
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Social Links</h3>
                  <p className="text-sm text-muted-foreground">
                    Connect your social media accounts
                  </p>
                </div>
                
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="twitter">Twitter</Label>
                    <Input
                      id="twitter"
                      name="twitter"
                      placeholder="https://twitter.com/username"
                      value={formValues.twitter}
                      onChange={handleInputChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="linkedin">LinkedIn</Label>
                    <Input
                      id="linkedin"
                      name="linkedin"
                      placeholder="https://linkedin.com/in/username"
                      value={formValues.linkedin}
                      onChange={handleInputChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="github">GitHub</Label>
                    <Input
                      id="github"
                      name="github"
                      placeholder="https://github.com/username"
                      value={formValues.github}
                      onChange={handleInputChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="website">Personal Website</Label>
                    <Input
                      id="website"
                      name="website"
                      placeholder="https://example.com"
                      value={formValues.website}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
              </div>
              
              <Button 
                type="submit" 
                className="w-full"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>Saving Changes...</>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Changes
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
} 