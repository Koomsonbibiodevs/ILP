"use client";

import { useAuth } from "@/lib/AuthContext";
import { logOut } from "@/lib/firebase";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { Settings } from "lucide-react";

export default function ProfilePage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login");
    }
  }, [user, loading, router]);

  const handleLogout = async () => {
    await logOut();
    router.push("/login");
  };

  const handleSettingsClick = () => {
    router.push("/profile/settings");
  };

  if (loading) {
    return (
      <div className="container flex min-h-[calc(100vh-4rem)] max-w-screen-xl flex-col items-center justify-center px-4 py-8">
        <p>Loading...</p>
      </div>
    );
  }

  if (!user) {
    return null; // This will be handled by the useEffect redirect
  }

  return (
    <div className="container flex min-h-[calc(100vh-4rem)] max-w-screen-xl flex-col items-center justify-center px-4 py-8 md:py-16">
      <div className="mx-auto flex w-full flex-col justify-center space-y-6 sm:w-[500px]">
        <div className="flex flex-col items-center space-y-2 text-center">
          <h1 className="text-3xl font-bold">Your Profile</h1>
          <p className="text-sm text-muted-foreground">
            View and manage your account details
          </p>
        </div>

        <Card>
          <CardHeader className="space-y-1">
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl font-bold">Account Information</CardTitle>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleSettingsClick}
                className="flex items-center gap-1"
              >
                <Settings className="h-4 w-4" />
                <span>Settings</span>
              </Button>
            </div>
            <CardDescription>
              Your personal information and preferences
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col space-y-2">
              {user.photoURL && (
                <div className="mb-4 flex justify-center">
                  <img 
                    src={user.photoURL} 
                    alt="Profile" 
                    className="h-24 w-24 rounded-full"
                  />
                </div>
              )}
              <div>
                <p className="text-sm font-medium text-muted-foreground">Name</p>
                <p className="text-base">{user.displayName || "Not provided"}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Email</p>
                <p className="text-base">{user.email}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Account Created</p>
                <p className="text-base">{user.metadata.creationTime ? new Date(user.metadata.creationTime).toLocaleDateString() : "Unknown"}</p>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              variant="destructive" 
              className="w-full" 
              onClick={handleLogout}
            >
              Log Out
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
} 