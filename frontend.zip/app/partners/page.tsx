"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from "@/components/ui/tabs"
import { ExternalLink, MoveRight } from "lucide-react"

export default function PartnersPage() {
  // Partner categories
  const educationalPartners = [
    {
      name: "University of Lagos",
      description: "Collaborating on curriculum development and accreditation for higher education courses.",
      logo: "/images/partners/unilag.png",
      website: "https://unilag.edu.ng"
    },
    {
      name: "Strathmore University",
      description: "Partnering on technology and business courses with certification pathways.",
      logo: "/images/partners/strathmore.png",
      website: "https://strathmore.edu"
    },
    {
      name: "University of Cape Town",
      description: "Collaborating on STEM education and research methodology courses.",
      logo: "/images/partners/uct.png",
      website: "https://www.uct.ac.za"
    },
    {
      name: "African Leadership Academy",
      description: "Working together on leadership development and entrepreneurship programs.",
      logo: "/images/partners/ala.png",
      website: "https://www.africanleadershipacademy.org"
    },
    {
      name: "Ghana Education Service",
      description: "Aligning our K-12 curriculum with national educational standards.",
      logo: "/images/partners/ges.png",
      website: "https://ges.gov.gh"
    },
    {
      name: "AIMS Africa",
      description: "Partnering on advanced mathematics and data science education.",
      logo: "/images/partners/aims.png",
      website: "https://aims.ac.za"
    }
  ]

  const corporatePartners = [
    {
      name: "Microsoft",
      description: "Providing cloud infrastructure, technical resources, and digital literacy programs.",
      logo: "/images/partners/microsoft.png",
      website: "https://www.microsoft.com"
    },
    {
      name: "MTN Group",
      description: "Supporting zero-rated data access for our platform across multiple African countries.",
      logo: "/images/partners/mtn.png",
      website: "https://www.mtn.com"
    },
    {
      name: "Safaricom",
      description: "Facilitating mobile payment integration and connectivity solutions in East Africa.",
      logo: "/images/partners/safaricom.png",
      website: "https://www.safaricom.co.ke"
    },
    {
      name: "Andela",
      description: "Collaborating on software development courses and employment pathways.",
      logo: "/images/partners/andela.png",
      website: "https://andela.com"
    },
    {
      name: "Google.org",
      description: "Supporting expansion of computer science education across Africa.",
      logo: "/images/partners/google.png",
      website: "https://www.google.org"
    },
    {
      name: "Flutterwave",
      description: "Providing payment infrastructure for our premium courses and certification programs.",
      logo: "/images/partners/flutterwave.png",
      website: "https://flutterwave.com"
    }
  ]

  const ngoPartners = [
    {
      name: "UNESCO",
      description: "Collaborating on educational policy and expanding access to quality education.",
      logo: "/images/partners/unesco.png",
      website: "https://en.unesco.org"
    },
    {
      name: "Mastercard Foundation",
      description: "Supporting scholarship programs and digital skills development for young Africans.",
      logo: "/images/partners/mastercard-foundation.png",
      website: "https://mastercardfdn.org"
    },
    {
      name: "African Development Bank",
      description: "Funding infrastructure development and scaling operations across the continent.",
      logo: "/images/partners/afdb.png",
      website: "https://www.afdb.org"
    },
    {
      name: "Gates Foundation",
      description: "Supporting our health education curriculum and community health worker training programs.",
      logo: "/images/partners/gates.png",
      website: "https://www.gatesfoundation.org"
    },
    {
      name: "UNICEF",
      description: "Collaborating on child-friendly educational content and child safety practices.",
      logo: "/images/partners/unicef.png",
      website: "https://www.unicef.org"
    },
    {
      name: "Ford Foundation",
      description: "Supporting cultural heritage and arts education programs across the platform.",
      logo: "/images/partners/ford.png",
      website: "https://www.fordfoundation.org"
    }
  ]

  const governmentPartners = [
    {
      name: "Ministry of Education, Kenya",
      description: "Integrating our platform with national education initiatives and curriculum standards.",
      logo: "/images/partners/kenya-moe.png",
      website: "https://www.education.go.ke"
    },
    {
      name: "Nigeria Communications Commission",
      description: "Facilitating regulatory approval and telecommunications partnerships for greater access.",
      logo: "/images/partners/ncc.png",
      website: "https://www.ncc.gov.ng"
    },
    {
      name: "Rwanda ICT Ministry",
      description: "Collaborating on digital literacy initiatives and tech innovation programs.",
      logo: "/images/partners/rwanda-ict.png",
      website: "https://www.minict.gov.rw"
    },
    {
      name: "African Union",
      description: "Working together on continent-wide educational standards and certification recognition.",
      logo: "/images/partners/au.png",
      website: "https://au.int"
    },
    {
      name: "South Africa Department of Basic Education",
      description: "Aligning our content with national curriculum standards and supplementary resources.",
      logo: "/images/partners/sa-education.png",
      website: "https://www.education.gov.za"
    },
    {
      name: "Ghana Ministry of Education",
      description: "Supporting teacher training programs and educational technology integration.",
      logo: "/images/partners/ghana-moe.png",
      website: "https://moe.gov.gh"
    }
  ]

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-green-600 dark:bg-green-900">
        <div className="absolute inset-0 bg-gradient-to-r from-green-600 to-green-800 opacity-90 dark:from-green-900 dark:to-green-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Our Partners</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              We work with a diverse network of educational institutions, corporations, 
              NGOs, and government agencies to expand access to quality education across Africa.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-3xl font-bold">Strategic Partnerships</h2>
          <p className="mx-auto max-w-3xl text-gray-600 dark:text-gray-400">
            Partnerships are at the core of our mission. By working together with 
            organizations across sectors, we can create more impactful educational 
            solutions and reach learners in every corner of Africa.
          </p>
        </div>

        <Tabs defaultValue="educational" className="mb-16">
          <TabsList className="mx-auto mb-8 w-full max-w-2xl">
            <TabsTrigger value="educational" className="flex-1">Educational Institutions</TabsTrigger>
            <TabsTrigger value="corporate" className="flex-1">Corporate Partners</TabsTrigger>
            <TabsTrigger value="ngo" className="flex-1">NGOs & Foundations</TabsTrigger>
            <TabsTrigger value="government" className="flex-1">Government</TabsTrigger>
          </TabsList>
          
          <TabsContent value="educational">
            <div className="mb-8 text-center">
              <h3 className="mb-4 text-2xl font-bold">Educational Institution Partners</h3>
              <p className="mx-auto max-w-3xl text-gray-600 dark:text-gray-400">
                We partner with leading universities, schools, and educational organizations 
                to develop high-quality curriculum and provide recognized certifications.
              </p>
            </div>
            
            <motion.div 
              variants={container}
              initial="hidden"
              animate="show"
              className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
            >
              {educationalPartners.map((partner, index) => (
                <motion.div key={index} variants={item}>
                  <Card className="h-full">
                    <CardHeader className="pb-4">
                      <div className="mb-4 h-16 relative">
                        <Image 
                          src={partner.logo}
                          alt={`${partner.name} logo`}
                          fill
                          className="object-contain"
                        />
                      </div>
                      <CardTitle>{partner.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 dark:text-gray-400">{partner.description}</p>
                    </CardContent>
                    <CardFooter>
                      <a 
                        href={partner.website} 
                        target="_blank" 
                        rel="noreferrer"
                        className="inline-flex items-center text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300"
                      >
                        Visit website <ExternalLink className="ml-2 h-4 w-4" />
                      </a>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="corporate">
            <div className="mb-8 text-center">
              <h3 className="mb-4 text-2xl font-bold">Corporate Partners</h3>
              <p className="mx-auto max-w-3xl text-gray-600 dark:text-gray-400">
                Our corporate partners provide technical infrastructure, funding, and 
                industry expertise to ensure our platform delivers relevant skills for 
                today's workforce.
              </p>
            </div>
            
            <motion.div 
              variants={container}
              initial="hidden"
              animate="show"
              className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
            >
              {corporatePartners.map((partner, index) => (
                <motion.div key={index} variants={item}>
                  <Card className="h-full">
                    <CardHeader className="pb-4">
                      <div className="mb-4 h-16 relative">
                        <Image 
                          src={partner.logo}
                          alt={`${partner.name} logo`}
                          fill
                          className="object-contain"
                        />
                      </div>
                      <CardTitle>{partner.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 dark:text-gray-400">{partner.description}</p>
                    </CardContent>
                    <CardFooter>
                      <a 
                        href={partner.website} 
                        target="_blank" 
                        rel="noreferrer"
                        className="inline-flex items-center text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300"
                      >
                        Visit website <ExternalLink className="ml-2 h-4 w-4" />
                      </a>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="ngo">
            <div className="mb-8 text-center">
              <h3 className="mb-4 text-2xl font-bold">NGO & Foundation Partners</h3>
              <p className="mx-auto max-w-3xl text-gray-600 dark:text-gray-400">
                We collaborate with foundations and non-governmental organizations to 
                expand our reach to underserved communities and develop specialized programs.
              </p>
            </div>
            
            <motion.div 
              variants={container}
              initial="hidden"
              animate="show"
              className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
            >
              {ngoPartners.map((partner, index) => (
                <motion.div key={index} variants={item}>
                  <Card className="h-full">
                    <CardHeader className="pb-4">
                      <div className="mb-4 h-16 relative">
                        <Image 
                          src={partner.logo}
                          alt={`${partner.name} logo`}
                          fill
                          className="object-contain"
                        />
                      </div>
                      <CardTitle>{partner.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 dark:text-gray-400">{partner.description}</p>
                    </CardContent>
                    <CardFooter>
                      <a 
                        href={partner.website} 
                        target="_blank" 
                        rel="noreferrer"
                        className="inline-flex items-center text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300"
                      >
                        Visit website <ExternalLink className="ml-2 h-4 w-4" />
                      </a>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="government">
            <div className="mb-8 text-center">
              <h3 className="mb-4 text-2xl font-bold">Government Partners</h3>
              <p className="mx-auto max-w-3xl text-gray-600 dark:text-gray-400">
                Our partnerships with government agencies help us align our curriculum with 
                national standards and integrate with public education systems across Africa.
              </p>
            </div>
            
            <motion.div 
              variants={container}
              initial="hidden"
              animate="show"
              className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
            >
              {governmentPartners.map((partner, index) => (
                <motion.div key={index} variants={item}>
                  <Card className="h-full">
                    <CardHeader className="pb-4">
                      <div className="mb-4 h-16 relative">
                        <Image 
                          src={partner.logo}
                          alt={`${partner.name} logo`}
                          fill
                          className="object-contain"
                        />
                      </div>
                      <CardTitle>{partner.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 dark:text-gray-400">{partner.description}</p>
                    </CardContent>
                    <CardFooter>
                      <a 
                        href={partner.website} 
                        target="_blank" 
                        rel="noreferrer"
                        className="inline-flex items-center text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300"
                      >
                        Visit website <ExternalLink className="ml-2 h-4 w-4" />
                      </a>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
        
        {/* Partnership Process Section */}
        <div className="mb-16 rounded-xl bg-white p-8 shadow-sm dark:bg-gray-800">
          <div className="mb-8 text-center">
            <h2 className="mb-4 text-2xl font-bold">Partnership Process</h2>
            <p className="mx-auto max-w-3xl text-gray-600 dark:text-gray-400">
              We welcome new partnerships that align with our mission of expanding 
              access to quality education across Africa. Here's how our partnership 
              process works:
            </p>
          </div>
          
          <div className="grid gap-6 md:grid-cols-4">
            <div className="text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900/50 dark:text-green-400">
                <span className="text-2xl font-bold">1</span>
              </div>
              <h3 className="mb-2 text-lg font-semibold">Initial Conversation</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We start with an exploratory conversation to understand shared goals and potential alignment.
              </p>
            </div>
            
            <div className="text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900/50 dark:text-green-400">
                <span className="text-2xl font-bold">2</span>
              </div>
              <h3 className="mb-2 text-lg font-semibold">Needs Assessment</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We work together to identify specific needs, resources, and opportunities for collaboration.
              </p>
            </div>
            
            <div className="text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900/50 dark:text-green-400">
                <span className="text-2xl font-bold">3</span>
              </div>
              <h3 className="mb-2 text-lg font-semibold">Partnership Agreement</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We formalize our partnership with clear goals, responsibilities, and success metrics.
              </p>
            </div>
            
            <div className="text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900/50 dark:text-green-400">
                <span className="text-2xl font-bold">4</span>
              </div>
              <h3 className="mb-2 text-lg font-semibold">Implementation & Growth</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We execute our partnership plan with regular check-ins and adapt as we grow together.
              </p>
            </div>
          </div>
        </div>
        
        {/* CTA Section */}
        <div className="bg-gradient-to-r from-green-600 to-green-800 p-8 rounded-xl text-white dark:from-green-800 dark:to-green-900">
          <div className="text-center">
            <h3 className="mb-4 text-2xl font-bold">Become a Partner</h3>
            <p className="mx-auto mb-6 max-w-3xl">
              Are you interested in partnering with us to expand access to quality education across Africa? 
              We're always looking for organizations that share our vision and can help us create greater impact.
            </p>
            <Link href="/contact">
              <Button className="bg-white text-green-700 hover:bg-green-50">
                Get in Touch <MoveRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
        
        {/* Testimonials Section */}
        <div className="mt-16">
          <div className="mb-8 text-center">
            <h2 className="mb-4 text-3xl font-bold">Partner Testimonials</h2>
            <p className="mx-auto max-w-3xl text-gray-600 dark:text-gray-400">
              Hear what our partners have to say about working with us.
            </p>
          </div>
          
          <div className="grid gap-8 md:grid-cols-3">
            <div className="rounded-xl bg-white p-6 shadow-sm dark:bg-gray-800">
              <div className="mb-4 flex justify-center">
                <div className="h-16 w-16 relative">
                  <Image 
                    src="/images/partners/uct.png"
                    alt="University of Cape Town logo"
                    fill
                    className="object-contain"
                  />
                </div>
              </div>
              <p className="mb-4 text-gray-600 dark:text-gray-400">
                "Our partnership has allowed us to extend our teaching beyond physical 
                classrooms, reaching students across the continent who wouldn't otherwise 
                have access to university-level education."
              </p>
              <div className="text-center">
                <p className="font-semibold">Dr. Thabo Msibi</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Dean of Education, University of Cape Town</p>
              </div>
            </div>
            
            <div className="rounded-xl bg-white p-6 shadow-sm dark:bg-gray-800">
              <div className="mb-4 flex justify-center">
                <div className="h-16 w-16 relative">
                  <Image 
                    src="/images/partners/microsoft.png"
                    alt="Microsoft logo"
                    fill
                    className="object-contain"
                  />
                </div>
              </div>
              <p className="mb-4 text-gray-600 dark:text-gray-400">
                "This partnership aligns perfectly with our mission of empowering every 
                person and organization on the planet to achieve more. The platform is 
                making quality education accessible in ways we've never seen before."
              </p>
              <div className="text-center">
                <p className="font-semibold">Sarah Johnson</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Director of Education Partnerships, Microsoft Africa</p>
              </div>
            </div>
            
            <div className="rounded-xl bg-white p-6 shadow-sm dark:bg-gray-800">
              <div className="mb-4 flex justify-center">
                <div className="h-16 w-16 relative">
                  <Image 
                    src="/images/partners/mastercard-foundation.png"
                    alt="Mastercard Foundation logo"
                    fill
                    className="object-contain"
                  />
                </div>
              </div>
              <p className="mb-4 text-gray-600 dark:text-gray-400">
                "Working together has enabled us to develop innovative approaches to 
                education that are truly designed for the African context. The results 
                we're seeing in terms of student engagement and outcomes are remarkable."
              </p>
              <div className="text-center">
                <p className="font-semibold">Daniel Otieno</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Program Director, Mastercard Foundation</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
} 