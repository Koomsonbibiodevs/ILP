"use client"

import React, { useState, useEffect, use } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { useAuth } from "@/lib/AuthContext"
import {
  BookOpen,
  Calendar,
  ChevronLeft,
  Clock,
  Download,
  FileText,
  List,
  MessageCircle,
  Play,
  Star,
  Users,
  UserCheck,
  LogIn,
  Check,
  Loader2,
  Book,
  X,
  GraduationCap,
  PlayCircle,
  FileQuestion,
  MessageSquare,
  Lightbulb,
  PenLine,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { allCourses, Course } from "@/data/courses"
import { toast } from "@/components/ui/use-toast"
import { enrollUserInCourse } from "@/lib/firestore"
import { CourseReviewDialog } from "@/components/course-review-dialog"
import Image from "next/image"

export default function CourseDetailPage({ params }: { params: { id: string } }) {
  const courseParams = use(params)
  const courseId = courseParams.id
  const router = useRouter()
  const { user, loading } = useAuth()
  const [activeTab, setActiveTab] = useState("overview")
  const [isEnrolled, setIsEnrolled] = useState(false)
  const [enrolling, setEnrolling] = useState(false)
  const [previewLesson, setPreviewLesson] = useState<null | {
    title: string;
    type: string;
    content?: string;
    duration: string;
    thumbnail?: string;
    videoUrl?: string;
  }>(null)
  const [isPreviewOpen, setIsPreviewOpen] = useState(false)
  const [isReviewOpen, setIsReviewOpen] = useState(false)
  
  // Added state for download notification
  const [downloadNotification, setDownloadNotification] = useState<{
    show: boolean;
    message: string;
    isLoading: boolean;
    resourceName: string;
  } | null>(null);
  
  const [expandedSections, setExpandedSections] = useState<string[]>([])

  // Find the course based on the route parameter
  const course = allCourses.find(course => course.id === courseId) || {
    id: "not-found",
    title: "Course Not Found",
    description: "The course you're looking for doesn't exist or has been removed.",
    category: "Unknown",
    level: "Beginner",
    duration: "Unknown",
    students: 0,
    rating: 0,
    instructor: {
      id: "unknown",
      name: "Unknown Instructor",
      title: "Instructor",
      bio: "No information available about this instructor.",
      image: "/placeholder-user.jpg",
    },
    image: "/course-placeholder.jpg",
    modules: [],
    features: ["No features available"],
  } as Course;

  // Check if user is enrolled in this course
  useEffect(() => {
    if (!loading && user) {
      // Check localStorage first as a backup
      try {
        const userSpecificKey = `enrolledCourses_${user.uid}`
        const storedEnrolledCourses = localStorage.getItem(userSpecificKey)
        
        if (storedEnrolledCourses) {
          const enrolledCourseIds = JSON.parse(storedEnrolledCourses)
          setIsEnrolled(enrolledCourseIds.includes(courseId))
        } else {
          setIsEnrolled(false)
        }
      } catch (err) {
        console.error('Error checking enrollment status:', err)
        setIsEnrolled(false)
      }
    }
  }, [courseId, user, loading])

  // Mock enrolled course IDs for demo purposes
  const mockEnrolledCourseIds = ["javascript-advanced", "python-basics", "ux-fundamentals"]
  
  // Course enrollment handler
  const handleEnroll = async () => {
    if (!user) {
      router.push("/login")
      return
    }
    
    setEnrolling(true)
    
    try {
      // Enroll user in Firebase
      await enrollUserInCourse(user.uid, courseId)
      
      // Update UI state
      setIsEnrolled(true)
      
      // Show success notification
      toast({
        title: "Enrolled Successfully",
        description: `You are now enrolled in ${course.title}`,
      })
    } catch (error) {
      console.error('Error enrolling in course:', error)
      toast({
        title: "Enrollment Failed",
        description: "There was an error enrolling in this course. Please try again.",
        variant: "destructive"
      })
    } finally {
      setEnrolling(false)
    }
  }

  const openPreview = (lesson: any) => {
    // Generate topic-specific content based on lesson title and type
    const enhancedLesson = {
      ...lesson,
      content: generateLessonContent(lesson.title, lesson.type),
      thumbnail: getLessonThumbnail(lesson.title, lesson.type),
      videoUrl: getLessonVideoUrl(lesson.title, lesson.type)
    }
    setPreviewLesson(enhancedLesson)
    setIsPreviewOpen(true)
  }

  // Generate topic-specific content based on lesson title and type
  const generateLessonContent = (title: string, type: string): string => {
    // HTML content
    if (title.toLowerCase().includes('html')) {
      if (type.toLowerCase() === 'video') {
        return `
          <h2>HTML Fundamentals</h2>
          <p>This video lesson covers the essential building blocks of HTML that form the foundation of all web pages.</p>
          
          <h3>What You'll Learn</h3>
          <ul>
            <li>Understanding HTML document structure</li>
            <li>Working with semantic HTML elements</li>
            <li>Creating accessible markup</li>
            <li>Best practices for modern HTML development</li>
          </ul>
          
          <p>By the end of this lesson, you'll be able to create well-structured HTML documents that follow modern web standards.</p>
        `;
      } else if (type.toLowerCase() === 'quiz') {
        return `
          <h2>HTML Knowledge Check</h2>
          <p>Test your understanding of HTML concepts with this interactive quiz.</p>
          
          <h3>Quiz Topics</h3>
          <ul>
            <li>HTML document structure</li>
            <li>Semantic elements</li>
            <li>Forms and input validation</li>
            <li>Accessibility attributes</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'exercise') {
        return `
          <h2>HTML Coding Exercise</h2>
          <p>Apply your HTML knowledge by completing this hands-on coding exercise.</p>
          
          <h3>Exercise Requirements</h3>
          <p>Create a responsive webpage that includes:</p>
          <ul>
            <li>Proper document structure</li>
            <li>Navigation menu</li>
            <li>Content sections with appropriate semantic elements</li>
            <li>A contact form with validation</li>
            <li>Accessible markup with ARIA attributes where needed</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'reading') {
        return `
          <h2>HTML Essential Reading</h2>
          <p>This comprehensive reading material covers HTML fundamentals and best practices.</p>
          
          <h3>Reading Topics</h3>
          <ul>
            <li>HTML5 semantic structure</li>
            <li>Accessibility and ARIA roles</li>
            <li>HTML forms and validation</li>
            <li>SEO-friendly markup techniques</li>
          </ul>
          
          <p>This reading will provide you with a solid foundation in modern HTML development.</p>
        `;
      }
    }
    // CSS content
    else if (title.toLowerCase().includes('css')) {
      if (type.toLowerCase() === 'video') {
        return `
          <h2>CSS Styling Techniques</h2>
          <p>This video explores modern CSS styling techniques for creating beautiful, responsive websites.</p>
          
          <h3>What You'll Learn</h3>
          <ul>
            <li>CSS selectors and specificity</li>
            <li>Flexbox and Grid layout systems</li>
            <li>Responsive design principles</li>
            <li>CSS animations and transitions</li>
          </ul>
          
          <p>Master these CSS concepts to take your web designs to the next level.</p>
        `;
      } else if (type.toLowerCase() === 'quiz') {
        return `
          <h2>CSS Mastery Quiz</h2>
          <p>Test your CSS knowledge with questions covering both basic and advanced concepts.</p>
          
          <h3>Quiz Topics</h3>
          <ul>
            <li>Selectors and specificity</li>
            <li>Box model and positioning</li>
            <li>Flexbox and Grid layouts</li>
            <li>Media queries and responsive design</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'exercise') {
        return `
          <h2>CSS Styling Challenge</h2>
          <p>Apply your CSS skills to transform a plain HTML page into a visually appealing design.</p>
          
          <h3>Exercise Requirements</h3>
          <ul>
            <li>Create a responsive layout using Flexbox or Grid</li>
            <li>Implement a color scheme and typography system</li>
            <li>Add hover effects and transitions</li>
            <li>Ensure the design works on mobile, tablet, and desktop</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'reading') {
        return `
          <h2>CSS In-Depth Reading</h2>
          <p>This comprehensive reading material covers modern CSS techniques and best practices.</p>
          
          <h3>Reading Topics</h3>
          <ul>
            <li>CSS architecture and organization</li>
            <li>Advanced responsive design techniques</li>
            <li>CSS custom properties and calculations</li>
            <li>Performance optimization strategies</li>
          </ul>
          
          <p>This reading will help you master the art of CSS styling for modern web applications.</p>
        `;
      }
    }
    // JavaScript content
    else if (title.toLowerCase().includes('javascript') || title.toLowerCase().includes('js')) {
      if (type.toLowerCase() === 'video') {
        return `
          <h2>JavaScript Programming Concepts</h2>
          <p>This video covers essential JavaScript concepts for building interactive web applications.</p>
          
          <h3>What You'll Learn</h3>
          <ul>
            <li>Variables, data types, and functions</li>
            <li>DOM manipulation and event handling</li>
            <li>Asynchronous JavaScript with Promises</li>
            <li>Modern ES6+ features</li>
          </ul>
          
          <p>By the end of this lesson, you'll understand how to write clean, efficient JavaScript code.</p>
        `;
      } else if (type.toLowerCase() === 'quiz') {
        return `
          <h2>JavaScript Comprehension Quiz</h2>
          <p>Test your understanding of JavaScript fundamentals and advanced concepts.</p>
          
          <h3>Quiz Topics</h3>
          <ul>
            <li>Scope and closures</li>
            <li>Asynchronous programming</li>
            <li>Object-oriented JavaScript</li>
            <li>Error handling and debugging</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'exercise') {
        return `
          <h2>JavaScript Coding Challenge</h2>
          <p>Put your JavaScript skills to the test with this interactive coding challenge.</p>
          
          <h3>Exercise Requirements</h3>
          <ul>
            <li>Build a small interactive application</li>
            <li>Implement event listeners and DOM manipulation</li>
            <li>Use modern JavaScript syntax (ES6+)</li>
            <li>Handle potential errors gracefully</li>
            <li>Optimize for performance</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'reading') {
        return `
          <h2>JavaScript Deep Dive</h2>
          <p>This comprehensive reading material explores JavaScript concepts in depth.</p>
          
          <h3>Reading Topics</h3>
          <ul>
            <li>JavaScript engine internals</li>
            <li>Functional programming patterns</li>
            <li>Advanced asynchronous patterns</li>
            <li>Memory management and optimization</li>
          </ul>
          
          <p>This reading will take your JavaScript knowledge to an advanced level.</p>
        `;
      }
    }
    // React content
    else if (title.toLowerCase().includes('react')) {
      if (type.toLowerCase() === 'video') {
        return `
          <h2>React Component Development</h2>
          <p>This video explores React component architecture and best practices for building modern UIs.</p>
          
          <h3>What You'll Learn</h3>
          <ul>
            <li>Component lifecycle and hooks</li>
            <li>State management techniques</li>
            <li>Context API and Redux</li>
            <li>Performance optimization</li>
          </ul>
          
          <p>Master these React concepts to build scalable, maintainable front-end applications.</p>
        `;
      } else if (type.toLowerCase() === 'quiz') {
        return `
          <h2>React Fundamentals Quiz</h2>
          <p>Test your understanding of React core concepts and patterns.</p>
          
          <h3>Quiz Topics</h3>
          <ul>
            <li>Component architecture</li>
            <li>Hooks and state management</li>
            <li>Context and props drilling</li>
            <li>React performance optimization</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'exercise') {
        return `
          <h2>React Application Challenge</h2>
          <p>Build a small React application to demonstrate your understanding of React fundamentals.</p>
          
          <h3>Exercise Requirements</h3>
          <ul>
            <li>Create multiple functional components with hooks</li>
            <li>Implement state management</li>
            <li>Handle user interactions and form inputs</li>
            <li>Apply proper component composition</li>
            <li>Add basic styling with CSS-in-JS or CSS modules</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'reading') {
        return `
          <h2>React Advanced Patterns</h2>
          <p>This comprehensive reading material covers advanced React patterns and techniques.</p>
          
          <h3>Reading Topics</h3>
          <ul>
            <li>Advanced hooks and custom hook patterns</li>
            <li>React performance optimization techniques</li>
            <li>State management architecture</li>
            <li>Testing strategies for React applications</li>
          </ul>
          
          <p>This reading will help you master advanced React concepts for building complex applications.</p>
        `;
      }
    }
    // Python content
    else if (title.toLowerCase().includes('python')) {
      if (type.toLowerCase() === 'video') {
        return `
          <h2>Python Programming Fundamentals</h2>
          <p>This video introduces key Python concepts and programming techniques.</p>
          
          <h3>What You'll Learn</h3>
          <ul>
            <li>Python syntax and data structures</li>
            <li>Functions and object-oriented programming</li>
            <li>Working with libraries and packages</li>
            <li>File handling and data processing</li>
          </ul>
          
          <p>By the end of this lesson, you'll be able to write efficient Python code for various applications.</p>
        `;
      } else if (type.toLowerCase() === 'quiz') {
        return `
          <h2>Python Knowledge Assessment</h2>
          <p>Test your understanding of Python programming concepts.</p>
          
          <h3>Quiz Topics</h3>
          <ul>
            <li>Data types and structures</li>
            <li>Functions and modules</li>
            <li>Object-oriented programming</li>
            <li>Error handling and debugging</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'exercise') {
        return `
          <h2>Python Coding Exercise</h2>
          <p>Apply your Python skills with this hands-on programming exercise.</p>
          
          <h3>Exercise Requirements</h3>
          <ul>
            <li>Implement a Python program to solve a specific problem</li>
            <li>Use appropriate data structures and algorithms</li>
            <li>Handle edge cases and errors</li>
            <li>Write clean, well-documented code</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'reading') {
        return `
          <h2>Python In-Depth Guide</h2>
          <p>This comprehensive reading material covers Python programming in detail.</p>
          
          <h3>Reading Topics</h3>
          <ul>
            <li>Advanced Python features</li>
            <li>Performance optimization techniques</li>
            <li>Python for data science and analysis</li>
            <li>Building applications with Python</li>
          </ul>
          
          <p>This reading will deepen your understanding of Python programming concepts.</p>
        `;
      }
    }
    // Data Science content
    else if (title.toLowerCase().includes('data') || title.toLowerCase().includes('analytics')) {
      if (type.toLowerCase() === 'video') {
        return `
          <h2>Data Science Fundamentals</h2>
          <p>This video introduces key concepts in data science and analytics.</p>
          
          <h3>What You'll Learn</h3>
          <ul>
            <li>Data collection and preprocessing</li>
            <li>Exploratory data analysis</li>
            <li>Statistical modeling techniques</li>
            <li>Data visualization and interpretation</li>
          </ul>
          
          <p>By the end of this lesson, you'll understand the core principles of working with data.</p>
        `;
      } else if (type.toLowerCase() === 'quiz') {
        return `
          <h2>Data Science Concepts Quiz</h2>
          <p>Test your understanding of data science principles and techniques.</p>
          
          <h3>Quiz Topics</h3>
          <ul>
            <li>Statistical analysis methods</li>
            <li>Data preprocessing techniques</li>
            <li>Machine learning fundamentals</li>
            <li>Data visualization principles</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'exercise') {
        return `
          <h2>Data Analysis Exercise</h2>
          <p>Apply your data science skills with this hands-on analytical exercise.</p>
          
          <h3>Exercise Requirements</h3>
          <ul>
            <li>Clean and preprocess a dataset</li>
            <li>Perform exploratory data analysis</li>
            <li>Apply appropriate statistical methods</li>
            <li>Create meaningful visualizations</li>
            <li>Draw insights from the data</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'reading') {
        return `
          <h2>Data Science Comprehensive Guide</h2>
          <p>This in-depth reading material covers advanced data science concepts.</p>
          
          <h3>Reading Topics</h3>
          <ul>
            <li>Advanced statistical methods</li>
            <li>Machine learning algorithms</li>
            <li>Big data processing techniques</li>
            <li>Ethical considerations in data science</li>
          </ul>
          
          <p>This reading will provide you with a deeper understanding of data science principles.</p>
        `;
      }
    }
    // UX/UI Design content
    else if (title.toLowerCase().includes('ux') || title.toLowerCase().includes('ui') || title.toLowerCase().includes('design')) {
      if (type.toLowerCase() === 'video') {
        return `
          <h2>UI/UX Design Principles</h2>
          <p>This video explores fundamental concepts in user interface and experience design.</p>
          
          <h3>What You'll Learn</h3>
          <ul>
            <li>User-centered design methodology</li>
            <li>Interface design principles</li>
            <li>Usability testing techniques</li>
            <li>Design systems and component libraries</li>
          </ul>
          
          <p>By the end of this lesson, you'll understand how to create intuitive, user-friendly designs.</p>
        `;
      } else if (type.toLowerCase() === 'quiz') {
        return `
          <h2>UI/UX Design Concepts Quiz</h2>
          <p>Test your understanding of design principles and best practices.</p>
          
          <h3>Quiz Topics</h3>
          <ul>
            <li>Color theory and typography</li>
            <li>Information architecture</li>
            <li>Interaction design patterns</li>
            <li>Accessibility guidelines</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'exercise') {
        return `
          <h2>UI/UX Design Challenge</h2>
          <p>Apply your design skills with this hands-on UI/UX exercise.</p>
          
          <h3>Exercise Requirements</h3>
          <ul>
            <li>Create user personas and journey maps</li>
            <li>Design wireframes and prototypes</li>
            <li>Apply visual design principles</li>
            <li>Conduct usability testing</li>
            <li>Iterate based on feedback</li>
          </ul>
        `;
      } else if (type.toLowerCase() === 'reading') {
        return `
          <h2>UI/UX Design Comprehensive Guide</h2>
          <p>This in-depth reading material covers advanced design concepts and methodologies.</p>
          
          <h3>Reading Topics</h3>
          <ul>
            <li>Design thinking and problem-solving</li>
            <li>Advanced prototyping techniques</li>
            <li>Design systems architecture</li>
            <li>Measuring design impact and ROI</li>
          </ul>
          
          <p>This reading will deepen your understanding of effective design practices.</p>
        `;
      }
    }
    // Default content for other topics - more specific based on type
    if (type.toLowerCase() === 'video') {
      return `
        <h2>${title}</h2>
        <p>This video lesson covers essential concepts and practical skills related to ${title}.</p>
        
        <h3>What You'll Learn</h3>
        <ul>
          <li>Fundamental principles and key concepts</li>
          <li>Step-by-step implementation techniques</li>
          <li>Best practices and industry standards</li>
          <li>Real-world application examples</li>
        </ul>
        
        <p>This video lesson provides a comprehensive introduction to ${title} with visual demonstrations and expert explanations.</p>
      `;
    } else if (type.toLowerCase() === 'quiz') {
      return `
        <h2>${title} Assessment</h2>
        <p>Test your knowledge and understanding of ${title} with this comprehensive quiz.</p>
        
        <h3>Quiz Topics</h3>
        <ul>
          <li>Core concepts and terminology</li>
          <li>Problem-solving techniques</li>
          <li>Common challenges and solutions</li>
          <li>Practical applications</li>
        </ul>
        
        <p>This quiz will help you identify your strengths and areas for improvement in ${title}.</p>
      `;
    } else if (type.toLowerCase() === 'exercise') {
      return `
        <h2>${title} Practical Exercise</h2>
        <p>Apply your knowledge with this hands-on exercise focused on ${title}.</p>
        
        <h3>Exercise Requirements</h3>
        <ul>
          <li>Implement key concepts from the lesson</li>
          <li>Solve realistic problems step-by-step</li>
          <li>Apply best practices and optimization techniques</li>
          <li>Test and validate your solution</li>
          <li>Reflect on alternative approaches</li>
        </ul>
        
        <p>This exercise will help you build practical skills and confidence in ${title}.</p>
      `;
    } else if (type.toLowerCase() === 'reading') {
      return `
        <h2>${title} In-Depth Guide</h2>
        <p>This comprehensive reading material explores ${title} in detail.</p>
        
        <h3>Reading Topics</h3>
        <ul>
          <li>Theoretical foundations and principles</li>
          <li>Advanced concepts and techniques</li>
          <li>Current trends and future developments</li>
          <li>Case studies and practical applications</li>
        </ul>
        
        <p>This reading will deepen your understanding of ${title} and provide valuable insights for practical application.</p>
      `;
    } else {
      return `
        <h2>${title}</h2>
        <p>This ${type.toLowerCase()} covers essential concepts and practical skills related to ${title}.</p>
        
        <h3>What You'll Learn</h3>
        <ul>
          <li>Fundamental principles and concepts</li>
          <li>Practical implementation techniques</li>
          <li>Best practices and common patterns</li>
          <li>Real-world application examples</li>
        </ul>
        
        <p>Enroll now to access the full content and start mastering ${title}!</p>
      `;
    }
  }

  // Get appropriate thumbnail based on lesson topic
  const getLessonThumbnail = (title: string, type: string): string => {
    if (title.toLowerCase().includes('html')) {
      return 'https://images.unsplash.com/photo-1621839673705-6617adf9e890?w=800&auto=format&fit=crop';
    } else if (title.toLowerCase().includes('css')) {
      return 'https://images.unsplash.com/photo-1523437113738-bbd3cc89fb19?w=800&auto=format&fit=crop';
    } else if (title.toLowerCase().includes('javascript') || title.toLowerCase().includes('js')) {
      return 'https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=800&auto=format&fit=crop';
    } else if (title.toLowerCase().includes('react')) {
      return 'https://images.unsplash.com/photo-1633356122102-3fe601e05bd2?w=800&auto=format&fit=crop';
    } else if (title.toLowerCase().includes('python')) {
      return 'https://images.unsplash.com/photo-1526379879527-8559ecfcaec0?w=800&auto=format&fit=crop';
    } else if (title.toLowerCase().includes('data') || title.toLowerCase().includes('analytics')) {
      return 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop';
    } else if (title.toLowerCase().includes('ux') || title.toLowerCase().includes('ui') || title.toLowerCase().includes('design')) {
      return 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&auto=format&fit=crop';
    }
    
    // For other or default cases, use a category-based image from the same category as the course
    if (course?.category?.toLowerCase().includes('develop')) {
      return 'https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=800&auto=format&fit=crop';
    } else if (course?.category?.toLowerCase().includes('design')) {
      return 'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=800&auto=format&fit=crop';
    } else if (course?.category?.toLowerCase().includes('business')) {
      return 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800&auto=format&fit=crop';
    } else if (course?.category?.toLowerCase().includes('market')) {
      return 'https://images.unsplash.com/photo-1533750516457-a7f992034fec?w=800&auto=format&fit=crop';
    } else if (course?.category?.toLowerCase().includes('data')) {
      return 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop';
    }
    
    // Fallback to a generic education image
    return 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=800&auto=format&fit=crop';
  }

  // Get YouTube video URL based on lesson topic
  const getLessonVideoUrl = (title: string, type: string): string => {
    if (type.toLowerCase() !== 'video') return '';
    
    if (title.toLowerCase().includes('html')) {
      return 'https://www.youtube.com/embed/qz0aGYrrlhU';
    } else if (title.toLowerCase().includes('css')) {
      return 'https://www.youtube.com/embed/yfoY53QXEnI';
    } else if (title.toLowerCase().includes('javascript') || title.toLowerCase().includes('js')) {
      return 'https://www.youtube.com/embed/W6NZfCO5SIk';
    } else if (title.toLowerCase().includes('react')) {
      return 'https://www.youtube.com/embed/Ke90Tje7VS0';
    } else if (title.toLowerCase().includes('python')) {
      return 'https://www.youtube.com/embed/_uQrJ0TkZlc';
    } else if (title.toLowerCase().includes('data') || title.toLowerCase().includes('analytics')) {
      return 'https://www.youtube.com/embed/ua-CiDNNj30';
    } else if (title.toLowerCase().includes('ux') || title.toLowerCase().includes('ui') || title.toLowerCase().includes('design')) {
      return 'https://www.youtube.com/embed/c9Wg6Cb_YlU';
    }
    return '';
  }

  const closePreview = () => {
    setIsPreviewOpen(false)
  }

  const fadeInUp = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  }

  // Function to handle file downloads with tracking
  const handleDownload = (resourceName: string, resourceType: string, url: string) => {
    // Show download starting notification
    setDownloadNotification({
      show: true,
      message: `Starting download...`,
      isLoading: true,
      resourceName
    });
    
    // In a real app, you might want to track downloads
    console.log(`Downloading ${resourceName} (${resourceType})`);
    
    // Get course-specific educational resources based on course category
    const resourceUrls = {
      'web-development': {
        'syllabus': 'https://ocw.mit.edu/courses/6-170-software-studio-spring-2013/0c607df5422e9c8e9f49a6f0bea053fb_MIT6_170S13_Overview.pdf',
        'exercise': 'https://ocw.mit.edu/courses/6-170-software-studio-spring-2013/33a2c535034a3f5df981dad2ca9d989a_MIT6_170S13_Ex1-TicTacToe.pdf',
        'cheatsheet': 'https://education.github.com/git-cheat-sheet-education.pdf'
      },
      'javascript-advanced': {
        'syllabus': 'https://www.cs.princeton.edu/courses/archive/fall18/cos109/syllabus.pdf',
        'exercise': 'https://eloquentjavascript.net/Eloquent_JavaScript.pdf',
        'cheatsheet': 'https://websitesetup.org/wp-content/uploads/2020/09/JavaScript-Cheat-Sheet.pdf'
      },
      'react-fundamentals': {
        'syllabus': 'https://www.pdfdrive.com/download/react-cookbook-pdf-e199298627.html',
        'exercise': 'https://www.pdfdrive.com/download/learning-react-modern-patterns-for-developing-react-apps-e158254971.html',
        'cheatsheet': 'https://devhints.io/react.pdf'
      },
      'default': {
        'syllabus': 'https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/MIT6_006S20_syllabus.pdf',
        'exercise': 'https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/mit6_006s20_ps1.pdf',
        'cheatsheet': 'https://www.pdfdrive.com/download/algorithms-in-a-nutshell-e196993599.html'
      }
    };
    
    // Map the resource name to its key
    const resourceKey = resourceName.toLowerCase().includes('syllabus') ? 'syllabus' : 
                        resourceName.toLowerCase().includes('exercise') ? 'exercise' : 
                        'cheatsheet';
    
    // Get the appropriate URL based on course ID or use default if not found
    const courseSpecificUrls = resourceUrls[course.id as keyof typeof resourceUrls] || resourceUrls.default;
    const downloadUrl = courseSpecificUrls[resourceKey as keyof typeof courseSpecificUrls] || url;
    
    // Simulate download progress (In a real app, you would use fetch with progress tracking)
    setTimeout(() => {
      setDownloadNotification({
        show: true,
        message: `Downloading ${resourceName}...`,
        isLoading: true,
        resourceName
      });
      
      // Create a temporary link element
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = `${course.id}-${resourceName.toLowerCase().replace(/\s+/g, '-')}.${resourceType.toLowerCase()}`;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      
      // Append to the document and trigger click
      document.body.appendChild(link);
      link.click();
      
      // Clean up
      document.body.removeChild(link);
      
      // Show success notification
      setTimeout(() => {
        setDownloadNotification({
          show: true,
          message: `${resourceName} downloaded successfully!`,
          isLoading: false,
          resourceName
        });
        
        // Auto-hide notification after 3 seconds
        setTimeout(() => {
          setDownloadNotification(null);
        }, 3000);
      }, 1500);
    }, 500);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Download Notification Toast */}
      {downloadNotification && downloadNotification.show && (
        <div className="fixed bottom-4 right-4 z-50 max-w-md w-full">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 p-4 flex items-center"
          >
            <div className="mr-3 flex-shrink-0">
              {downloadNotification.isLoading ? (
                <div className="h-8 w-8 flex items-center justify-center">
                  <Loader2 className="h-6 w-6 text-blue-600 animate-spin" />
                </div>
              ) : (
                <div className="h-8 w-8 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                  <Check className="h-5 w-5 text-green-600 dark:text-green-400" />
                </div>
              )}
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-medium">{downloadNotification.resourceName}</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400">{downloadNotification.message}</p>
            </div>
            <button
              onClick={() => setDownloadNotification(null)}
              className="ml-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
            >
              <X className="h-4 w-4" />
            </button>
          </motion.div>
        </div>
      )}

      {/* Review Dialog */}
      <CourseReviewDialog
        open={isReviewOpen}
        onOpenChange={setIsReviewOpen}
        courseId={courseId}
        courseTitle={course.title}
        onSubmitReview={async (review) => {
          // In a real app, this would save to a database
          console.log('Submitting review:', review);
          // Simulate API call
          return new Promise((resolve) => setTimeout(resolve, 1000));
        }}
      />
      
      {/* Preview Dialog */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader className="border-b pb-4 dark:border-gray-700">
            <DialogTitle className="text-xl font-bold leading-tight">
              {previewLesson?.title}
            </DialogTitle>
            <div className="flex items-center gap-3 mt-2">
              <span className="inline-flex items-center rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                {previewLesson?.type === "Video" ? (
                  <PlayCircle className="mr-1 h-3 w-3" />
                ) : previewLesson?.type === "quiz" ? (
                  <FileQuestion className="mr-1 h-3 w-3" />
                ) : previewLesson?.type === "exercise" ? (
                  <PenLine className="mr-1 h-3 w-3" />
                ) : (
                  <BookOpen className="mr-1 h-3 w-3" />
                )}
                {previewLesson?.type || "Lesson"}
              </span>
              <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800 dark:bg-gray-800 dark:text-gray-300">
                <Clock className="mr-1 h-3 w-3" />
                {previewLesson?.duration || "10 min"}
              </span>
            </div>
          </DialogHeader>
          
          <div className="py-4 space-y-6">
            {/* Video Preview Section */}
            {previewLesson?.type?.toLowerCase() === "video" && (
              <div className="relative aspect-video bg-gradient-to-br from-blue-900 to-indigo-900 rounded-lg overflow-hidden shadow-lg">
                {previewLesson?.videoUrl ? (
                  <div className="relative w-full h-full">
                    <iframe 
                      src={previewLesson.videoUrl}
                      title={previewLesson.title}
                      className="absolute top-0 left-0 w-full h-full"
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    ></iframe>
                  </div>
                ) : (
                  <>
                    <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
                      <div className="rounded-full bg-white/20 p-4 backdrop-blur-sm hover:bg-white/30 transition-all transform hover:scale-105 cursor-pointer">
                        <Play className="h-12 w-12 text-white" />
                      </div>
                      <div className="mt-6 text-center px-4 py-2 rounded-lg bg-black/40 backdrop-blur-sm max-w-md">
                        <p className="text-white text-center">
                          This video preview is available after enrollment.
                          <span className="block font-medium mt-1 text-blue-300">Enroll now to start learning!</span>
                        </p>
                      </div>
                    </div>
                    <img 
                      src={previewLesson?.thumbnail || 
                          (course?.image && course.image.startsWith('http') ? course.image : 
                          getLessonThumbnail(course.title, "default"))} 
                      alt={previewLesson?.title || "Lesson preview"} 
                      className="w-full h-full object-cover opacity-40 transform scale-105 blur-[1px]"
                    />
                  </>
                )}
              </div>
            )}
            
            {/* Quiz Preview Section */}
            {previewLesson?.type?.toLowerCase() === "quiz" && (
              <div className="bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20 rounded-lg p-6 border border-purple-100 dark:border-purple-800/30">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 rounded-full bg-purple-100 dark:bg-purple-800/30">
                    <FileQuestion className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div>
                    <h3 className="font-medium">Interactive Quiz</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Test your knowledge</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <p className="text-sm">This interactive quiz will help you test your understanding of key concepts covered in this lesson.</p>
                  <div className="p-3 bg-white dark:bg-gray-800 rounded-md border border-gray-200 dark:border-gray-700">
                    <p className="font-medium text-sm">Sample Question:</p>
                    <p className="mt-2 text-sm">What is the main purpose of the concept covered in this lesson?</p>
                    <div className="mt-3 space-y-2">
                      <div className="flex items-center gap-2 p-2 rounded-md bg-gray-50 dark:bg-gray-700/50">
                        <div className="h-4 w-4 rounded-full border-2 border-gray-300 dark:border-gray-600"></div>
                        <span className="text-sm">Sample answer option 1</span>
                      </div>
                      <div className="flex items-center gap-2 p-2 rounded-md">
                        <div className="h-4 w-4 rounded-full border-2 border-gray-300 dark:border-gray-600"></div>
                        <span className="text-sm">Sample answer option 2</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-center text-gray-500 dark:text-gray-400 italic">Full quiz available after enrollment</p>
                </div>
              </div>
            )}
            
            {/* Lesson Overview */}
            <div className="space-y-4 bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700 shadow-sm">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-full bg-blue-100 dark:bg-blue-900/30">
                  <Lightbulb className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="text-lg font-semibold">What you'll learn in this lesson</h3>
              </div>
              
              <div className="prose prose-sm dark:prose-invert max-w-none">
                <div className="text-gray-700 dark:text-gray-300 prose prose-sm dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: previewLesson?.content || "In this lesson, you'll learn essential concepts and practical skills that will help you master this topic. The full content is available after enrollment." }}></div>
                
                <ul className="mt-4 space-y-2">
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>Understanding core principles and fundamentals</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>Practical implementation with step-by-step guidance</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>Common challenges and how to overcome them</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>Best practices and industry standards</span>
                  </li>
                </ul>
              </div>
            </div>
            
            {/* Discussion Preview */}
            {previewLesson?.type?.toLowerCase() !== "quiz" && (
              <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-5 border border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-3 mb-3">
                  <MessageSquare className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                  <h3 className="font-medium">Discussion & Q&A</h3>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">Join the conversation with other students and instructors.</p>
                <div className="bg-white dark:bg-gray-800 rounded-md p-3 border border-gray-200 dark:border-gray-700">
                  <div className="flex items-start gap-3">
                    <div className="h-8 w-8 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                    <div className="flex-1">
                      <p className="text-xs text-gray-500 dark:text-gray-400">Sample discussion thread</p>
                      <p className="text-sm">How does this concept relate to what we learned previously?</p>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-center mt-3 text-gray-500 dark:text-gray-400 italic">Full discussions available after enrollment</p>
              </div>
            )}
            
            {/* Educational Resources */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Book className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                <h3 className="text-lg font-semibold">Educational Resources</h3>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <a href="https://www.freecodecamp.org/" target="_blank" rel="noopener noreferrer" 
                   className="flex items-start gap-3 p-4 rounded-lg border hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800 transition-colors hover:shadow-md">
                  <div className="flex-shrink-0 h-12 w-12 rounded-md bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center text-blue-600 dark:text-blue-400">
                    <BookOpen className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-medium">freeCodeCamp</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Free coding lessons and projects</p>
                    <span className="text-xs text-blue-600 dark:text-blue-400 mt-1 inline-block">Visit resource →</span>
                  </div>
                </a>
                <a href="https://developer.mozilla.org/" target="_blank" rel="noopener noreferrer" 
                   className="flex items-start gap-3 p-4 rounded-lg border hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800 transition-colors hover:shadow-md">
                  <div className="flex-shrink-0 h-12 w-12 rounded-md bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center text-purple-600 dark:text-purple-400">
                    <FileText className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-medium">MDN Web Docs</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Comprehensive web documentation</p>
                    <span className="text-xs text-purple-600 dark:text-purple-400 mt-1 inline-block">Visit resource →</span>
                  </div>
                </a>
              </div>
            </div>
          </div>
          
          <DialogFooter className="flex-col space-y-2 sm:space-y-0 sm:flex-row pt-4 border-t dark:border-gray-700">
            <div className="w-full sm:w-auto order-2 sm:order-1">
              <Button variant="outline" onClick={closePreview} className="w-full sm:w-auto">
                Close Preview
              </Button>
            </div>
            <div className="w-full sm:w-auto order-1 sm:order-2">
              {!isEnrolled ? (
                <Button onClick={handleEnroll} className="w-full sm:w-auto">
                  <GraduationCap className="mr-2 h-4 w-4" />
                  Enroll Now to Access Full Content
                </Button>
              ) : (
                <Button asChild className="w-full sm:w-auto">
                  <Link href={`/courses/${courseId}/learn`}>
                    <PlayCircle className="mr-2 h-4 w-4" />
                    Continue to Full Lesson
                  </Link>
                </Button>
              )}
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <Link
              href="/courses"
              className="mb-6 inline-flex items-center text-sm font-medium text-white/80 hover:text-white"
            >
              <ChevronLeft className="mr-1 h-4 w-4" />
              Back to Courses
            </Link>
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">{course.title}</h1>
            <div className="mb-6 flex flex-wrap items-center gap-4 text-white/90">
              <div className="flex items-center">
                <BookOpen className="mr-2 h-5 w-5" />
                <span>{course.category}</span>
              </div>
              <div className="flex items-center">
                <List className="mr-2 h-5 w-5" />
                <span>{course.level}</span>
              </div>
              <div className="flex items-center">
                <Calendar className="mr-2 h-5 w-5" />
                <span>{course.duration}</span>
              </div>
              <div className="flex items-center">
                <Users className="mr-2 h-5 w-5" />
                <span>{course.students.toLocaleString()} students</span>
              </div>
              <div className="flex items-center">
                <div className="flex">
                  {Array(5)
                    .fill(0)
                    .map((_, i) => (
                      <Star
                        key={i}
                        className={`h-5 w-5 ${i < Math.floor(course.rating) ? "fill-yellow-400 text-yellow-400" : "text-white/50"}`}
                      />
                    ))}
                </div>
                <span className="ml-2">{course.rating.toFixed(1)}</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-4">
              {isEnrolled ? (
                <>
                  <Button 
                    size="lg" 
                    className="bg-green-600 text-white hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-800"
                    asChild
                  >
                    <Link href={`/dashboard`}>
                      <UserCheck className="mr-2 h-5 w-5" />
                      Go to Dashboard
                    </Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-white/30 text-white hover:bg-white/10 hover:text-white"
                    asChild
                  >
                    <Link href={`/courses/${courseId}/learn`}>
                      <Play className="mr-2 h-5 w-5" />
                      Continue Learning
                    </Link>
                  </Button>
                </>
              ) : (
                <>
                  <Button 
                    size="lg" 
                    className="bg-white text-blue-700 hover:bg-white/90 dark:bg-white dark:text-blue-900"
                    onClick={handleEnroll}
                    disabled={enrolling}
                  >
                    {enrolling ? (
                      <>
                        <div className="mr-2 h-5 w-5 animate-spin rounded-full border-2 border-blue-700 border-t-transparent"></div>
                        Enrolling...
                      </>
                    ) : (
                      <>
                        {!user ? (
                          <>
                            <LogIn className="mr-2 h-5 w-5" />
                            Login to Enroll
                          </>
                        ) : (
                          <>
                            <BookOpen className="mr-2 h-5 w-5" />
                            Enroll Now (Free)
                          </>
                        )}
                      </>
                    )}
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-white/30 text-white hover:bg-white/10 hover:text-white"
                    onClick={() => handleDownload('Course Syllabus', 'pdf', 'https://www.adobe.com/support/products/enterprise/knowledgecenter/media/c4611_sample_explain.pdf')}
                  >
                    <Download className="mr-2 h-5 w-5" />
                    Download Syllabus
                  </Button>
                </>
              )}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Student Dashboard Section - Only visible for enrolled users */}
      {user && isEnrolled && (
        <div className="bg-gray-50 border-b dark:bg-gray-900 dark:border-gray-800">
          <div className="container mx-auto px-4 py-8">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold">Your Progress</h2>
              <Button variant="outline" size="sm" asChild>
                <Link href="/dashboard">
                  <Users className="mr-2 h-4 w-4" />
                  Full Dashboard
                </Link>
              </Button>
            </div>
            
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {/* Progress Card */}
              <div className="rounded-lg border bg-white p-5 shadow-sm dark:border-gray-700 dark:bg-gray-800">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Course Progress</h3>
                  <span className="text-lg font-bold text-blue-600 dark:text-blue-400">42%</span>
                </div>
                <Progress value={42} className="h-2 mb-3" />
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  5 of 12 lessons completed
                </p>
              </div>
              
              {/* Time Spent Card */}
              <div className="rounded-lg border bg-white p-5 shadow-sm dark:border-gray-700 dark:bg-gray-800">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Time Spent</h3>
                <div className="flex items-baseline">
                  <span className="text-2xl font-bold mr-1">3h 24m</span>
                  <span className="text-sm text-gray-500 dark:text-gray-400">total</span>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                  Last session: Yesterday, 45 minutes
                </p>
              </div>
              
              {/* Next Lesson Card */}
              <div className="rounded-lg border bg-white p-5 shadow-sm dark:border-gray-700 dark:bg-gray-800">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Continue Learning</h3>
                <h4 className="font-medium mb-1 line-clamp-1">3.2 Advanced Styling Techniques</h4>
                <div className="flex items-center text-xs text-gray-500 dark:text-gray-400 mb-3">
                  <Play className="h-3 w-3 mr-1" />
                  <span>Video • 18 min</span>
                </div>
                <Button 
                  size="sm" 
                  className="w-full"
                  onClick={(e) => {
                    e.preventDefault();
                    if (courseId) {
                      router.push(`/courses/${courseId}/learn`);
                    }
                  }}
                >
                  <Play className="mr-1 h-3 w-3" />
                  Resume
                </Button>
              </div>
              
              {/* Certificate Progress Card */}
              <div className="rounded-lg border bg-white p-5 shadow-sm dark:border-gray-700 dark:bg-gray-800">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Certificate Progress</h3>
                <div className="relative h-20 w-20 mx-auto my-1">
                  <svg viewBox="0 0 36 36" className="h-20 w-20">
                    <path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="#E5E7EB"
                      strokeWidth="3"
                      strokeDasharray="100, 100"
                    />
                    <path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="#3B82F6"
                      strokeWidth="3"
                      strokeDasharray="42, 100"
                    />
                  </svg>
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
                    <span className="text-lg font-bold">42%</span>
                  </div>
                </div>
                <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-2">
                  Complete the course to earn your certificate
                </p>
              </div>
            </div>
            
            {/* Recent Activity */}
            <div className="mt-8">
              <h3 className="text-lg font-medium mb-4">Recent Activity</h3>
              <div className="space-y-2">
                <div className="flex items-center rounded-md border px-4 py-3 bg-white dark:bg-gray-800 dark:border-gray-700">
                  <div className="mr-4 flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300">
                    <Play className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Completed lesson: Introduction to CSS Grid</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Yesterday at 3:45 PM</p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="ml-2"
                    onClick={() => {
                      // In a production app, this would open notes for this specific lesson
                      console.log('Opening notes for: Introduction to CSS Grid');
                    }}
                  >
                    <FileText className="h-4 w-4 mr-1" />
                    Notes
                  </Button>
                </div>
                
                <div className="flex items-center rounded-md border px-4 py-3 bg-white dark:bg-gray-800 dark:border-gray-700">
                  <div className="mr-4 flex h-10 w-10 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-300">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
                      <path d="m5 11 4 4L20 4"/>
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Completed quiz: CSS Layout Fundamentals</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">2 days ago at 1:30 PM</p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="ml-2"
                    onClick={() => {
                      // In a production app, this would show quiz results
                      console.log('Showing results for: CSS Layout Fundamentals');
                    }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1">
                      <path d="M12 20V10"/>
                      <path d="M18 20V4"/>
                      <path d="M6 20v-4"/>
                    </svg>
                    Results
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Course Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="overview" className="w-full" onValueChange={setActiveTab}>
              <TabsList className="mb-8 grid w-full grid-cols-5">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
                <TabsTrigger value="instructor">Instructor</TabsTrigger>
                <TabsTrigger value="resources">Resources</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>

              <TabsContent value="overview">
                <motion.div
                  initial="hidden"
                  animate={activeTab === "overview" ? "visible" : "hidden"}
                  variants={fadeInUp}
                >
                  <div className="mb-8 overflow-hidden rounded-xl">
                    <img
                      src={course.image && course.image.startsWith('http') 
                        ? course.image 
                        : getLessonThumbnail(course.title, "default")}
                      alt={course.title}
                      className="h-auto w-full object-cover"
                    />
                  </div>

                  <div className="mb-8">
                    <h2 className="mb-4 text-2xl font-bold">About This Course</h2>
                    <p className="mb-4 text-gray-700 dark:text-gray-300">{course.description}</p>
                    <p className="text-gray-700 dark:text-gray-300">
                      This course is completely free and designed to be accessible to everyone. We believe in removing
                      barriers to education and providing high-quality learning resources at no cost.
                    </p>
                  </div>

                  <div className="mb-8">
                    <h2 className="mb-4 text-2xl font-bold">What You'll Learn</h2>
                    <ul className="grid gap-3 sm:grid-cols-2">
                      {course.features.map((feature, index) => (
                        <li key={index} className="flex items-start">
                          <div className="mr-3 mt-1 flex h-5 w-5 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="h-3 w-3"
                            >
                              <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                          </div>
                          <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h2 className="mb-4 text-2xl font-bold">Accessibility Features</h2>
                    <div className="rounded-xl bg-blue-50 p-6 dark:bg-blue-950">
                      <h3 className="mb-3 text-lg font-semibold text-blue-700 dark:text-blue-300">
                        This course includes:
                      </h3>
                      <ul className="space-y-3">
                        <li className="flex items-center text-blue-700 dark:text-blue-300">
                          <FileText className="mr-3 h-5 w-5" />
                          <span>Full text transcripts for all video content</span>
                        </li>
                        <li className="flex items-center text-blue-700 dark:text-blue-300">
                          <MessageCircle className="mr-3 h-5 w-5" />
                          <span>Closed captions and subtitles</span>
                        </li>
                        <li className="flex items-center text-blue-700 dark:text-blue-300">
                          <Download className="mr-3 h-5 w-5" />
                          <span>Downloadable resources in accessible formats</span>
                        </li>
                        <li className="flex items-center text-blue-700 dark:text-blue-300">
                          <Clock className="mr-3 h-5 w-5" />
                          <span>Self-paced learning with no time restrictions</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </motion.div>
              </TabsContent>

              <TabsContent value="curriculum">
                <motion.div
                  initial="hidden"
                  animate={activeTab === "curriculum" ? "visible" : "hidden"}
                  variants={fadeInUp}
                >
                  <div className="mb-6">
                    <h2 className="mb-4 text-2xl font-bold">Course Curriculum</h2>
                    <p className="text-gray-700 dark:text-gray-300">
                      This course contains {course.modules.reduce((total, module) => total + module.lessons.length, 0)} lessons organized into {course.modules.length} modules.
                    </p>
                  </div>

                  <div className="space-y-6">
                    {course.modules.map((module, moduleIndex) => (
                      <div key={moduleIndex} className="overflow-hidden rounded-lg border shadow-sm dark:border-gray-700 transition-all hover:shadow-md">
                        <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-5 dark:from-blue-950/40 dark:to-blue-900/30">
                          <h3 className="text-lg font-semibold flex items-center">
                            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-blue-600 text-white text-xs mr-3">
                              {moduleIndex + 1}
                            </span>
                            {module.title}
                          </h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1 ml-10">
                            {module.lessons.length} {module.lessons.length === 1 ? "lesson" : "lessons"}
                          </p>
                        </div>
                        <div className="divide-y dark:divide-gray-700">
                          {module.lessons.map((lesson, lessonIndex) => (
                            <div key={lessonIndex} className="p-4 flex justify-between items-center hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                              <div className="flex items-center">
                                <div className="mr-4 flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400">
                                  {lesson.type === "Video" ? (
                                    <PlayCircle className="h-6 w-6" />
                                  ) : lesson.type === "Quiz" ? (
                                    <FileQuestion className="h-6 w-6" />
                                  ) : (
                                    <FileText className="h-6 w-6" />
                                  )}
                                </div>
                                <div>
                                  <h4 className="text-base font-medium">{lessonIndex + 1}. {lesson.title}</h4>
                                  <div className="mt-1 flex items-center gap-3 text-xs text-gray-500 dark:text-gray-400">
                                    <span className="flex items-center">
                                      <Clock className="mr-1 h-3 w-3" />
                                      {lesson.duration}
                                    </span>
                                    <span className="flex items-center">
                                      <span className={`h-2 w-2 rounded-full ${lesson.type === "Video" ? "bg-green-500" : lesson.type === "Quiz" ? "bg-orange-500" : "bg-blue-500"}`}></span>
                                      <span className="ml-1">{lesson.type}</span>
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 dark:text-blue-400 dark:hover:bg-blue-900/20 transition-all"
                                onClick={() => openPreview(lesson)}
                              >
                                <Play className="mr-1 h-3 w-3" />
                                Preview
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              </TabsContent>

              <TabsContent value="instructor">
                <motion.div
                  initial="hidden"
                  animate={activeTab === "instructor" ? "visible" : "hidden"}
                  variants={fadeInUp}
                >
                  <div className="mb-8">
                    <h2 className="mb-6 text-2xl font-bold">Meet Your Instructor</h2>
                    <div className="flex flex-col items-start gap-6 sm:flex-row">
                      <div className="flex-shrink-0">
                        <Image
                          src={course.instructor.image}
                          alt={course.instructor.name}
                          className="h-24 w-24 rounded-full object-cover"
                          width={96}
                          height={96}
                        />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold">{course.instructor.name}</h3>
                        <p className="mb-3 text-blue-600 dark:text-blue-400">{course.instructor.title}</p>
                        <p className="text-gray-700 dark:text-gray-300">{course.instructor.bio}</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </TabsContent>

              <TabsContent value="resources">
                <motion.div
                  initial="hidden"
                  animate={activeTab === "resources" ? "visible" : "hidden"}
                  variants={fadeInUp}
                >
                  <div className="mb-8">
                    <h2 className="mb-4 text-2xl font-bold">Course Resources</h2>
                    <p className="mb-6 text-gray-700 dark:text-gray-300">
                      Download supplementary materials to enhance your learning experience.
                    </p>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between rounded-lg border p-4 dark:border-gray-700">
                        <div className="flex items-center">
                          <FileText className="mr-3 h-5 w-5 text-blue-600 dark:text-blue-400" />
                          <div>
                            <h4 className="font-medium">Course Syllabus</h4>
                            <p className="text-sm text-gray-500 dark:text-gray-400">PDF, 2.3 MB</p>
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-blue-600 dark:text-blue-400 inline-flex items-center"
                          onClick={() => handleDownload('Course Syllabus', 'pdf', 'https://www.adobe.com/support/products/enterprise/knowledgecenter/media/c4611_sample_explain.pdf')}
                        >
                          <Download className="mr-1 h-4 w-4" />
                          Download
                        </Button>
                      </div>

                      <div className="flex items-center justify-between rounded-lg border p-4 dark:border-gray-700">
                        <div className="flex items-center">
                          <FileText className="mr-3 h-5 w-5 text-blue-600 dark:text-blue-400" />
                          <div>
                            <h4 className="font-medium">Exercise Files</h4>
                            <p className="text-sm text-gray-500 dark:text-gray-400">ZIP, 15.7 MB</p>
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-blue-600 dark:text-blue-400 inline-flex items-center"
                          onClick={() => handleDownload('Exercise Files', 'zip', 'https://www.learningcontainer.com/wp-content/uploads/2020/05/sample-zip-file.zip')}
                        >
                          <Download className="mr-1 h-4 w-4" />
                          Download
                        </Button>
                      </div>

                      <div className="flex items-center justify-between rounded-lg border p-4 dark:border-gray-700">
                        <div className="flex items-center">
                          <FileText className="mr-3 h-5 w-5 text-blue-600 dark:text-blue-400" />
                          <div>
                            <h4 className="font-medium">Cheat Sheet</h4>
                            <p className="text-sm text-gray-500 dark:text-gray-400">PDF, 1.2 MB</p>
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-blue-600 dark:text-blue-400 inline-flex items-center"
                          onClick={() => handleDownload('Cheat Sheet', 'pdf', 'https://documentcloud.adobe.com/link/track?uri=urn:aaid:scds:US:20068a5f-a41e-48cc-9a8c-b08a89bd1b14')}
                        >
                          <Download className="mr-1 h-4 w-4" />
                          Download
                        </Button>
                      </div>
                    </div>
                    
                    {/* Open Educational Resources Section */}
                    <div className="mt-10 pt-6 border-t border-gray-200 dark:border-gray-700">
                      <h3 className="text-xl font-semibold mb-4">Find More Free Educational Resources</h3>
                      <p className="mb-6 text-gray-700 dark:text-gray-300">
                        Explore these open educational platforms to find additional free materials related to this course.
                      </p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                        <a 
                          href={`https://ocw.mit.edu/search/?q=${encodeURIComponent(course.title.toLowerCase())}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center p-4 border rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                        >
                          <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-full mr-3">
                            <BookOpen className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                          </div>
                          <div>
                            <h4 className="font-medium">MIT OpenCourseWare</h4>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Free course materials from MIT</p>
                          </div>
                        </a>
                        
                        <a 
                          href={`https://www.coursera.org/search?query=${encodeURIComponent(course.title.toLowerCase())}&index=prod_all_launched_products_term_optimization`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center p-4 border rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                        >
                          <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-full mr-3">
                            <Book className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                          </div>
                          <div>
                            <h4 className="font-medium">Coursera</h4>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Free-to-audit courses (non-certification)</p>
                          </div>
                        </a>
                        
                        <a 
                          href={`https://openstax.org/subjects`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center p-4 border rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                        >
                          <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-full mr-3">
                            <BookOpen className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                          </div>
                          <div>
                            <h4 className="font-medium">OpenStax</h4>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Free peer-reviewed textbooks</p>
                          </div>
                        </a>
                        
                        <a 
                          href={`https://www.pdfdrive.com/search?q=${encodeURIComponent(course.title.toLowerCase())}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center p-4 border rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                        >
                          <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-full mr-3">
                            <FileText className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                          </div>
                          <div>
                            <h4 className="font-medium">PDF Drive</h4>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Search engine for free PDF e-books</p>
                          </div>
                        </a>
                      </div>
                      
                      <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border-l-4 border-yellow-400 dark:border-yellow-600 p-4">
                        <h4 className="font-medium text-yellow-800 dark:text-yellow-300 mb-1">Note About Open Educational Resources</h4>
                        <p className="text-sm text-yellow-700 dark:text-yellow-400">
                          These resources are provided for educational purposes. Always respect copyright laws and the terms of use for each platform. Some resources may require free account creation.
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </TabsContent>
              
              <TabsContent value="reviews">
                <motion.div
                  initial="hidden"
                  animate={activeTab === "reviews" ? "visible" : "hidden"}
                  variants={fadeInUp}
                >
                  <div className="mb-8">
                    <div className="flex justify-between items-center mb-6">
                      <h2 className="text-2xl font-bold">Student Reviews</h2>
                      <Button 
                        onClick={() => setIsReviewOpen(true)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <MessageSquare className="mr-2 h-4 w-4" />
                        Write a Review
                      </Button>
                    </div>
                    
                    <div className="grid gap-6 md:grid-cols-2">
                      {/* Sample reviews - in a real app, these would come from a database */}
                      <div className="rounded-lg border p-5 bg-white dark:bg-gray-800 dark:border-gray-700 shadow-sm">
                        <div className="flex justify-between mb-3">
                          <div className="flex items-center">
                            <div className="h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-400 mr-3">
                              <span className="font-medium">JD</span>
                            </div>
                            <div>
                              <h4 className="font-medium">John Doe</h4>
                              <p className="text-xs text-gray-500 dark:text-gray-400">2 weeks ago</p>
                            </div>
                          </div>
                          <div className="flex">
                            {Array(5).fill(0).map((_, i) => (
                              <Star key={i} className={`h-4 w-4 ${i < 5 ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`} />
                            ))}
                          </div>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 text-sm">This course exceeded my expectations. The content is well-structured and the instructor explains complex concepts in a way that's easy to understand.</p>
                      </div>
                      
                      <div className="rounded-lg border p-5 bg-white dark:bg-gray-800 dark:border-gray-700 shadow-sm">
                        <div className="flex justify-between mb-3">
                          <div className="flex items-center">
                            <div className="h-10 w-10 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center text-purple-600 dark:text-purple-400 mr-3">
                              <span className="font-medium">AS</span>
                            </div>
                            <div>
                              <h4 className="font-medium">Alice Smith</h4>
                              <p className="text-xs text-gray-500 dark:text-gray-400">1 month ago</p>
                            </div>
                          </div>
                          <div className="flex">
                            {Array(5).fill(0).map((_, i) => (
                              <Star key={i} className={`h-4 w-4 ${i < 4 ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`} />
                            ))}
                          </div>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 text-sm">Great course with practical examples. I especially enjoyed the hands-on exercises. Would recommend to anyone looking to learn this subject.</p>
                      </div>
                      
                      <div className="rounded-lg border p-5 bg-white dark:bg-gray-800 dark:border-gray-700 shadow-sm">
                        <div className="flex justify-between mb-3">
                          <div className="flex items-center">
                            <div className="h-10 w-10 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center text-green-600 dark:text-green-400 mr-3">
                              <span className="font-medium">RJ</span>
                            </div>
                            <div>
                              <h4 className="font-medium">Robert Johnson</h4>
                              <p className="text-xs text-gray-500 dark:text-gray-400">3 months ago</p>
                            </div>
                          </div>
                          <div className="flex">
                            {Array(5).fill(0).map((_, i) => (
                              <Star key={i} className={`h-4 w-4 ${i < 5 ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`} />
                            ))}
                          </div>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 text-sm">The instructor is knowledgeable and passionate about the subject. The course materials are comprehensive and up-to-date. I've learned so much!</p>
                      </div>
                      
                      <div className="rounded-lg border p-5 bg-white dark:bg-gray-800 dark:border-gray-700 shadow-sm">
                        <div className="flex justify-between mb-3">
                          <div className="flex items-center">
                            <div className="h-10 w-10 rounded-full bg-red-100 dark:bg-red-900 flex items-center justify-center text-red-600 dark:text-red-400 mr-3">
                              <span className="font-medium">MW</span>
                            </div>
                            <div>
                              <h4 className="font-medium">Maria Williams</h4>
                              <p className="text-xs text-gray-500 dark:text-gray-400">2 months ago</p>
                            </div>
                          </div>
                          <div className="flex">
                            {Array(5).fill(0).map((_, i) => (
                              <Star key={i} className={`h-4 w-4 ${i < 4 ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`} />
                            ))}
                          </div>
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 text-sm">Very informative course with a good balance of theory and practice. The quizzes helped reinforce my understanding of the material.</p>
                      </div>
                    </div>
                    
                    <div className="mt-8 text-center">
                      <Button variant="outline">
                        Load More Reviews
                      </Button>
                    </div>
                  </div>
                </motion.div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="rounded-lg border bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
              <h3 className="mb-4 text-lg font-semibold">Ready to Start Learning?</h3>
              <Button 
                className="mb-3 w-full"
                onClick={handleEnroll}
              >
                Enroll Now - It's Free
              </Button>
              <p className="mb-4 text-sm text-gray-500 dark:text-gray-400">
                No credit card required. Full access to all course materials.
              </p>
              <div className="space-y-3">
                <div className="flex items-center text-sm">
                  <Clock className="mr-2 h-4 w-4 text-gray-400" />
                  <span>Self-paced learning</span>
                </div>
                <div className="flex items-center text-sm">
                  <Users className="mr-2 h-4 w-4 text-gray-400" />
                  <span>Join {course.students.toLocaleString()} students</span>
                </div>
                <div className="flex items-center text-sm">
                  <FileText className="mr-2 h-4 w-4 text-gray-400" />
                  <span>Downloadable resources</span>
                </div>
                <div className="flex items-center text-sm">
                  <BookOpen className="mr-2 h-4 w-4 text-gray-400" />
                  <span>Certificate of completion</span>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t">
                <h4 className="text-sm font-medium mb-2">Quick Access Resources</h4>
                <div className="space-y-2">
                  <Button 
                    variant="outline"
                    size="sm"
                    className="w-full justify-start text-left"
                    onClick={() => handleDownload('Course Syllabus', 'pdf', 'https://www.adobe.com/support/products/enterprise/knowledgecenter/media/c4611_sample_explain.pdf')}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download Syllabus
                  </Button>
                  <Button 
                    variant="outline"
                    size="sm"
                    className="w-full justify-start text-left"
                    onClick={() => handleDownload('Cheat Sheet', 'pdf', 'https://documentcloud.adobe.com/link/track?uri=urn:aaid:scds:US:20068a5f-a41e-48cc-9a8c-b08a89bd1b14')}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download Cheat Sheet
                  </Button>
                </div>
              </div>
            </div>

            <div className="rounded-lg border bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
              <h3 className="mb-4 text-lg font-semibold">Share This Course</h3>
              <div className="flex space-x-2">
                <Button variant="outline" size="icon" className="h-10 w-10 rounded-full">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                  </svg>
                  <span className="sr-only">Facebook</span>
                </Button>
                <Button variant="outline" size="icon" className="h-10 w-10 rounded-full">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                  </svg>
                  <span className="sr-only">Twitter</span>
                </Button>
                <Button variant="outline" size="icon" className="h-10 w-10 rounded-full">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                    <rect width="4" height="12" x="2" y="9"></rect>
                    <circle cx="4" cy="4" r="2"></circle>
                  </svg>
                  <span className="sr-only">LinkedIn</span>
                </Button>
                <Button variant="outline" size="icon" className="h-10 w-10 rounded-full">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line>
                  </svg>
                  <span className="sr-only">Instagram</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
