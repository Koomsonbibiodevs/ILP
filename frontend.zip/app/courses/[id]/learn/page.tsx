"use client"

import React, { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { useAuth } from "@/lib/AuthContext"
import {
  BookOpen,
  CheckCircle,
  ChevronLeft,
  ChevronRight,
  Download,
  FileText,
  Home,
  List,
  MessageCircle,
  Menu,
  Play,
  X,
  Layout,
  CheckSquare,
  Clock
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { allCourses, Course } from "@/data/courses"

export default function CourseLearnPage({ params }: { params: { id: string } }) {
  // Unwrap the params to get the course ID
  const unwrappedParams = React.use(params);
  const courseId = unwrappedParams.id;
  const { user, loading } = useAuth();
  const router = useRouter();
  
  // State management
  const [course, setCourse] = useState<Course | null>(null);
  const [activeModule, setActiveModule] = useState(0);
  const [activeLesson, setActiveLesson] = useState(0);
  const [progress, setProgress] = useState(0);
  const [completedLessons, setCompletedLessons] = useState<string[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [activeTab, setActiveTab] = useState("content");
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [youtubeVideos, setYoutubeVideos] = useState<{[key: string]: string}>({});
  const [externalResources, setExternalResources] = useState<{[key: string]: {title: string, url: string, source: string, type: string}[]}>({});
  
  // YouTube video mapping based on course and lesson
  const getYoutubeVideoId = (courseId: string, lessonId: string) => {
    // This would typically come from an API or database
    // Using a static mapping for demonstration
    const videoMappings: {[key: string]: {[key: string]: string}} = {
      "web-development": {
        "html-basics": "uVwtVBpw7RQ",
        "html-structure": "bWPMSSsVdPk",
        "html-forms": "YwbIeMlxZAU"
      },
      "javascript-advanced": {
        "js-variables": "DHjqpvDnNGE",
        "js-functions": "N8ap4k_1QEQ",
        "js-objects": "PFmuCDHHpwk"
      },
      "react-fundamentals": {
        "react-intro": "4UZrsTqkcW4",
        "react-components": "Tn6-PIqc4UM",
        "react-hooks": "TNhaISOUy6Q"
      },
      "python-basics": {
        "python-intro": "kqtD5dpn9C8",
        "python-syntax": "rfscVS0vtbw",
        "python-functions": "9Os0o3wzS_I"
      },
      "ux-fundamentals": {
        "ux-principles": "2QQbVbUGzPs",
        "user-research": "bCeBMAgkKJA",
        "wireframing": "qpH7-BELeBE"
      }
    };
    
    // If we have a specific video for this lesson
    if (videoMappings[courseId]?.[lessonId]) {
      return videoMappings[courseId][lessonId];
    }
    
    // Fallback search terms based on course and lesson
    const searchQueries: {[key: string]: string} = {
      "web-development": "HTML CSS Javascript tutorial",
      "javascript-advanced": "Advanced JavaScript programming tutorial",
      "react-fundamentals": "React.js tutorial for beginners",
      "python-basics": "Python programming tutorial",
      "ux-fundamentals": "UX Design fundamentals",
      "default": "coding tutorial"
    };
    
    // Simulate searching YouTube - this would be replaced by actual API call
    // For now, we're using a few popular educational video IDs as fallbacks
    const fallbackVideos = [
      "PkZNo7MFNFg", // JavaScript tutorial
      "rfscVS0vtbw", // Python tutorial
      "4UZrsTqkcW4", // React tutorial
      "mU6anWqZJcc", // HTML CSS tutorial
      "2QQbVbUGzPs"  // UX Design tutorial
    ];
    
    // Return a consistent video based on course ID to simulate search
    const courseIndex = Object.keys(searchQueries).indexOf(courseId);
    return fallbackVideos[courseIndex >= 0 ? courseIndex % fallbackVideos.length : 0];
  };

  // External educational resources mapping
  const getExternalResources = (courseId: string, lessonId: string) => {
    // Free educational resources by topic
    const resourceMappings: {[key: string]: {[key: string]: {title: string, url: string, source: string, type: string}[]}} = {
      "web-development": {
        "html-basics": [
          {
            title: "Introduction to HTML",
            url: "https://www.w3schools.com/html/html_intro.asp",
            source: "W3Schools",
            type: "tutorial"
          },
          {
            title: "HTML Basics",
            url: "https://developer.mozilla.org/en-US/docs/Learn/Getting_started_with_the_web/HTML_basics",
            source: "MDN Web Docs",
            type: "documentation"
          },
          {
            title: "HTML & CSS Crash Course",
            url: "https://www.freecodecamp.org/learn/responsive-web-design/#basic-html-and-html5",
            source: "freeCodeCamp",
            type: "interactive"
          }
        ],
        "html-structure": [
          {
            title: "HTML Document Structure",
            url: "https://www.w3schools.com/html/html5_syntax.asp",
            source: "W3Schools",
            type: "tutorial"
          },
          {
            title: "Document and Website Structure",
            url: "https://developer.mozilla.org/en-US/docs/Learn/HTML/Introduction_to_HTML/Document_and_website_structure",
            source: "MDN Web Docs",
            type: "documentation"
          },
          {
            title: "HTML5 Structure Elements",
            url: "https://www.coursera.org/lecture/html-css-javascript-for-web-developers/lecture-8-semantic-elements-W1FYK",
            source: "Coursera",
            type: "video"
          }
        ],
        "html-forms": [
          {
            title: "HTML Forms",
            url: "https://www.w3schools.com/html/html_forms.asp",
            source: "W3Schools",
            type: "tutorial"
          },
          {
            title: "Your First Form",
            url: "https://developer.mozilla.org/en-US/docs/Learn/Forms/Your_first_form",
            source: "MDN Web Docs",
            type: "documentation"
          },
          {
            title: "Build a Survey Form",
            url: "https://www.freecodecamp.org/learn/responsive-web-design/responsive-web-design-projects/build-a-survey-form",
            source: "freeCodeCamp",
            type: "project"
          }
        ]
      },
      "javascript-advanced": {
        "js-variables": [
          {
            title: "JavaScript Variables",
            url: "https://javascript.info/variables",
            source: "JavaScript.info",
            type: "tutorial"
          },
          {
            title: "Variable Scope",
            url: "https://www.codecademy.com/learn/introduction-to-javascript/modules/learn-javascript-variables/cheatsheet",
            source: "Codecademy",
            type: "cheatsheet"
          },
          {
            title: "ES6 Let and Const",
            url: "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/let",
            source: "MDN Web Docs",
            type: "documentation"
          }
        ]
      },
      "react-fundamentals": {
        "react-intro": [
          {
            title: "React - Getting Started",
            url: "https://reactjs.org/docs/getting-started.html",
            source: "React Docs",
            type: "documentation"
          },
          {
            title: "React Basics",
            url: "https://www.edx.org/learn/reactjs/the-hong-kong-university-of-science-and-technology-front-end-web-development-with-react",
            source: "edX",
            type: "course"
          }
        ]
      },
      "python-basics": {
        "python-intro": [
          {
            title: "Python Introduction",
            url: "https://docs.python.org/3/tutorial/introduction.html",
            source: "Python Docs",
            type: "documentation"
          },
          {
            title: "Python Basics",
            url: "https://www.kaggle.com/learn/python",
            source: "Kaggle",
            type: "course"
          },
          {
            title: "Scientific Computing with Python",
            url: "https://www.freecodecamp.org/learn/scientific-computing-with-python/",
            source: "freeCodeCamp",
            type: "certification"
          }
        ]
      },
      "ux-fundamentals": {
        "ux-principles": [
          {
            title: "User Experience Design Fundamentals",
            url: "https://www.interaction-design.org/literature/topics/ux-design",
            source: "Interaction Design Foundation",
            type: "article"
          },
          {
            title: "UX Design Principles",
            url: "https://www.nngroup.com/articles/ten-usability-heuristics/",
            source: "Nielsen Norman Group",
            type: "article"
          }
        ]
      }
    };
    
    // Generic resources by course type
    const genericResources: {[key: string]: {title: string, url: string, source: string, type: string}[]} = {
      "web-development": [
        {
          title: "Web Development Full Course",
          url: "https://www.w3schools.com/",
          source: "W3Schools",
          type: "tutorial"
        },
        {
          title: "Learn Web Development",
          url: "https://developer.mozilla.org/en-US/docs/Learn",
          source: "MDN Web Docs",
          type: "documentation"
        },
        {
          title: "Responsive Web Design",
          url: "https://www.freecodecamp.org/learn/responsive-web-design/",
          source: "freeCodeCamp",
          type: "certification"
        }
      ],
      "javascript-advanced": [
        {
          title: "JavaScript Guide",
          url: "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide",
          source: "MDN Web Docs",
          type: "documentation"
        },
        {
          title: "JavaScript.info",
          url: "https://javascript.info/",
          source: "JavaScript.info",
          type: "tutorial"
        },
        {
          title: "JavaScript Algorithms and Data Structures",
          url: "https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/",
          source: "freeCodeCamp",
          type: "certification"
        }
      ],
      "react-fundamentals": [
        {
          title: "React Documentation",
          url: "https://reactjs.org/docs/getting-started.html",
          source: "React Docs",
          type: "documentation"
        },
        {
          title: "React Tutorial",
          url: "https://www.w3schools.com/react/",
          source: "W3Schools",
          type: "tutorial"
        },
        {
          title: "Front End Development Libraries",
          url: "https://www.freecodecamp.org/learn/front-end-development-libraries/",
          source: "freeCodeCamp",
          type: "certification"
        }
      ],
      "python-basics": [
        {
          title: "Python Documentation",
          url: "https://docs.python.org/3/",
          source: "Python Docs",
          type: "documentation"
        },
        {
          title: "Learn Python",
          url: "https://www.learnpython.org/",
          source: "LearnPython.org",
          type: "tutorial"
        },
        {
          title: "Python for Everybody",
          url: "https://www.py4e.com/",
          source: "py4e",
          type: "course"
        }
      ],
      "ux-fundamentals": [
        {
          title: "UX Design Courses",
          url: "https://www.interaction-design.org/courses",
          source: "Interaction Design Foundation",
          type: "course"
        },
        {
          title: "UX Fundamentals",
          url: "https://www.coursera.org/specializations/ui-ux-design",
          source: "Coursera",
          type: "course"
        }
      ]
    };
    
    // Return specific resources if available
    if (resourceMappings[courseId]?.[lessonId]) {
      return resourceMappings[courseId][lessonId];
    }
    
    // Return generic resources for the course type
    return genericResources[courseId] || genericResources["web-development"];
  };

  // Fetch course data
  useEffect(() => {
    // Find the course by ID
    const foundCourse = allCourses.find(c => c.id === courseId);
    
    if (foundCourse) {
      setCourse(foundCourse);
      
      // Set initial progress (this would be fetched from a database in a real app)
      const totalLessons = foundCourse.modules.reduce((total, module) => total + module.lessons.length, 0);
      
      // Mock data for completed lessons (in a real app, this would come from the database)
      const mockCompletedLessons = ["html-basics", "html-structure"];
      setCompletedLessons(mockCompletedLessons);
      
      // Calculate progress percentage
      setProgress((mockCompletedLessons.length / totalLessons) * 100);
      
      // Prepare YouTube videos for each lesson
      const videos: {[key: string]: string} = {};
      foundCourse.modules.forEach(module => {
        module.lessons.forEach(lesson => {
          videos[lesson.id] = getYoutubeVideoId(courseId, lesson.id);
        });
      });
      setYoutubeVideos(videos);

      // Prepare external resources for each lesson
      const resources: {[key: string]: {title: string, url: string, source: string, type: string}[]} = {};
      foundCourse.modules.forEach(module => {
        module.lessons.forEach(lesson => {
          resources[lesson.id] = getExternalResources(courseId, lesson.id);
        });
      });
      setExternalResources(resources);
    } else {
      // Handle case when course is not found
      console.error(`Course with ID ${courseId} not found`);
    }
    
    // Access control - If user isn't logged in, redirect to course page
    if (!loading && !user) {
      router.push(`/courses/${courseId}`);
    }
  }, [courseId, user, loading, router]);
  
  // Get current lesson
  const currentLesson = course?.modules[activeModule]?.lessons[activeLesson];
  
  // Handle lesson completion
  const markLessonAsComplete = () => {
    if (!currentLesson) return;
    
    if (!completedLessons.includes(currentLesson.id)) {
      const updatedCompletedLessons = [...completedLessons, currentLesson.id];
      setCompletedLessons(updatedCompletedLessons);
      
      // Recalculate progress
      const totalLessons = course?.modules.reduce((total, module) => total + module.lessons.length, 0) || 1;
      setProgress((updatedCompletedLessons.length / totalLessons) * 100);
      
      // In a real app, you would save this progress to the database
      console.log(`Marked lesson ${currentLesson.id} as complete`);
    }
  };
  
  // Navigate to next lesson
  const goToNextLesson = () => {
    if (!course) return;
    
    // Mark current lesson as complete
    markLessonAsComplete();
    
    // Calculate next lesson
    if (activeLesson < course.modules[activeModule].lessons.length - 1) {
      // Next lesson in same module
      setActiveLesson(activeLesson + 1);
    } else if (activeModule < course.modules.length - 1) {
      // First lesson in next module
      setActiveModule(activeModule + 1);
      setActiveLesson(0);
    }
  };
  
  // Navigate to previous lesson
  const goToPreviousLesson = () => {
    if (!course) return;
    
    if (activeLesson > 0) {
      // Previous lesson in same module
      setActiveLesson(activeLesson - 1);
    } else if (activeModule > 0) {
      // Last lesson in previous module
      setActiveModule(activeModule - 1);
      setActiveLesson(course.modules[activeModule - 1].lessons.length - 1);
    }
  };
  
  // Toggle fullscreen mode
  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
    setIsSidebarOpen(!isFullscreen);
  };
  
  // Toggle video playback
  const toggleVideoPlayback = () => {
    setIsVideoPlaying(!isVideoPlaying);
  };
  
  // Loading state
  if (!course) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="animate-pulse text-center">
          <div className="h-12 w-12 mx-auto mb-4 rounded-full bg-blue-200 dark:bg-blue-900"></div>
          <div className="h-4 mx-auto mb-2 w-48 rounded bg-blue-200 dark:bg-blue-900"></div>
          <div className="h-3 mx-auto w-32 rounded bg-gray-200 dark:bg-gray-700"></div>
        </div>
      </div>
    );
  }
  
  return (
    <div className={`flex h-screen w-full flex-col overflow-hidden no-footer-overlap ${isFullscreen ? 'bg-black' : 'bg-gray-50 dark:bg-gray-900'} fixed inset-0 top-0 left-0 right-0 bottom-0`}>
      {/* Top Navigation Bar */}
      {!isFullscreen && (
        <header className="flex h-16 items-center justify-between border-b bg-white px-4 dark:border-gray-800 dark:bg-gray-950">
          <div className="flex items-center">
            <Button variant="ghost" size="icon" onClick={() => setIsSidebarOpen(!isSidebarOpen)}>
              {isSidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            <Link 
              href={`/courses/${courseId}`}
              className="ml-4 flex items-center text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100"
            >
              <ChevronLeft className="mr-1 h-4 w-4" />
              Back to Course
            </Link>
          </div>
          
          <div className="flex-1 max-w-2xl mx-4">
            <div className="flex flex-col">
              <h1 className="text-sm font-semibold truncate">{course.title}</h1>
              <div className="flex items-center">
                <Progress value={progress} className="h-1.5 flex-1" />
                <span className="ml-2 text-xs font-medium text-gray-500 dark:text-gray-400">
                  {Math.round(progress)}% complete
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={markLessonAsComplete}
              disabled={completedLessons.includes(currentLesson?.id || '')}
            >
              <CheckCircle className="mr-1 h-4 w-4" />
              {completedLessons.includes(currentLesson?.id || '') ? 'Completed' : 'Mark Complete'}
            </Button>
            
            <Button asChild variant="ghost" size="icon">
              <Link href="/dashboard">
                <Home className="h-5 w-5" />
              </Link>
            </Button>
          </div>
        </header>
      )}
      
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar/Course Navigation */}
        {(isSidebarOpen && !isFullscreen) && (
          <aside className="w-80 flex-shrink-0 border-r bg-white dark:border-gray-800 dark:bg-gray-950">
            <div className="flex h-full flex-col">
              <div className="border-b p-4 dark:border-gray-800">
                <h2 className="font-semibold">Course Content</h2>
                <div className="mt-2 flex items-center text-sm text-gray-500 dark:text-gray-400">
                  <Clock className="mr-1 h-4 w-4" />
                  <span>{course.duration}</span>
                  <span className="mx-2">•</span>
                  <FileText className="mr-1 h-4 w-4" />
                  <span>
                    {course.modules.reduce((total, module) => total + module.lessons.length, 0)} lessons
                  </span>
                </div>
              </div>
              
              <ScrollArea className="flex-1">
                <div className="p-1">
                  {course.modules.map((module, moduleIndex) => (
                    <div key={moduleIndex} className="mb-2">
                      <div className="flex items-center justify-between rounded-lg bg-gray-100 p-3 dark:bg-gray-800">
                        <h3 className="font-medium">
                          {moduleIndex + 1}. {module.title}
                        </h3>
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          {module.lessons.length} {module.lessons.length === 1 ? 'lesson' : 'lessons'}
                        </span>
                      </div>
                      
                      <div className="ml-3 mt-1 space-y-1">
                        {module.lessons.map((lesson, lessonIndex) => {
                          const isActive = moduleIndex === activeModule && lessonIndex === activeLesson;
                          const isCompleted = completedLessons.includes(lesson.id);
                          
                          return (
                            <button
                              key={lessonIndex}
                              className={`flex w-full items-center rounded-md p-2 text-left text-sm transition-colors ${
                                isActive
                                  ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300'
                                  : isCompleted
                                  ? 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800'
                                  : 'text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800'
                              }`}
                              onClick={() => {
                                setActiveModule(moduleIndex);
                                setActiveLesson(lessonIndex);
                              }}
                            >
                              <div className="mr-2 flex h-5 w-5 flex-shrink-0 items-center justify-center">
                                {isCompleted ? (
                                  <CheckSquare className="h-4 w-4 text-green-600 dark:text-green-500" />
                                ) : lesson.type === "video" ? (
                                  <Play className="h-4 w-4" />
                                ) : lesson.type === "reading" ? (
                                  <FileText className="h-4 w-4" />
                                ) : (
                                  <MessageCircle className="h-4 w-4" />
                                )}
                              </div>
                              <span className="flex-1 truncate">{lesson.title}</span>
                              <span className="ml-2 text-xs text-gray-500 dark:text-gray-400">{lesson.duration}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </aside>
        )}
        
        {/* Main Content Area */}
        <main className={`flex-1 overflow-hidden ${isFullscreen ? 'bg-black' : 'bg-gray-50 dark:bg-gray-900'}`}>
          {currentLesson && (
            <div className="flex h-full flex-col">
              {/* Video Content */}
              {currentLesson.type === "video" && (
                <div className={`relative ${isFullscreen ? 'h-full' : 'aspect-video'} bg-black`}>
                  {!isVideoPlaying ? (
                    <div 
                      className="flex h-full items-center justify-center cursor-pointer"
                      onClick={toggleVideoPlayback}
                    >
                      <div className="absolute inset-0">
                        <img 
                          src={`https://img.youtube.com/vi/${youtubeVideos[currentLesson.id] || 'dQw4w9WgXcQ'}/maxresdefault.jpg`}
                          alt="Video thumbnail"
                          className="h-full w-full object-cover opacity-60"
                        />
                        <div className="absolute inset-0 bg-black/40"></div>
                      </div>
                      <div className="relative z-10 flex flex-col items-center">
                        <div className="rounded-full bg-blue-600 p-5 text-white shadow-lg hover:bg-blue-700 transition-colors">
                          <Play className="h-12 w-12" />
                        </div>
                        <span className="mt-4 text-white text-lg">{currentLesson.title}</span>
                        <span className="mt-1 text-gray-300 text-sm">Click to play video</span>
                      </div>
                    </div>
                  ) : (
                    <div className="absolute inset-0">
                      <iframe
                        src={`https://www.youtube.com/embed/${youtubeVideos[currentLesson.id] || 'dQw4w9WgXcQ'}?autoplay=1&modestbranding=1&rel=0`}
                        title={currentLesson.title}
                        className="h-full w-full"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      ></iframe>
                    </div>
                  )}
                  
                  {/* Video Controls */}
                  {!isVideoPlaying && (
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 p-4">
                      <div className="flex items-center justify-between text-white">
                        <div>
                          <h2 className="text-lg font-semibold">{currentLesson.title}</h2>
                          <div className="flex items-center text-sm">
                            <span>{currentLesson.duration}</span>
                            <span className="mx-2">•</span>
                            <span>YouTube Video</span>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-white hover:bg-white/20"
                            onClick={toggleFullscreen}
                          >
                            <Layout className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
              
              {/* Content Area for Non-Video Content */}
              <div className={`flex-1 ${isFullscreen && currentLesson.type === "video" ? "hidden" : "flex flex-col"}`}>
                <div className="mb-4 flex items-center justify-between border-b bg-white p-4 dark:border-gray-800 dark:bg-gray-950">
                  <div>
                    <div className="flex items-center">
                      {currentLesson.type === "reading" ? (
                        <FileText className="mr-2 h-5 w-5 text-blue-600 dark:text-blue-400" />
                      ) : currentLesson.type === "quiz" ? (
                        <CheckCircle className="mr-2 h-5 w-5 text-green-600 dark:text-green-400" />
                      ) : (
                        <MessageCircle className="mr-2 h-5 w-5 text-orange-600 dark:text-orange-400" />
                      )}
                      <h2 className="text-lg font-semibold">{currentLesson.title}</h2>
                    </div>
                    <div className="mt-1 flex items-center text-sm text-gray-500 dark:text-gray-400">
                      <span className="capitalize">{currentLesson.type}</span>
                      <span className="mx-2">•</span>
                      <span>{currentLesson.duration}</span>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={goToPreviousLesson}
                      disabled={activeModule === 0 && activeLesson === 0}
                    >
                      <ChevronLeft className="mr-1 h-4 w-4" />
                      Previous
                    </Button>
                    <Button 
                      size="sm" 
                      onClick={goToNextLesson}
                      disabled={
                        activeModule === course.modules.length - 1 && 
                        activeLesson === course.modules[course.modules.length - 1].lessons.length - 1
                      }
                    >
                      Next
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="flex-1 overflow-y-auto p-6">
                  <Tabs defaultValue="content" value={activeTab} onValueChange={setActiveTab}>
                    <TabsList>
                      <TabsTrigger value="content">Lesson Content</TabsTrigger>
                      <TabsTrigger value="resources">Resources</TabsTrigger>
                      <TabsTrigger value="discussion">Discussion</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="content" className="pt-4">
                      {currentLesson.content ? (
                        <div 
                          className="prose prose-blue max-w-none dark:prose-invert prose-headings:text-blue-800 dark:prose-headings:text-blue-300"
                          dangerouslySetInnerHTML={{ __html: currentLesson.content }}
                        />
                      ) : (
                        <div className="rounded-lg border bg-white p-8 text-center dark:border-gray-700 dark:bg-gray-800">
                          <FileText className="mx-auto mb-4 h-12 w-12 text-gray-400" />
                          <h3 className="mb-2 text-lg font-medium">No content available</h3>
                          <p className="text-gray-500 dark:text-gray-400">
                            This lesson doesn't have any content yet. Please check back later.
                          </p>
                        </div>
                      )}
                    </TabsContent>
                    
                    <TabsContent value="resources" className="pt-4">
                      <div className="rounded-lg border bg-white p-6 dark:border-gray-700 dark:bg-gray-800">
                        <h3 className="mb-4 text-lg font-medium">External Learning Resources</h3>
                        <p className="mb-4 text-sm text-gray-500 dark:text-gray-400">
                          Access free educational content from reputable learning platforms to enhance your understanding of this topic.
                        </p>
                        
                        {/* External Educational Resources */}
                        <div className="space-y-3">
                          {externalResources[currentLesson.id]?.map((resource, index) => (
                            <div key={index} className="flex items-center justify-between rounded-md border p-3 dark:border-gray-600">
                              <div className="flex items-center">
                                {resource.type === "documentation" ? (
                                  <FileText className="mr-3 h-5 w-5 text-blue-600 dark:text-blue-400" />
                                ) : resource.type === "tutorial" ? (
                                  <BookOpen className="mr-3 h-5 w-5 text-green-600 dark:text-green-400" />
                                ) : resource.type === "course" ? (
                                  <Layout className="mr-3 h-5 w-5 text-purple-600 dark:text-purple-400" />
                                ) : resource.type === "interactive" ? (
                                  <Play className="mr-3 h-5 w-5 text-orange-600 dark:text-orange-400" />
                                ) : (
                                  <FileText className="mr-3 h-5 w-5 text-gray-600 dark:text-gray-400" />
                                )}
                                <div>
                                  <h4 className="font-medium">{resource.title}</h4>
                                  <div className="flex items-center mt-1">
                                    <span className="text-xs px-2 py-0.5 bg-gray-100 dark:bg-gray-700 rounded-full text-gray-700 dark:text-gray-300 capitalize">
                                      {resource.type}
                                    </span>
                                    <span className="mx-2 text-gray-300 dark:text-gray-600">•</span>
                                    <span className="text-xs text-gray-500 dark:text-gray-400">{resource.source}</span>
                                  </div>
                                </div>
                              </div>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => window.open(resource.url, '_blank')}
                              >
                                <svg 
                                  xmlns="http://www.w3.org/2000/svg" 
                                  width="24" 
                                  height="24" 
                                  viewBox="0 0 24 24" 
                                  fill="none" 
                                  stroke="currentColor" 
                                  strokeWidth="2" 
                                  strokeLinecap="round" 
                                  strokeLinejoin="round" 
                                  className="mr-2 h-4 w-4"
                                >
                                  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                                  <polyline points="15 3 21 3 21 9"></polyline>
                                  <line x1="10" y1="14" x2="21" y2="3"></line>
                                </svg>
                                Open Resource
                              </Button>
                            </div>
                          ))}
                        </div>
                        
                        {/* YouTube Related Videos Section */}
                        <div className="mt-8 pt-6 border-t">
                          <h3 className="mb-4 text-lg font-medium">Related YouTube Tutorials</h3>
                          <div className="space-y-4">
                            {/* YouTube Video Suggestions - These would come from an API in a real app */}
                            {[
                              {
                                id: youtubeVideos[currentLesson.id] || "dQw4w9WgXcQ",
                                title: `${currentLesson.title} - Official Tutorial`,
                                channel: "EduFree Academy",
                                duration: "12:34"
                              },
                              {
                                id: currentLesson.id === "html-basics" ? "qz0aGYrrlhU" : 
                                     currentLesson.id === "html-structure" ? "pQN-pnXPaVg" : 
                                     currentLesson.id === "html-forms" ? "FNGoExJlLQY" : "W6NZfCO5SIk",
                                title: `Advanced ${currentLesson.title.split(' ')[0]} Tutorial for Beginners`,
                                channel: "Programming with Mosh",
                                duration: "18:22"
                              },
                              {
                                id: currentLesson.id === "html-basics" ? "UB1O30fR-EE" : 
                                     currentLesson.id === "html-structure" ? "3JluqTojuME" : 
                                     currentLesson.id === "html-forms" ? "2hJ1rTANVHs" : "8dWL3wF_OMw",
                                title: `${course?.title} Crash Course: ${currentLesson.title}`,
                                channel: "Traversy Media",
                                duration: "22:15"
                              }
                            ].map((video, index) => (
                              <div key={index} className="flex rounded-md overflow-hidden border dark:border-gray-600">
                                <div className="flex-shrink-0 relative w-40 h-24">
                                  <img 
                                    src={`https://img.youtube.com/vi/${video.id}/mqdefault.jpg`} 
                                    alt={video.title}
                                    className="w-full h-full object-cover"
                                  />
                                  <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-1 rounded">
                                    {video.duration}
                                  </div>
                                </div>
                                <div className="flex flex-col justify-between flex-1 p-3">
                                  <div>
                                    <h4 className="font-medium text-sm line-clamp-2">{video.title}</h4>
                                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{video.channel}</p>
                                  </div>
                                  <Button 
                                    size="sm" 
                                    className="mt-auto self-start"
                                    onClick={() => {
                                      window.open(`https://www.youtube.com/watch?v=${video.id}`, '_blank');
                                    }}
                                  >
                                    <Play className="mr-1 h-3 w-3" />
                                    Watch on YouTube
                                  </Button>
                                </div>
                              </div>
                            ))}
                            
                            {/* YouTube Search Link */}
                            <div className="mt-2 text-center">
                              <Button 
                                variant="outline" 
                                onClick={() => {
                                  const searchQuery = encodeURIComponent(`${course?.title} ${currentLesson.title} tutorial`);
                                  window.open(`https://www.youtube.com/results?search_query=${searchQuery}`, '_blank');
                                }}
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4 mr-2 text-red-600">
                                  <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
                                </svg>
                                Find More Videos on YouTube
                              </Button>
                            </div>
                          </div>
                        </div>
                        
                        {/* Other Learning Platforms Section */}
                        <div className="mt-8 pt-6 border-t">
                          <h3 className="mb-4 text-lg font-medium">Popular Learning Platforms</h3>
                          <div className="grid grid-cols-2 gap-3">
                            <a
                              href={`https://www.freecodecamp.org/learn/`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex flex-col items-center p-4 border rounded-lg bg-white hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700 transition-colors"
                            >
                              <div className="h-10 w-10 bg-gray-100 dark:bg-gray-700 rounded-md flex items-center justify-center mb-2">
                                <svg width="30" height="30" viewBox="0 0 576 512" fill="#0a0a23">
                                  <path d="M97.22,96.21c10.36-10.65,16-17.12,16-21.9,0-2.76-1.92-5.51-3.83-7.42A14.81,14.81,0,0,0,97.22,62a16.11,16.11,0,0,0-9.2-2.78c-6.72,0-15.07,3.84-21.91,10.44L32.23,103.8V93.2a19,19,0,0,0-3.83-11.44,16.22,16.22,0,0,0-12-5.79,18.22,18.22,0,0,0-11.66,4.21L3.27,81.7a12.65,12.65,0,0,0-3.83,9.61V140q0,3.65.06,4.78.95,5.51,4.21,8.89a16.83,16.83,0,0,0,11.17,4.3c5.94,0,9.79-1.92,12-5.11a17.83,17.83,0,0,0,4.41-12V114.14l23.81-23.81,5.48,24.35a15.36,15.36,0,0,0,6.13,9.19,16.29,16.29,0,0,0,10.44,3.83,19.34,19.34,0,0,0,9.79-2.59q.3,3.71.3,4.12v15.71c0,5.3-1,11.3-2.68,11.3-1.4,0-2.07-.37-4.3-3.65l-13.86-20.74a7.35,7.35,0,0,0-6.13-3.19c-4.68,0-9.3,5.24-9.3,10.57a9.16,9.16,0,0,0,1.92,6.13l19.88,29.90a20.66,20.66,0,0,0,16.73,9.21c8.89,0,15.26-3.11,18.15-8.89,1.24-2.49,2.68-6.72,2.68-13.25V113.3a37.63,37.63,0,0,0-.37-5.41ZM312.54,0a16.25,16.25,0,0,0-8.47,2.21c-3.43,1.95-5.66,5.87-7.42,10.63a92.35,92.35,0,0,0-3.06,20.54c-.06,3.06-.06,3.76-.06,45.40v73.28l-28.57-13.71a22.19,22.19,0,0,0-8.2-1.92c-7.23,0-14.33,4.08-18.28,10.07a28.59,28.59,0,0,0-4.08,14.46,28.59,28.59,0,0,0,4.08,14.46c3.95,6,11.05,10.07,18.28,10.07a22.22,22.22,0,0,0,8.2-1.91l28.57-13.72v94.08L265.91,269c-18,8.18-28.94,25.75-28.94,46.3,0,28.06,22.61,50.05,50.67,50.05a185.75,185.75,0,0,0,26.16-1.95c4.49-1.34,14.8-3.78,14.8-13.32a13.16,13.16,0,0,0-.95-4.83c-2.49-6.06-7.61-9.36-13.32-9.36a8,8,0,0,0-2.2.31c-10.13,2.68-14.45,3-20.39,3-12,0-22.85-5.36-22.85-16.06a16,16,0,0,1,7.61-13.25l46.63-35.2c18-13.51,29.8-36.23,29.8-57.6a78.27,78.27,0,0,0-7.23-33.3,202.28,202.28,0,0,1,19-23.2c8.56-9.48,24-22.91,42.09-22.91,5.25,0,9.12,1.19,11.74,4a9.24,9.24,0,0,1,2.3,6.68c0,4.58-3,7.95-12.34,12.89-8,4.3-11.62,7.82-11.62,14.52,0,4.61,2.68,8.75,6.25,11.3a19.49,19.49,0,0,0,12,3.68c8.83,0,18.28-4.61,22.48-10.75,4.21-6.13,5-10.26,5-18.89,0-14-5.42-25.72-15.33-33.36C382.31,12.53,365.4,0,336.9,0a85.64,85.64,0,0,0-57.31,23.14l-4.9,4.5c-1.4-9.54-5.24-15.4-11.23-19.68A34.91,34.91,0,0,0,243.79,0a129.56,129.56,0,0,0-28.22,3.35A34.33,34.33,0,0,0,204.7,9.19c-3.5,2.5-5.4,5.11-5.4,8,0,3.42,3.06,6.42,9.3,6.42a11.93,11.93,0,0,0,5.24-1.15,125.5,125.5,0,0,1,20-5.21,40.86,40.86,0,0,1,9.68-1.13c5.36,0,7.61,1.23,9.06,2.45,1.79,1.49,2.49,3.32,2.49,6.57,0,1.51-.29,5.6-.33,6.13a241.84,241.84,0,0,0-28.12,17.56l-7.93,5.6c-13.11,9.3-21.56,18.38-25.21,26.9-3.43,8.07-3.49,16-3.49,22.89,0,15.49,5.23,27.29,15.85,35A51.92,51.92,0,0,0,244,152.13c5.55,0,9.3-1.67,9.3-5.24,0-2.4-1.45-4.21-4.51-5.75a33.22,33.22,0,0,1-13.2-13.17,47.57,47.57,0,0,1-5.36-23.58c0-5.9,1-9.36,3.78-13.86,1.28-2.07,3.13-4.54,5.67-7.54l5.42-6.36a199.81,199.81,0,0,1,17.28-17.8L312.54,0Zm236.48,338.6h-69V166.19h69a28.4,28.4,0,0,1,19.09,7.18,28.4,28.4,0,0,1,7.18,19.09V312.32a28.4,28.4,0,0,1-7.18,19.09A28.4,28.4,0,0,1,549,338.6Zm6.75-264.5H414.39c-6.46,0-11.07-3.42-11.07-7.54s4.18-7.14,11.07-7.14H555.78c6.9,0,11.07,3,11.07,7.14S562.68,74.1,555.78,74.1ZM429.32,437.58c1,1.92,1.95,4.66,1.95,6.93a11.31,11.31,0,0,1-2.68,8,12.8,12.8,0,0,1-9.07,3.74c-7.93,0-15.26-3.86-15.26-12.11,0-2.3,1.41-7.06,7.3-11.77l16.43-12.88a10.82,10.82,0,0,1,7-2.68c5.92,0,10.69,3.8,10.69,10.82,0,5.11-2.75,10.82-8.95,13.36-1.56.64-3.58,1.23-5.41,1.79ZM507.33,312.7a20.77,20.77,0,0,1-13.25,5H427.13l25.66-19.56c2.36-1.78,6.31-4.77,9.18-4.77,4.6,0,8.3,3.68,8.3,8.12a7.46,7.46,0,0,1-1.8,5.17L455.09,320c9.34-3.74,15.62-5.41,23.71-5.41A27.76,27.76,0,0,1,499,323.09c6.13,6.06,9.06,14.27,9.06,25.6,0,10.6-3.49,19.3-10.07,25.6a34.33,34.33,0,0,1-24.47,9.36,42.53,42.53,0,0,1-15.26-2.49c-9.36-3.43-16.53-11-16.53-18.38,0-2.21.95-4.49,2.36-5.17a6.27,6.27,0,0,1,3.21-.93c4.17,0,6.13,3.13,7.36,4.72A24.8,24.8,0,0,0,472.62,371c7.36,0,12.89-2.9,16.85-7.82a28.4,28.4,0,0,0,5.86-18.21c0-7.29-2.68-13.25-7.3-16.85-3.42-2.74-7.94-4.13-14.2-4.13-14.17,0-24.37,8.31-36.46,18.05l-17.2,13.86c-5.7,4.48-12.89,10-12.89,19.68v81.73c0,9.18,2.3,16.47,6.19,21.07,5.29,6.3,13.65,8.8,28.06,8.8,12.71,0,22.08-3.73,27.85-10.28s8.77-17.09,8.77-32.09V413.48c0-5.3,3.8-9.58,8.89-9.58,4.6,0,9.12,3.21,9.12,8.83v31.5c0,20.34-4.48,34.86-14.14,44.44-9.24,9.3-23.71,14.33-42.74,14.33-19.27,0-31.4-3.83-39.27-12.52-7.29-8-11-19.7-11-35.31V329.91c0-14.33,7.36-23.89,15.07-30l38.72-31.42,13.2-10.75V192.1a28.4,28.4,0,0,1,7.18-19.09,28.39,28.39,0,0,1,19.08-7.18h92.68a28.39,28.39,0,0,1,19.09,7.18,28.4,28.4,0,0,1,7.18,19.09V294a18.11,18.11,0,0,1-5,13A19.8,19.8,0,0,1,507.33,312.7Z"/>
                                </svg>
                              </div>
                              <span className="text-sm font-medium">freeCodeCamp</span>
                              <span className="text-xs text-gray-500 dark:text-gray-400 mt-1">Free coding tutorials</span>
                            </a>
                            
                            <a
                              href={`https://developer.mozilla.org/en-US/`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex flex-col items-center p-4 border rounded-lg bg-white hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700 transition-colors"
                            >
                              <div className="h-10 w-10 bg-gray-100 dark:bg-gray-700 rounded-md flex items-center justify-center mb-2">
                                <svg width="30" height="30" viewBox="0 0 512 512">
                                  <rect width="512" height="512" fill="#000"/>
                                  <path d="M70.2 337.4h36.3v29.5H35V169.8h35.2v167.6zm184.3-71v71.7c0 5.7-1 13.5-3.2 23.2-2 9.8-8 18.1-17.7 25-9.8 6.8-23.7 10.3-41.8 10.3-16 0-29.3-2.5-40.3-7.4-10.9-5-18.9-11.4-24-19.4-5-8-8-16.6-8.7-26h36.3c.3 3.9 1.7 7.8 4.2 11.7a27.8 27.8 0 0020.7 10.6c9.6-.2 16.7-3.4 21.7-9.5 4.9-6.2 7.3-14.5 7.3-24.9v-17.8a42 42 0 01-44.8.6c-12-7-18-15.5-18-25.5v-68.5c0-10.8 5.7-19.9 17-27.4a41.1 41.1 0 0145.9.3 41.6 41.6 0 017.3 6.5v-11.1h36.2v77.6zm-36.2-44c0-7.9-2-14.4-5.7-19.4a18.3 18.3 0 00-15.6-7.7c-6.7 0-12 2.6-15.9 7.7a30.7 30.7 0 00-5.7 19.4v41c0 7.9 1.9 14.4 5.7 19.4a18.4 18.4 0 0015.9 7.7c6.7 0 12-2.6 15.6-7.7a30.7 30.7 0 005.7-19.4v-41zM357 337.4h36.2v29.5H321.7V169.8h35.1v167.6z" fill="#fff"/>
                                </svg>
                              </div>
                              <span className="text-sm font-medium">MDN Web Docs</span>
                              <span className="text-xs text-gray-500 dark:text-gray-400 mt-1">Web documentation</span>
                            </a>
                            
                            <a
                              href={`https://www.w3schools.com/`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex flex-col items-center p-4 border rounded-lg bg-white hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700 transition-colors"
                            >
                              <div className="h-10 w-10 bg-gray-100 dark:bg-gray-700 rounded-md flex items-center justify-center mb-2">
                                <svg width="30" height="30" viewBox="0 0 512 512">
                                  <path fill="#04AA6D" d="M71 460L41 30h430l-31 430-185 52z"/>
                                  <path fill="#059862" d="M256 472l149-41 35-394H256z"/>
                                  <path fill="#FFFFFF" d="M256 208h-75l-5-58h80v-56H118l1 15 14 156h123V208zm0 147h-1l-63-17-4-45h-56l7 89 116 32h1v-59z"/>
                                  <path fill="#EBEBEB" d="M256 265h69l-7 73-62 17v59l115-32 16-174H256v57z"/>
                                </svg>
                              </div>
                              <span className="text-sm font-medium">W3Schools</span>
                              <span className="text-xs text-gray-500 dark:text-gray-400 mt-1">Web tutorials</span>
                            </a>
                            
                            <a
                              href={`https://www.coursera.org/`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex flex-col items-center p-4 border rounded-lg bg-white hover:bg-gray-50 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700 transition-colors"
                            >
                              <div className="h-10 w-10 bg-gray-100 dark:bg-gray-700 rounded-md flex items-center justify-center mb-2">
                                <svg width="30" height="30" viewBox="0 0 64 64">
                                  <path d="M32 62C15.432 62 2 48.568 2 32S15.432 2 32 2s30 13.432 30 30-13.432 30-30 30z" fill="#2a73cc"/>
                                  <path d="m29.095 36.781-3.17-1.4a14.686 14.686 0 0 1-2.698-1.553c-.745-.557-1.117-1.377-1.117-2.46 0-1.052.447-1.922 1.342-2.609.894-.688 2.076-1.031 3.545-1.031 1.403 0 2.563.317 3.479.95.916.633 1.533 1.48 1.85 2.54l4.3-1.762c-.603-1.719-1.687-3.126-3.253-4.223-1.566-1.096-3.537-1.645-5.912-1.645-1.991 0-3.738.342-5.24 1.026a8.495 8.495 0 0 0-3.598 2.944c-.859 1.28-1.288 2.746-1.288 4.4 0 1.613.342 2.977 1.026 4.09a8.946 8.946 0 0 0 2.651 2.739 22.342 22.342 0 0 0 3.618 1.89l3.101 1.295c1.262.557 2.216 1.12 2.862 1.689.647.569.97 1.354.97 2.353 0 1.025-.435 1.89-1.303 2.597-.87.706-2.122 1.06-3.76 1.06-1.685 0-3.046-.384-4.083-1.15-1.037-.768-1.779-1.821-2.225-3.16l-4.532 1.858c.671 2.017 1.864 3.646 3.58 4.887 1.715 1.242 3.948 1.862 6.698 1.862 2.055 0 3.856-.347 5.403-1.04a8.729 8.729 0 0 0 3.641-2.958c.882-1.29 1.324-2.78 1.324-4.47 0-1.656-.331-3.032-.993-4.124-.662-1.094-1.516-1.983-2.562-2.67a21.036 21.036 0 0 0-3.459-1.775zm13.259-16.96c-1.584 0-2.978.395-4.18 1.186-1.203.79-2.159 1.895-2.87 3.317v-4.125h-4.674v23.193h4.88V32.378c0-2.107.55-3.843 1.65-5.208 1.1-1.365 2.491-2.048 4.178-2.048 1.526 0 2.693.526 3.5 1.577.807 1.052 1.21 2.52 1.21 4.402v12.291h4.881V31.077c0-2.145-.368-3.9-1.104-5.268-.736-1.367-1.753-2.384-3.05-3.051-1.298-.667-2.786-1-4.467-1-1.425 0-2.7.304-3.825.912-1.126.61-2.045 1.44-2.757 2.493l.044-1.584a4.401 4.401 0 0 1 1.365-2.336c.691-.63 1.574-.946 2.65-.946.799 0 1.523.18 2.173.54.65.36 1.144.847 1.483 1.46l3.95-2.22c-.71-1.318-1.72-2.343-3.033-3.076-1.312-.733-2.845-1.1-4.599-1.1z" fill="#fff"/>
                                </svg>
                              </div>
                              <span className="text-sm font-medium">Coursera</span>
                              <span className="text-xs text-gray-500 dark:text-gray-400 mt-1">Free courses to audit</span>
                            </a>
                          </div>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  )
} 