"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Filter, Search, SlidersHorizontal } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { CourseCard } from "@/components/course-card"
import { allCourses } from "@/data/courses"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function CoursesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedLevels, setSelectedLevels] = useState<string[]>([])
  const [filteredCourses, setFilteredCourses] = useState(allCourses)

  // Get unique categories and levels
  const categories = Array.from(new Set(allCourses.map((course) => course.category)))
  const levels = Array.from(new Set(allCourses.map((course) => course.level)))

  useEffect(() => {
    let result = allCourses

    // Filter by search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      result = result.filter(
        (course) =>
          course.title.toLowerCase().includes(term) ||
          course.description.toLowerCase().includes(term) ||
          course.instructor.name.toLowerCase().includes(term),
      )
    }

    // Filter by categories
    if (selectedCategories.length > 0) {
      result = result.filter((course) => selectedCategories.includes(course.category))
    }

    // Filter by levels
    if (selectedLevels.length > 0) {
      result = result.filter((course) => selectedLevels.includes(course.level))
    }

    setFilteredCourses(result)
  }, [searchTerm, selectedCategories, selectedLevels])

  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const toggleLevel = (level: string) => {
    setSelectedLevels((prev) => (prev.includes(level) ? prev.filter((l) => l !== level) : [...prev, level]))
  }

  const resetFilters = () => {
    setSearchTerm("")
    setSelectedCategories([])
    setSelectedLevels([])
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Explore Our Free Courses</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Discover high-quality courses across various subjects, all completely free and accessible to everyone.
            </p>
            <div className="mx-auto flex max-w-md flex-col gap-4 sm:flex-row">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input
                  type="search"
                  placeholder="Search courses..."
                  className="pl-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" className="bg-white text-blue-700 hover:bg-white/90 dark:bg-white">
                    <Filter className="mr-2 h-4 w-4" />
                    Filters
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                  <div className="flex flex-col space-y-6 py-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold">Filters</h3>
                      <Button variant="ghost" size="sm" onClick={resetFilters}>
                        Reset
                      </Button>
                    </div>

                    <div>
                      <h4 className="mb-3 text-sm font-medium">Categories</h4>
                      <div className="space-y-2">
                        {categories.map((category) => (
                          <div key={category} className="flex items-center space-x-2">
                            <Checkbox
                              id={`category-${category}`}
                              checked={selectedCategories.includes(category)}
                              onCheckedChange={() => toggleCategory(category)}
                            />
                            <label
                              htmlFor={`category-${category}`}
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {category}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="mb-3 text-sm font-medium">Level</h4>
                      <div className="space-y-2">
                        {levels.map((level) => (
                          <div key={level} className="flex items-center space-x-2">
                            <Checkbox
                              id={`level-${level}`}
                              checked={selectedLevels.includes(level)}
                              onCheckedChange={() => toggleLevel(level)}
                            />
                            <label
                              htmlFor={`level-${level}`}
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {level}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Button className="mt-4">Apply Filters</Button>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Courses Grid */}
      <div className="container mx-auto px-4 py-12">
        <div className="mb-8 flex items-center justify-between">
          <h2 className="text-2xl font-bold">
            {filteredCourses.length} {filteredCourses.length === 1 ? "Course" : "Courses"} Available
          </h2>
          <div className="hidden items-center gap-2 md:flex">
            <Button variant="outline" size="sm" onClick={resetFilters}>
              Clear Filters
            </Button>
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="h-4 w-4 text-gray-500" />
              <span className="text-sm text-gray-500">Sort by:</span>
              <select className="rounded-md border border-gray-200 bg-transparent px-2 py-1 text-sm dark:border-gray-700">
                <option value="popular">Most Popular</option>
                <option value="newest">Newest</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>
          </div>
        </div>

        {filteredCourses.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-gray-300 py-16 text-center dark:border-gray-700">
            <div className="mb-4 rounded-full bg-gray-100 p-3 dark:bg-gray-800">
              <Search className="h-6 w-6 text-gray-400" />
            </div>
            <h3 className="mb-2 text-lg font-medium">No courses found</h3>
            <p className="mb-4 max-w-md text-gray-500 dark:text-gray-400">
              We couldn't find any courses matching your search criteria. Try adjusting your filters or search term.
            </p>
            <Button onClick={resetFilters}>Clear Filters</Button>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredCourses.map((course) => (
              <CourseCard key={course.id} {...course} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
