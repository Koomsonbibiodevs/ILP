"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useParams } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { BookOpen, Clock, Filter, Search, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

// Sample courses data by category - in a real app, this would come from an API
const coursesByCategory = {
  "web-development": [
    {
      id: "web-dev-1",
      title: "Introduction to HTML & CSS",
      description: "Learn the fundamentals of web development with HTML and CSS.",
      instructor: "Sarah Johnson",
      duration: "5 hours",
      level: "Beginner",
      rating: 4.8,
      students: 12465,
      image: "https://images.pexels.com/photos/1591061/pexels-photo-1591061.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "web-dev-2",
      title: "JavaScript Essentials",
      description: "Master the core concepts of JavaScript programming.",
      instructor: "David Miller",
      duration: "8 hours",
      level: "Intermediate",
      rating: 4.7,
      students: 8932,
      image: "https://images.pexels.com/photos/4974920/pexels-photo-4974920.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "web-dev-3",
      title: "React for Beginners",
      description: "Build interactive user interfaces with React.",
      instructor: "Emily Chen",
      duration: "10 hours",
      level: "Intermediate",
      rating: 4.9,
      students: 7845,
      image: "https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "web-dev-4",
      title: "Full-Stack Web Development",
      description: "Learn to build complete web applications with MERN stack.",
      instructor: "Michael Brown",
      duration: "15 hours",
      level: "Advanced",
      rating: 4.8,
      students: 5621,
      image: "https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ],
  "data-science": [
    {
      id: "data-1",
      title: "Introduction to Python for Data Science",
      description: "Learn Python programming basics for data analysis.",
      instructor: "Dr. Robert Chen",
      duration: "6 hours",
      level: "Beginner",
      rating: 4.7,
      students: 9876,
      image: "https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "data-2",
      title: "Data Analysis with Pandas",
      description: "Master data manipulation and analysis with Python's Pandas library.",
      instructor: "Lisa Wang",
      duration: "8 hours",
      level: "Intermediate",
      rating: 4.8,
      students: 7654,
      image: "https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "data-3",
      title: "Machine Learning Fundamentals",
      description: "Introduction to core machine learning algorithms and applications.",
      instructor: "Dr. James Wilson",
      duration: "12 hours",
      level: "Intermediate",
      rating: 4.9,
      students: 6543,
      image: "https://images.pexels.com/photos/669615/pexels-photo-669615.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ],
  "ui-ux-design": [
    {
      id: "design-1",
      title: "UI/UX Design Principles",
      description: "Learn the fundamentals of user interface and experience design.",
      instructor: "Emma Davis",
      duration: "7 hours",
      level: "Beginner",
      rating: 4.8,
      students: 8765,
      image: "https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "design-2",
      title: "Figma for UI Designers",
      description: "Master UI design workflows with Figma.",
      instructor: "Alex Johnson",
      duration: "6 hours",
      level: "Intermediate",
      rating: 4.9,
      students: 7654,
      image: "https://images.pexels.com/photos/5082579/pexels-photo-5082579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ],
  "mobile-development": [
    {
      id: "mobile-1",
      title: "Android App Development",
      description: "Build Android applications with Kotlin.",
      instructor: "Daniel Kim",
      duration: "10 hours",
      level: "Intermediate",
      rating: 4.7,
      students: 6543,
      image: "https://images.pexels.com/photos/267507/pexels-photo-267507.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "mobile-2",
      title: "iOS Development with Swift",
      description: "Learn to build iOS applications with Swift.",
      instructor: "Sophia Martinez",
      duration: "12 hours",
      level: "Intermediate",
      rating: 4.8,
      students: 5432,
      image: "https://images.pexels.com/photos/1616516/pexels-photo-1616516.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "mobile-3",
      title: "React Native for Cross-Platform Apps",
      description: "Build mobile apps for iOS and Android with React Native.",
      instructor: "Jason Taylor",
      duration: "8 hours",
      level: "Intermediate",
      rating: 4.6,
      students: 4321,
      image: "https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ],
  "business": [
    {
      id: "business-1",
      title: "Introduction to Entrepreneurship",
      description: "Learn the fundamentals of starting and growing a business.",
      instructor: "Mark Wilson",
      duration: "6 hours",
      level: "Beginner",
      rating: 4.7,
      students: 5432,
      image: "https://images.pexels.com/photos/3184398/pexels-photo-3184398.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "business-2",
      title: "Business Strategy Fundamentals",
      description: "Develop strategic thinking skills for business success.",
      instructor: "Dr. Sarah Thompson",
      duration: "8 hours",
      level: "Intermediate",
      rating: 4.8,
      students: 4321,
      image: "https://images.pexels.com/photos/3183183/pexels-photo-3183183.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ],
  "marketing": [
    {
      id: "marketing-1",
      title: "Digital Marketing Essentials",
      description: "Learn the core concepts of digital marketing.",
      instructor: "Rachel Adams",
      duration: "7 hours",
      level: "Beginner",
      rating: 4.9,
      students: 6543,
      image: "https://images.pexels.com/photos/905163/pexels-photo-905163.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "marketing-2",
      title: "Social Media Marketing",
      description: "Master strategies for effective social media marketing.",
      instructor: "Thomas Moore",
      duration: "5 hours",
      level: "Intermediate",
      rating: 4.7,
      students: 5432,
      image: "https://images.pexels.com/photos/607812/pexels-photo-607812.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ],
  "photography": [
    {
      id: "photo-1",
      title: "Digital Photography Basics",
      description: "Learn the essentials of digital photography.",
      instructor: "Michael Rodriguez",
      duration: "6 hours",
      level: "Beginner",
      rating: 4.8,
      students: 4321,
      image: "https://images.pexels.com/photos/1983037/pexels-photo-1983037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "photo-2",
      title: "Portrait Photography",
      description: "Master the art of portrait photography.",
      instructor: "Jennifer Lewis",
      duration: "5 hours",
      level: "Intermediate",
      rating: 4.9,
      students: 3210,
      image: "https://images.pexels.com/photos/2779455/pexels-photo-2779455.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ],
  "video-production": [
    {
      id: "video-1",
      title: "Video Editing Fundamentals",
      description: "Learn the basics of video editing.",
      instructor: "David Wilson",
      duration: "8 hours",
      level: "Beginner",
      rating: 4.7,
      students: 5432,
      image: "https://images.pexels.com/photos/1266943/pexels-photo-1266943.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "video-2",
      title: "Cinematography Essentials",
      description: "Master the art of visual storytelling through cinematography.",
      instructor: "Sophia Clark",
      duration: "10 hours",
      level: "Intermediate",
      rating: 4.8,
      students: 4321,
      image: "https://images.pexels.com/photos/66134/pexels-photo-66134.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ],
  "personal-development": [
    {
      id: "personal-1",
      title: "Effective Communication Skills",
      description: "Improve your communication for personal and professional success.",
      instructor: "Dr. Jessica Andrews",
      duration: "5 hours",
      level: "All Levels",
      rating: 4.9,
      students: 7654,
      image: "https://images.pexels.com/photos/3153198/pexels-photo-3153198.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "personal-2",
      title: "Time Management Mastery",
      description: "Learn techniques to maximize productivity and manage your time effectively.",
      instructor: "Robert Johnson",
      duration: "4 hours",
      level: "All Levels",
      rating: 4.8,
      students: 6543,
      image: "https://images.pexels.com/photos/1436944/pexels-photo-1436944.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ],
  "education": [
    {
      id: "education-1",
      title: "Education Technology Fundamentals",
      description: "Learn how to leverage technology for effective teaching and learning.",
      instructor: "Dr. Emma Miller",
      duration: "6 hours",
      level: "Beginner",
      rating: 4.7,
      students: 4321,
      image: "https://images.pexels.com/photos/4144923/pexels-photo-4144923.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: "education-2",
      title: "Curriculum Design Principles",
      description: "Learn how to develop effective educational curriculum.",
      instructor: "Dr. Michael Davis",
      duration: "8 hours",
      level: "Intermediate",
      rating: 4.8,
      students: 3210,
      image: "https://images.pexels.com/photos/4050315/pexels-photo-4050315.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ]
};

// Category display names mapping (for prettier titles)
const categoryDisplayNames = {
  "web-development": "Web Development",
  "data-science": "Data Science",
  "ui-ux-design": "UI/UX Design",
  "mobile-development": "Mobile Development",
  "business": "Business",
  "marketing": "Marketing",
  "photography": "Photography",
  "video-production": "Video Production",
  "personal-development": "Personal Development",
  "education": "Education"
};

export default function CategoryPage() {
  const params = useParams();
  const slug = params.slug as string;
  
  const [searchTerm, setSearchTerm] = useState("");
  const [courses, setCourses] = useState<any[]>([]);
  const [filteredCourses, setFilteredCourses] = useState<any[]>([]);
  const [selectedLevel, setSelectedLevel] = useState<string>("all");
  const [isLoading, setIsLoading] = useState(true);

  // Get the category display name
  const categoryName = categoryDisplayNames[slug] || slug;

  useEffect(() => {
    // Show loading state when slug/category changes
    setIsLoading(true);
    
    // Simulate API fetch delay
    setTimeout(() => {
      // Load courses based on the slug
      const categoryCourses = coursesByCategory[slug] || [];
      setCourses(categoryCourses);
      setFilteredCourses(categoryCourses);
      setIsLoading(false);
    }, 800); // Simulate network delay
  }, [slug]);

  // Filter courses when search or level changes
  useEffect(() => {
    setIsLoading(true);
    
    // Simulate filtering delay
    setTimeout(() => {
      let result = courses;
      
      // Filter by search term
      if (searchTerm) {
        result = result.filter(
          course => course.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                   course.description.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }
      
      // Filter by level
      if (selectedLevel !== "all") {
        result = result.filter(course => course.level.toLowerCase() === selectedLevel.toLowerCase());
      }
      
      setFilteredCourses(result);
      setIsLoading(false);
    }, 400); // Shorter delay for filtering
  }, [searchTerm, selectedLevel, courses]);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleLevelChange = (value: string) => {
    setSelectedLevel(value);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-16 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">
              {categoryName} Courses
              {isLoading && (
                <div className="ml-4 inline-flex items-center">
                  <div className="h-5 w-5 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                </div>
              )}
            </h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Explore our free {categoryName.toLowerCase()} courses and start learning today
            </p>
          </motion.div>
        </div>
      </div>

      {/* Filter Section */}
      <div className="border-b border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <div className="relative w-full max-w-md">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <Input
                type="text"
                placeholder="Search courses..."
                className="pl-10"
                value={searchTerm}
                onChange={handleSearch}
                disabled={isLoading}
              />
              {isLoading && searchTerm && (
                <div className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2">
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-gray-300 border-t-blue-600"></div>
                </div>
              )}
            </div>
            <div className="flex w-full items-center gap-4 md:w-auto">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                <span className="text-sm text-gray-500 dark:text-gray-400">Filter by:</span>
              </div>
              <Select onValueChange={handleLevelChange} defaultValue="all" disabled={isLoading}>
                <SelectTrigger className={`w-32 ${isLoading ? 'opacity-70' : ''}`}>
                  <SelectValue placeholder="Level" />
                  {isLoading && (
                    <div className="ml-2 inline-flex h-3 w-3 animate-spin rounded-full border-2 border-gray-300 border-t-blue-600"></div>
                  )}
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="beginner">Beginner</SelectItem>
                  <SelectItem value="intermediate">Intermediate</SelectItem>
                  <SelectItem value="advanced">Advanced</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      {/* Courses Grid */}
      <div className="container mx-auto px-4 py-12">
        {isLoading ? (
          <div className="py-12">
            <div className="mx-auto max-w-md text-center">
              <div className="mb-8 flex justify-center">
                <div className="h-12 w-12 animate-spin rounded-full border-4 border-blue-200 border-t-blue-600"></div>
              </div>
              <h3 className="mb-2 text-xl font-semibold">Loading courses...</h3>
              <p className="text-gray-500 dark:text-gray-400">Please wait while we prepare your content</p>
            </div>
            
            {/* Loading skeleton placeholders */}
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {[1, 2, 3, 4, 5, 6].map((item) => (
                <div key={item} className="overflow-hidden rounded-lg bg-white shadow-md dark:bg-gray-800">
                  <div className="h-48 w-full animate-pulse bg-gray-200 dark:bg-gray-700"></div>
                  <div className="p-5">
                    <div className="mb-2 h-6 w-3/4 animate-pulse rounded bg-gray-200 dark:bg-gray-700"></div>
                    <div className="mb-4 h-4 w-full animate-pulse rounded bg-gray-200 dark:bg-gray-700"></div>
                    <div className="mb-3 h-4 w-1/4 animate-pulse rounded bg-gray-200 dark:bg-gray-700"></div>
                    <div className="mt-4 mb-4 h-px w-full bg-gray-200 dark:bg-gray-700"></div>
                    <div className="flex items-center justify-between">
                      <div className="h-4 w-1/3 animate-pulse rounded bg-gray-200 dark:bg-gray-700"></div>
                      <div className="h-4 w-1/4 animate-pulse rounded bg-gray-200 dark:bg-gray-700"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : filteredCourses.length > 0 ? (
          <>
            <div className="mb-8">
              <h2 className="text-2xl font-bold">
                Showing {filteredCourses.length} {filteredCourses.length === 1 ? 'course' : 'courses'}
              </h2>
            </div>
            <motion.div
              initial="hidden"
              animate="visible"
              variants={{
                hidden: { opacity: 0 },
                visible: {
                  opacity: 1,
                  transition: {
                    staggerChildren: 0.1
                  }
                }
              }}
              className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
            >
              {filteredCourses.map((course) => (
                <motion.div
                  key={course.id}
                  variants={{
                    hidden: { opacity: 0, y: 20 },
                    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } }
                  }}
                  className="overflow-hidden rounded-lg bg-white shadow-md transition-all hover:shadow-lg dark:bg-gray-800"
                >
                  <Link href={`/courses/${course.id}`}>
                    <div className="relative h-48 w-full">
                      {course.image.startsWith('http') ? (
                        <img
                          src={course.image}
                          alt={course.title}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <Image
                          src={course.image}
                          alt={course.title}
                          fill
                          className="object-cover"
                        />
                      )}
                      <div className="absolute bottom-0 left-0 bg-blue-600 px-3 py-1 text-xs font-semibold text-white">
                        {course.level}
                      </div>
                    </div>
                    <div className="p-5">
                      <h3 className="mb-2 text-xl font-bold">{course.title}</h3>
                      <p className="mb-4 text-sm text-gray-600 dark:text-gray-400">{course.description}</p>
                      <div className="mb-3 flex items-center text-sm text-gray-500 dark:text-gray-400">
                        <Clock className="mr-1 h-4 w-4" />
                        <span>{course.duration}</span>
                      </div>
                      <div className="mb-4 flex items-center justify-between border-t border-gray-200 pt-3 dark:border-gray-700">
                        <div className="flex items-center">
                          <Star className="mr-1 h-4 w-4 text-yellow-500" />
                          <span className="font-medium">{course.rating}</span>
                          <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">
                            ({course.students.toLocaleString()} students)
                          </span>
                        </div>
                        <div>
                          <span className="font-bold text-blue-600 dark:text-blue-400">Free</span>
                        </div>
                      </div>
                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                        <BookOpen className="mr-1 h-4 w-4" />
                        <span>{course.instructor}</span>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </motion.div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="mb-4 rounded-full bg-blue-100 p-3 dark:bg-blue-900/30">
              <Search className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="mb-2 text-xl font-bold">No courses found</h3>
            <p className="mb-6 text-gray-600 dark:text-gray-400">
              We couldn't find any courses matching your criteria.
            </p>
            <Button 
              onClick={() => {
                setSearchTerm("");
                setSelectedLevel("all");
              }}
              variant="outline"
            >
              Clear filters
            </Button>
          </div>
        )}
      </div>

      {/* FAQ Section */}
      <div className="bg-gray-100 py-16 dark:bg-gray-800/50">
        <div className="container mx-auto px-4">
          <div className="mb-8 text-center">
            <h2 className="mb-2 text-3xl font-bold">
              Frequently Asked Questions
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              Everything you need to know about our {categoryName.toLowerCase()} courses
            </p>
          </div>
          <div className="mx-auto max-w-3xl">
            <Accordion type="single" collapsible>
              <AccordionItem value="item-1">
                <AccordionTrigger>Are the courses really free?</AccordionTrigger>
                <AccordionContent>
                  Yes! All of our courses are completely free. We believe education should be 
                  accessible to everyone, regardless of financial circumstances.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-2">
                <AccordionTrigger>Do I get a certificate after completing a course?</AccordionTrigger>
                <AccordionContent>
                  Yes, upon successful completion of a course, you'll receive a digital certificate 
                  that you can share on your resume or social media profiles.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-3">
                <AccordionTrigger>How long do I have access to a course?</AccordionTrigger>
                <AccordionContent>
                  Once enrolled, you have unlimited access to the course materials. Learn at your own pace 
                  and revisit content whenever you need to refresh your knowledge.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-4">
                <AccordionTrigger>Are these courses suitable for beginners?</AccordionTrigger>
                <AccordionContent>
                  Our courses cater to all skill levels. Each course clearly indicates whether it's 
                  designed for beginners, intermediate, or advanced learners, helping you choose the 
                  right option for your current knowledge level.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-5">
                <AccordionTrigger>Can I download course materials for offline learning?</AccordionTrigger>
                <AccordionContent>
                  Yes, most course materials can be downloaded for offline use, including video lectures, 
                  readings, and exercises. This feature is especially useful for learners with limited 
                  internet connectivity.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </div>
    </div>
  )
} 