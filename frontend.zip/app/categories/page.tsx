"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { 
  BookOpen, 
  Code, 
  Database, 
  LineChart, 
  Palette, 
  PenTool, 
  Smartphone, 
  Speaker, 
  Users, 
  Video 
} from "lucide-react"

const categories = [
  {
    name: "Web Development",
    icon: Code,
    count: 42,
    color: "bg-blue-50 text-blue-600 dark:bg-blue-950 dark:text-blue-400",
    description: "Learn to build websites and web applications with HTML, CSS, JavaScript and modern frameworks."
  },
  {
    name: "Data Science",
    icon: Database,
    count: 38,
    color: "bg-purple-50 text-purple-600 dark:bg-purple-950 dark:text-purple-400",
    description: "Explore data analysis, machine learning, and statistical methods to derive insights from data."
  },
  {
    name: "UI/UX Design",
    icon: Palette,
    count: 24,
    color: "bg-pink-50 text-pink-600 dark:bg-pink-950 dark:text-pink-400",
    description: "Master the principles of user interface and experience design to create intuitive digital products."
  },
  {
    name: "Mobile Development",
    icon: Smartphone,
    count: 32,
    color: "bg-orange-50 text-orange-600 dark:bg-orange-950 dark:text-orange-400",
    description: "Build mobile applications for iOS and Android platforms with native and cross-platform frameworks."
  },
  {
    name: "Business",
    icon: LineChart,
    count: 18,
    color: "bg-green-50 text-green-600 dark:bg-green-950 dark:text-green-400",
    description: "Develop entrepreneurship skills, business strategy, and management expertise."
  },
  { 
    name: "Marketing", 
    icon: Speaker, 
    count: 26, 
    color: "bg-red-50 text-red-600 dark:bg-red-950 dark:text-red-400",
    description: "Learn digital marketing, social media strategies, and customer acquisition techniques."
  },
  {
    name: "Photography",
    icon: PenTool,
    count: 15,
    color: "bg-yellow-50 text-yellow-600 dark:bg-yellow-950 dark:text-yellow-400",
    description: "Master the art of photography from basic techniques to advanced editing and composition."
  },
  {
    name: "Video Production",
    icon: Video,
    count: 22,
    color: "bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400",
    description: "Learn video filming, editing, and post-production techniques for various media formats."
  },
  {
    name: "Personal Development",
    icon: Users,
    count: 30,
    color: "bg-teal-50 text-teal-600 dark:bg-teal-950 dark:text-teal-400",
    description: "Improve your soft skills, communication, time management, and productivity."
  },
  {
    name: "Education",
    icon: BookOpen,
    count: 28,
    color: "bg-cyan-50 text-cyan-600 dark:bg-cyan-950 dark:text-cyan-400",
    description: "Explore teaching methodologies, educational technology, and curriculum development."
  },
]

export default function CategoriesPage() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.4 },
    },
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Course Categories</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Explore our free courses across a wide range of subjects and disciplines
            </p>
          </motion.div>
        </div>
      </div>

      {/* Categories Section */}
      <div className="container mx-auto px-4 py-16">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
        >
          {categories.map((category, index) => (
            <motion.div 
              key={index}
              variants={itemVariants}
              whileHover={{ y: -5, scale: 1.02 }}
              className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm transition-all hover:shadow-md dark:border-gray-700 dark:bg-gray-800"
            >
              <Link href={`/categories/${category.name.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="p-6">
                  <div className="mb-4 flex items-center">
                    <div className={`mr-4 rounded-full p-3 ${category.color}`}>
                      <category.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold">{category.name}</h2>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{category.count} courses</p>
                    </div>
                  </div>
                  <p className="mb-4 text-gray-600 dark:text-gray-400">{category.description}</p>
                  <div className="flex items-center text-blue-600 dark:text-blue-400">
                    <span className="font-medium">Browse courses</span>
                    <svg
                      className="ml-2 h-4 w-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* CTA Section */}
      <div className="bg-gray-100 py-16 dark:bg-gray-800/50">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="mb-4 text-3xl font-bold">Can't find what you're looking for?</h2>
            <p className="mb-8 text-lg text-gray-600 dark:text-gray-400">
              We're constantly adding new courses. If you don't see a subject you're interested in, 
              let us know and we'll consider adding it to our curriculum.
            </p>
            <Link 
              href="/contact" 
              className="inline-flex items-center rounded-full bg-blue-600 px-6 py-3 text-white hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
            >
              <span>Suggest a Course</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
} 