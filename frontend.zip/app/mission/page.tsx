"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { 
  BarChart3, 
  BookOpen, 
  Globe, 
  Heart, 
  LightbulbIcon, 
  MapPin, 
  Sparkles, 
  Zap 
} from "lucide-react"

export default function MissionPage() {
  const impactStats = [
    {
      number: "1.2M+",
      label: "Students Reached",
      icon: <BookOpen className="h-8 w-8 text-green-500" />
    },
    {
      number: "15+",
      label: "Countries Served",
      icon: <Globe className="h-8 w-8 text-green-500" />
    },
    {
      number: "87%",
      label: "Course Completion Rate",
      icon: <BarChart3 className="h-8 w-8 text-green-500" />
    },
    {
      number: "250+",
      label: "Educational Partners",
      icon: <Heart className="h-8 w-8 text-green-500" />
    }
  ]

  const coreValues = [
    {
      title: "Accessibility",
      description: "We believe education should be accessible to everyone, regardless of location, ability, or socioeconomic status.",
      icon: <Globe className="h-6 w-6" />
    },
    {
      title: "Quality",
      description: "We are committed to delivering world-class educational content that meets international standards while being contextually relevant.",
      icon: <Sparkles className="h-6 w-6" />
    },
    {
      title: "Innovation",
      description: "We continuously explore new technologies and teaching methodologies to improve the learning experience.",
      icon: <LightbulbIcon className="h-6 w-6" />
    },
    {
      title: "Community",
      description: "We foster inclusive learning communities where students support each other and grow together.",
      icon: <Heart className="h-6 w-6" />
    },
    {
      title: "Impact",
      description: "We measure our success by the positive change we create in learners' lives and their communities.",
      icon: <Zap className="h-6 w-6" />
    },
    {
      title: "Localization",
      description: "We ensure our content and approach are relevant to local contexts across the African continent.",
      icon: <MapPin className="h-6 w-6" />
    }
  ]

  const fadeInUp = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  }

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-green-600 dark:bg-green-900">
        <div className="absolute inset-0 bg-gradient-to-r from-green-600 to-green-800 opacity-90 dark:from-green-900 dark:to-green-950" />
        <div className="absolute inset-0">
          <div className="h-full w-full bg-[url('/images/mission/pattern.svg')] opacity-10" />
        </div>
        <div className="container relative z-10 mx-auto px-4 py-24">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7 }}
            className="flex flex-col items-center justify-center text-center"
          >
            <h1 className="mb-6 text-4xl font-bold text-white sm:text-5xl md:text-6xl">
              Our Mission
            </h1>
            <p className="mx-auto mb-8 max-w-3xl text-xl leading-relaxed text-white text-opacity-90">
              Transforming education across Africa through accessible, 
              high-quality digital learning experiences that empower individuals 
              and strengthen communities.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Vision and Mission Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="mx-auto max-w-4xl">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            variants={fadeInUp}
            className="mb-16 text-center"
          >
            <h2 className="mb-6 text-3xl font-bold sm:text-4xl">Our Vision</h2>
            <p className="mb-8 text-xl leading-relaxed text-gray-700 dark:text-gray-300">
              A future where every African has access to quality education that 
              empowers them to reach their full potential and contribute to the 
              sustainable development of their communities and the continent.
            </p>
            <div className="mx-auto h-1 w-16 bg-green-600 dark:bg-green-500"></div>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            variants={fadeInUp}
            className="mb-16 text-center"
          >
            <h2 className="mb-6 text-3xl font-bold sm:text-4xl">Our Mission</h2>
            <p className="mb-8 text-xl leading-relaxed text-gray-700 dark:text-gray-300">
              To leverage technology to provide accessible, affordable, and high-quality 
              educational experiences tailored to African contexts. We create pathways for 
              learners to acquire knowledge, develop skills, and gain credentials that 
              open doors to economic opportunities and positive social impact.
            </p>
            <div className="mx-auto h-1 w-16 bg-green-600 dark:bg-green-500"></div>
          </motion.div>
        </div>

        {/* Core Values Section */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="mb-24"
        >
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold sm:text-4xl">Our Core Values</h2>
            <p className="mx-auto max-w-3xl text-lg text-gray-600 dark:text-gray-400">
              These principles guide everything we do and every decision we make.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {coreValues.map((value, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                className="rounded-lg bg-white p-8 shadow-sm dark:bg-gray-800"
              >
                <div className="mb-4 rounded-full bg-green-100 p-3 inline-flex dark:bg-green-900/30">
                  {value.icon}
                </div>
                <h3 className="mb-3 text-xl font-bold">{value.title}</h3>
                <p className="text-gray-600 dark:text-gray-400">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Impact Section */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          variants={fadeInUp}
          className="mb-24"
        >
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold sm:text-4xl">Our Impact</h2>
            <p className="mx-auto max-w-3xl text-lg text-gray-600 dark:text-gray-400">
              Through our platform, we're making a meaningful difference in the lives 
              of learners across Africa. Here's our impact at a glance:
            </p>
          </div>

          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {impactStats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="flex flex-col items-center justify-center rounded-lg bg-white p-8 text-center shadow-sm dark:bg-gray-800"
              >
                <div className="mb-4">{stat.icon}</div>
                <h3 className="mb-2 text-4xl font-bold text-green-600 dark:text-green-500">{stat.number}</h3>
                <p className="text-gray-600 dark:text-gray-400">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Our Approach Section */}
        <div className="mb-24">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold sm:text-4xl">Our Approach</h2>
            <p className="mx-auto max-w-3xl text-lg text-gray-600 dark:text-gray-400">
              We combine technology, pedagogy, and local knowledge to create 
              educational experiences that are both globally competitive and 
              locally relevant.
            </p>
          </div>

          <div className="grid gap-12 md:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="rounded-lg bg-white p-8 shadow-sm dark:bg-gray-800"
            >
              <h3 className="mb-4 text-2xl font-bold">Technology-Enhanced Learning</h3>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="mr-4 flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">
                    <span className="font-semibold">Adaptive Learning Paths:</span> Our platform 
                    adjusts to each learner's pace and style, providing personalized experiences.
                  </p>
                </li>
                <li className="flex items-start">
                  <div className="mr-4 flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">
                    <span className="font-semibold">Low Bandwidth Solutions:</span> Designed 
                    for areas with limited connectivity to ensure no learner is left behind.
                  </p>
                </li>
                <li className="flex items-start">
                  <div className="mr-4 flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">
                    <span className="font-semibold">Multimodal Content:</span> We offer 
                    video, audio, text, and interactive elements to support different 
                    learning preferences.
                  </p>
                </li>
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="rounded-lg bg-white p-8 shadow-sm dark:bg-gray-800"
            >
              <h3 className="mb-4 text-2xl font-bold">Culturally Relevant Pedagogy</h3>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="mr-4 flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">
                    <span className="font-semibold">Local Context:</span> Our courses 
                    incorporate African examples, case studies, and perspectives.
                  </p>
                </li>
                <li className="flex items-start">
                  <div className="mr-4 flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">
                    <span className="font-semibold">Multilingual Support:</span> Content 
                    available in major African languages to overcome language barriers.
                  </p>
                </li>
                <li className="flex items-start">
                  <div className="mr-4 flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">
                    <span className="font-semibold">Community Learning:</span> Designed 
                    to harness the power of collaborative learning and knowledge sharing.
                  </p>
                </li>
              </ul>
            </motion.div>
          </div>
        </div>

        {/* Quote Section */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="mb-24 rounded-xl bg-gradient-to-r from-green-600 to-green-800 p-12 text-center text-white dark:from-green-800 dark:to-green-900"
        >
          <div className="mx-auto max-w-4xl">
            <svg className="mx-auto mb-6 h-12 w-12 text-white opacity-80" fill="currentColor" viewBox="0 0 24 24">
              <path d="M9.983 3v7.391c0 5.704-3.731 9.57-8.983 10.609l-.995-2.151c2.432-.917 3.995-3.638 3.995-5.849h-4v-10h9.983zm14.017 0v7.391c0 5.704-3.748 9.571-9 10.609l-.996-2.151c2.433-.917 3.996-3.638 3.996-5.849h-3.983v-10h9.983z" />
            </svg>
            <p className="mb-6 text-2xl font-light italic leading-relaxed">
              "Education is the most powerful weapon which you can use to change the world. 
              By making quality education accessible to all Africans, we're helping to unlock 
              the continent's immense potential and enabling a future of prosperity and 
              innovation."
            </p>
            <p className="text-lg font-semibold">Dr. Amina Diallo, Founder & CEO</p>
          </div>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="rounded-xl bg-white p-12 text-center shadow-sm dark:bg-gray-800"
        >
          <h2 className="mb-6 text-3xl font-bold">Join Our Mission</h2>
          <p className="mx-auto mb-8 max-w-3xl text-lg text-gray-600 dark:text-gray-400">
            Whether you're a student, educator, partner organization, or supporter, 
            there are many ways to be part of our journey to transform education 
            across Africa.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/courses">
              <Button className="bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600">
                Explore Courses
              </Button>
            </Link>
            <Link href="/partners">
              <Button variant="outline" className="border-green-600 text-green-600 hover:bg-green-50 dark:border-green-500 dark:text-green-500 dark:hover:bg-green-950/30">
                Partner With Us
              </Button>
            </Link>
            <Link href="/careers">
              <Button variant="outline" className="border-green-600 text-green-600 hover:bg-green-50 dark:border-green-500 dark:text-green-500 dark:hover:bg-green-950/30">
                Join Our Team
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  )
} 