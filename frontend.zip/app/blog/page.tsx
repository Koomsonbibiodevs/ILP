"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import Image from "next/image"
import { 
  Calendar, 
  Clock, 
  Tag, 
  Search, 
  ChevronRight, 
  User,
  Bookmark,
  BadgeCheck
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

export default function BlogPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Sample blog posts data - would typically come from a CMS or API
  const featuredPosts = [
    {
      id: 1,
      title: "The Future of Education in Africa: Digital Opportunities and Challenges",
      excerpt: "Exploring how technology is reshaping educational access and outcomes across the continent.",
      date: "October 15, 2023",
      readTime: "8 min read",
      author: "Dr. Amina Diallo",
      authorRole: "Founder & CEO",
      category: "Education",
      image: "/images/blog/digital-education.jpg",
      featured: true
    },
    {
      id: 2,
      title: "How Mobile Learning is Bridging the Digital Divide",
      excerpt: "Case studies on successful mobile learning initiatives in rural communities.",
      date: "September 28, 2023",
      readTime: "6 min read",
      author: "Thomas Mensah",
      authorRole: "Director of Technology",
      category: "Technology",
      image: "/images/blog/mobile-learning.jpg",
      featured: true
    },
    {
      id: 3,
      title: "Adapting Global Learning Standards to Local African Contexts",
      excerpt: "Strategies for making international educational content culturally relevant and impactful.",
      date: "August 12, 2023",
      readTime: "10 min read",
      author: "Grace Okonkwo",
      authorRole: "Curriculum Development Lead",
      category: "Pedagogy",
      image: "/images/blog/local-contexts.jpg",
      featured: true
    }
  ]

  const recentPosts = [
    {
      id: 4,
      title: "Success Story: How 1,000 Students in Tanzania Benefited from Our STEM Program",
      excerpt: "Follow the journey of students who participated in our science and technology initiative.",
      date: "October 5, 2023",
      readTime: "5 min read",
      author: "Mark Johnson",
      authorRole: "Impact Assessment Specialist",
      category: "Success Stories",
      image: "/images/blog/success-story.jpg"
    },
    {
      id: 5,
      title: "Partnerships That Matter: Collaborating with Local Universities",
      excerpt: "How our university partnerships are creating pathways to higher education for students.",
      date: "September 20, 2023",
      readTime: "7 min read",
      author: "Sarah Mwangi",
      authorRole: "Partnership Manager",
      category: "Partnerships",
      image: "/images/blog/partnerships.jpg"
    },
    {
      id: 6,
      title: "Designing for Accessibility: Making Education Available to All",
      excerpt: "Our approach to inclusive design and accommodating diverse learning needs.",
      date: "September 15, 2023",
      readTime: "6 min read",
      author: "David Osei",
      authorRole: "UX Designer",
      category: "Accessibility",
      image: "/images/blog/accessibility.jpg"
    },
    {
      id: 7,
      title: "The Role of AI in Personalizing Learning Experiences",
      excerpt: "How we're using artificial intelligence to adapt content to individual student needs.",
      date: "September 8, 2023",
      readTime: "9 min read",
      author: "Fatima Hassan",
      authorRole: "AI Research Lead",
      category: "Technology",
      image: "/images/blog/ai-learning.jpg"
    },
    {
      id: 8,
      title: "Building Digital Skills for Tomorrow's Workforce",
      excerpt: "Preparing African youth for the digital economy through targeted skills development.",
      date: "August 30, 2023",
      readTime: "7 min read",
      author: "Robert Kiyosaki",
      authorRole: "Workforce Development Specialist",
      category: "Career Development",
      image: "/images/blog/digital-skills.jpg"
    },
    {
      id: 9,
      title: "Community Learning Hubs: Extending Our Digital Reach",
      excerpt: "How physical learning centers complement our online platform in underserved areas.",
      date: "August 22, 2023",
      readTime: "5 min read",
      author: "Ngozi Adichie",
      authorRole: "Community Engagement Manager",
      category: "Community",
      image: "/images/blog/community-hubs.jpg"
    }
  ]

  const categories = [
    { name: "Education", count: 12 },
    { name: "Technology", count: 8 },
    { name: "Success Stories", count: 15 },
    { name: "Partnerships", count: 6 },
    { name: "Accessibility", count: 4 },
    { name: "Pedagogy", count: 7 },
    { name: "Community", count: 9 },
    { name: "Career Development", count: 5 }
  ]

  const fadeInUp = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  }

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-green-600 to-green-800 dark:from-green-800 dark:to-green-950">
        <div className="absolute inset-0">
          <div className="h-full w-full bg-[url('/images/blog/pattern.svg')] opacity-10" />
        </div>
        <div className="container relative z-10 mx-auto px-4 py-16 md:py-24">
          <div className="mx-auto max-w-5xl text-center">
            <motion.h1
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-3xl font-bold text-white sm:text-4xl md:text-5xl"
            >
              Our Blog
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="mt-4 text-lg text-white/90 sm:text-xl"
            >
              Insights, stories, and updates from our team and community on education, 
              technology, and impact across Africa.
            </motion.p>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="mt-8 flex flex-col items-center justify-center sm:flex-row sm:space-x-4"
            >
              <div className="relative w-full max-w-md">
                <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search articles..."
                  className="w-full rounded-full border-0 bg-white py-3 pl-10 pr-4 text-gray-900 shadow-md dark:bg-gray-800 dark:text-gray-100"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Featured Posts */}
      <div className="container mx-auto px-4 py-16">
        <div className="mb-12">
          <h2 className="mb-2 text-3xl font-bold">Featured Articles</h2>
          <p className="text-lg text-gray-600 dark:text-gray-400">Our most impactful stories and insights</p>
        </div>

        <div className="grid gap-8 md:grid-cols-3">
          {featuredPosts.map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="group overflow-hidden rounded-lg bg-white shadow-md transition-all hover:shadow-lg dark:bg-gray-800"
            >
              <Link href={`/blog/${post.id}`}>
                <div className="relative h-52 w-full overflow-hidden">
                  <div className="absolute left-4 top-4 z-10 rounded-full bg-green-600 px-3 py-1 text-xs font-semibold uppercase text-white">
                    {post.category}
                  </div>
                  <Image
                    src={post.image}
                    alt={post.title}
                    width={400}
                    height={250}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <div className="mb-3 flex items-center text-sm text-gray-500 dark:text-gray-400">
                    <Calendar className="mr-1 h-4 w-4" />
                    <span>{post.date}</span>
                    <span className="mx-2">•</span>
                    <Clock className="mr-1 h-4 w-4" />
                    <span>{post.readTime}</span>
                  </div>
                  <h3 className="mb-3 text-xl font-bold transition-colors group-hover:text-green-600 dark:group-hover:text-green-500">
                    {post.title}
                  </h3>
                  <p className="mb-4 text-gray-600 dark:text-gray-400">{post.excerpt}</p>
                  <div className="mt-4 flex items-center">
                    <div className="relative mr-3 h-10 w-10 overflow-hidden rounded-full bg-gray-200">
                      <User className="absolute left-1/2 top-1/2 h-6 w-6 -translate-x-1/2 -translate-y-1/2 text-gray-600" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold">{post.author}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{post.authorRole}</p>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Recent Posts and Sidebar */}
      <div className="container mx-auto px-4 pb-16">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Recent Posts Column */}
          <div className="lg:col-span-2">
            <div className="mb-12">
              <h2 className="mb-2 text-3xl font-bold">Recent Articles</h2>
              <p className="text-lg text-gray-600 dark:text-gray-400">The latest from our blog</p>
            </div>

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={staggerContainer}
              className="space-y-8"
            >
              {recentPosts.map((post) => (
                <motion.div
                  key={post.id}
                  variants={fadeInUp}
                  className="overflow-hidden rounded-lg bg-white shadow-md transition-all hover:shadow-lg dark:bg-gray-800"
                >
                  <Link href={`/blog/${post.id}`}>
                    <div className="grid grid-cols-1 items-stretch md:grid-cols-3">
                      <div className="relative h-full w-full min-h-[200px]">
                        <Image
                          src={post.image}
                          alt={post.title}
                          fill
                          className="object-cover"
                        />
                        <div className="absolute left-4 top-4 z-10 rounded-full bg-green-600 px-3 py-1 text-xs font-semibold uppercase text-white">
                          {post.category}
                        </div>
                      </div>
                      <div className="flex flex-col justify-between p-6 md:col-span-2">
                        <div>
                          <div className="mb-3 flex flex-wrap items-center text-sm text-gray-500 dark:text-gray-400">
                            <Calendar className="mr-1 h-4 w-4" />
                            <span className="mr-3">{post.date}</span>
                            <Clock className="mr-1 h-4 w-4" />
                            <span>{post.readTime}</span>
                          </div>
                          <h3 className="mb-3 text-xl font-bold transition-colors hover:text-green-600 dark:hover:text-green-500">
                            {post.title}
                          </h3>
                          <p className="mb-4 text-gray-600 dark:text-gray-400">{post.excerpt}</p>
                        </div>
                        <div className="mt-4 flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="relative mr-3 h-10 w-10 overflow-hidden rounded-full bg-gray-200">
                              <User className="absolute left-1/2 top-1/2 h-6 w-6 -translate-x-1/2 -translate-y-1/2 text-gray-600" />
                            </div>
                            <div>
                              <p className="text-sm font-semibold">{post.author}</p>
                              <p className="text-xs text-gray-500 dark:text-gray-400">{post.authorRole}</p>
                            </div>
                          </div>
                          <ChevronRight className="h-5 w-5 text-green-600" />
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </motion.div>

            <div className="mt-12 text-center">
              <Button className="bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-600">
                Load More Articles
              </Button>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-8 space-y-8">
              {/* Categories */}
              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="overflow-hidden rounded-lg bg-white p-6 shadow-md dark:bg-gray-800"
              >
                <h3 className="mb-4 text-xl font-bold">Categories</h3>
                <ul className="space-y-3">
                  {categories.map((category, index) => (
                    <li key={index}>
                      <Link href={`/blog/category/${category.name.toLowerCase().replace(/\s+/g, '-')}`}>
                        <div className="flex items-center justify-between rounded-md p-2 transition-colors hover:bg-gray-100 dark:hover:bg-gray-700">
                          <div className="flex items-center">
                            <Tag className="mr-2 h-4 w-4 text-green-600" />
                            <span>{category.name}</span>
                          </div>
                          <span className="rounded-full bg-gray-100 px-2 py-1 text-xs dark:bg-gray-700">
                            {category.count}
                          </span>
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              </motion.div>

              {/* Newsletter Signup */}
              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className="overflow-hidden rounded-lg bg-gradient-to-r from-green-600 to-green-800 p-6 shadow-md dark:from-green-700 dark:to-green-900"
              >
                <h3 className="mb-4 text-xl font-bold text-white">Subscribe to Our Newsletter</h3>
                <p className="mb-4 text-white/90">
                  Get the latest articles, updates, and insights delivered directly to your inbox.
                </p>
                <div className="space-y-3">
                  <Input
                    type="email"
                    placeholder="Your email address"
                    className="border-0 bg-white/90 text-gray-900 placeholder:text-gray-500 focus:ring-2 focus:ring-white dark:bg-gray-800/90 dark:text-white"
                  />
                  <Button className="w-full bg-white text-green-700 hover:bg-white/90 dark:bg-gray-800 dark:text-green-500 dark:hover:bg-gray-700">
                    Subscribe
                  </Button>
                </div>
                <div className="mt-4 flex items-center text-sm text-white/80">
                  <BadgeCheck className="mr-2 h-4 w-4" />
                  No spam, we promise!
                </div>
              </motion.div>

              {/* Popular Tags */}
              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4, duration: 0.5 }}
                className="overflow-hidden rounded-lg bg-white p-6 shadow-md dark:bg-gray-800"
              >
                <h3 className="mb-4 text-xl font-bold">Popular Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {["EdTech", "Africa", "Digital Learning", "STEM", "Mobile Education",
                    "Skill Development", "Innovation", "Accessibility", "Future of Work",
                    "Teaching", "Rural Education"].map((tag, index) => (
                    <Link key={index} href={`/blog/tag/${tag.toLowerCase().replace(/\s+/g, '-')}`}>
                      <span className="rounded-full bg-gray-100 px-3 py-1 text-sm transition-colors hover:bg-green-100 hover:text-green-800 dark:bg-gray-700 dark:hover:bg-green-900 dark:hover:text-green-300">
                        {tag}
                      </span>
                    </Link>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
} 