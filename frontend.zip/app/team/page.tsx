"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { 
  Card, 
  CardContent 
} from "@/components/ui/card"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from "@/components/ui/tabs"
import { Linkedin, Twitter, Mail, Globe, MoveRight } from "lucide-react"

export default function TeamPage() {
  const leadershipTeam = [
    {
      name: "Dr. Nala Amara",
      title: "Founder & CEO",
      bio: "Former education policy advisor with 15+ years of experience in educational technology. Ph.D. in Educational Innovation from Stanford University.",
      image: "/images/team/nala-amara.jpg",
      social: {
        linkedin: "https://linkedin.com/in/nala-amara",
        twitter: "https://twitter.com/nalaamara",
        email: "nala@eduplatform.org"
      }
    },
    {
      name: "Kwame Osei",
      title: "Chief Technology Officer",
      bio: "Former Lead Engineer at Google with expertise in scalable systems and AI. Passionate about leveraging technology to solve Africa's educational challenges.",
      image: "/images/team/kwame-osei.jpg",
      social: {
        linkedin: "https://linkedin.com/in/kwame-osei",
        twitter: "https://twitter.com/kwameosei",
        email: "kwame@eduplatform.org"
      }
    },
    {
      name: "Dr. Fatima Nkosi",
      title: "Chief Academic Officer",
      bio: "Educational expert with background in curriculum development across multiple African education systems. Ph.D. in Curriculum Studies from University of Cape Town.",
      image: "/images/team/fatima-nkosi.jpg",
      social: {
        linkedin: "https://linkedin.com/in/fatima-nkosi",
        twitter: "https://twitter.com/fatimankosi",
        email: "fatima@eduplatform.org"
      }
    },
    {
      name: "Gabriel Mensah",
      title: "Chief Operating Officer",
      bio: "Operations leader with experience scaling non-profits across Sub-Saharan Africa. MBA from INSEAD with focus on social entrepreneurship.",
      image: "/images/team/gabriel-mensah.jpg",
      social: {
        linkedin: "https://linkedin.com/in/gabriel-mensah",
        twitter: "https://twitter.com/gabrielmensah",
        email: "gabriel@eduplatform.org"
      }
    }
  ]

  const coreTeam = [
    {
      name: "Zainab Omar",
      title: "Content Director",
      bio: "Educational content specialist with experience in K-12 curriculum development across multiple African countries.",
      image: "/images/team/zainab-omar.jpg"
    },
    {
      name: "Thabo Nkosi",
      title: "Engineering Lead",
      bio: "Full-stack developer with expertise in building offline-first educational applications for low-bandwidth environments.",
      image: "/images/team/thabo-nkosi.jpg"
    },
    {
      name: "Amina Diallo",
      title: "Partnership Manager",
      bio: "Relationship builder who has established partnerships with over 50 educational institutions across Africa.",
      image: "/images/team/amina-diallo.jpg"
    },
    {
      name: "David Chukwu",
      title: "User Experience Lead",
      bio: "Designer focused on creating intuitive interfaces for users with varying levels of digital literacy.",
      image: "/images/team/david-chukwu.jpg"
    },
    {
      name: "Sophia Abebe",
      title: "Community Manager",
      bio: "Community building expert who oversees our network of volunteer educators and learning communities.",
      image: "/images/team/sophia-abebe.jpg"
    },
    {
      name: "Omar Hassan",
      title: "Data Analytics Lead",
      bio: "Data scientist working to measure educational outcomes and optimize learning pathways for students.",
      image: "/images/team/omar-hassan.jpg"
    },
    {
      name: "Ngozi Adeyemi",
      title: "Accessibility Specialist",
      bio: "Advocate for inclusive design who ensures our platform serves learners of all abilities.",
      image: "/images/team/ngozi-adeyemi.jpg"
    },
    {
      name: "Tendai Moyo",
      title: "Learning Science Researcher",
      bio: "Cognitive scientist researching effective teaching methods for diverse learning contexts.",
      image: "/images/team/tendai-moyo.jpg"
    }
  ]

  const advisors = [
    {
      name: "Prof. Kofi Annan",
      title: "Education Policy Advisor",
      organization: "University of Ghana",
      bio: "Former Education Minister with expertise in education policy reform across West Africa.",
      image: "/images/team/kofi-annan.jpg"
    },
    {
      name: "Dr. Amara Conteh",
      title: "Technology Advisor",
      organization: "MIT Media Lab",
      bio: "Researcher focused on technology innovations for emerging markets and educational contexts.",
      image: "/images/team/amara-conteh.jpg"
    },
    {
      name: "Sarah Kimani",
      title: "NGO Partnerships Advisor",
      organization: "African Education Consortium",
      bio: "Leader in coordinating educational initiatives between governments, NGOs, and private sector.",
      image: "/images/team/sarah-kimani.jpg"
    },
    {
      name: "Dr. Malik Ibrahim",
      title: "Curriculum Design Advisor",
      organization: "International Education Council",
      bio: "Expert in designing competency-based curricula that bridge local and global educational needs.",
      image: "/images/team/malik-ibrahim.jpg"
    }
  ]

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-blue-600 dark:bg-blue-900">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-90 dark:from-blue-900 dark:to-blue-950" />
        <div className="container relative z-10 mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="mb-4 text-3xl font-bold text-white sm:text-4xl md:text-5xl">Our Team</h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
              Meet the passionate individuals dedicated to transforming education across Africa. 
              Our diverse team brings together expertise in education, technology, design, and community building.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <Tabs defaultValue="leadership" className="mb-12">
          <TabsList className="mx-auto mb-8 w-full max-w-md">
            <TabsTrigger value="leadership" className="flex-1">Leadership</TabsTrigger>
            <TabsTrigger value="team" className="flex-1">Core Team</TabsTrigger>
            <TabsTrigger value="advisors" className="flex-1">Advisors</TabsTrigger>
          </TabsList>
          
          <TabsContent value="leadership">
            <div className="mb-12 text-center">
              <h2 className="mb-4 text-3xl font-bold">Our Leadership</h2>
              <p className="mx-auto max-w-3xl text-gray-600 dark:text-gray-400">
                Our leadership team brings decades of combined experience in education, technology, and social impact. 
                They're united by a shared vision of democratizing access to quality education across Africa.
              </p>
            </div>
            
            <motion.div 
              variants={container}
              initial="hidden"
              animate="show"
              className="grid gap-8 md:grid-cols-2 lg:grid-cols-4"
            >
              {leadershipTeam.map((member, index) => (
                <motion.div key={index} variants={item}>
                  <Card className="h-full overflow-hidden">
                    <div className="aspect-square relative">
                      <Image 
                        src={member.image}
                        alt={member.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <CardContent className="p-6">
                      <h3 className="mb-1 text-xl font-bold">{member.name}</h3>
                      <p className="mb-3 text-blue-600 dark:text-blue-400">{member.title}</p>
                      <p className="mb-4 text-gray-600 dark:text-gray-400">{member.bio}</p>
                      <div className="flex space-x-3">
                        {member.social.linkedin && (
                          <a href={member.social.linkedin} target="_blank" rel="noreferrer" className="text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                            <Linkedin className="h-5 w-5" />
                          </a>
                        )}
                        {member.social.twitter && (
                          <a href={member.social.twitter} target="_blank" rel="noreferrer" className="text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                            <Twitter className="h-5 w-5" />
                          </a>
                        )}
                        {member.social.email && (
                          <a href={`mailto:${member.social.email}`} className="text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-400">
                            <Mail className="h-5 w-5" />
                          </a>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="team">
            <div className="mb-12 text-center">
              <h2 className="mb-4 text-3xl font-bold">Core Team</h2>
              <p className="mx-auto max-w-3xl text-gray-600 dark:text-gray-400">
                Our dedicated team members work every day to build, improve, and grow our platform. 
                With diverse skills and backgrounds, they're the heart of our organization.
              </p>
            </div>
            
            <motion.div 
              variants={container}
              initial="hidden"
              animate="show"
              className="grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4"
            >
              {coreTeam.map((member, index) => (
                <motion.div key={index} variants={item}>
                  <Card className="h-full">
                    <div className="aspect-square relative">
                      <Image 
                        src={member.image}
                        alt={member.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <CardContent className="p-4">
                      <h3 className="mb-1 text-lg font-bold">{member.name}</h3>
                      <p className="mb-2 text-blue-600 dark:text-blue-400">{member.title}</p>
                      <p className="text-gray-600 dark:text-gray-400">{member.bio}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
            
            <div className="mt-16 rounded-lg bg-blue-50 p-8 dark:bg-blue-900/30">
              <div className="text-center">
                <h3 className="mb-4 text-2xl font-bold">Join Our Team</h3>
                <p className="mx-auto mb-6 max-w-2xl text-gray-600 dark:text-gray-400">
                  We're always looking for passionate individuals to join our mission. 
                  If you're excited about transforming education in Africa, we'd love to hear from you.
                </p>
                <Link href="/careers">
                  <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800">
                    View Open Positions <MoveRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="advisors">
            <div className="mb-12 text-center">
              <h2 className="mb-4 text-3xl font-bold">Our Advisors</h2>
              <p className="mx-auto max-w-3xl text-gray-600 dark:text-gray-400">
                Our advisory board consists of experts in education, technology, policy, and social impact. 
                They provide strategic guidance and help us navigate complex challenges.
              </p>
            </div>
            
            <motion.div 
              variants={container}
              initial="hidden"
              animate="show"
              className="grid gap-8 md:grid-cols-2 lg:grid-cols-4"
            >
              {advisors.map((advisor, index) => (
                <motion.div key={index} variants={item}>
                  <Card className="h-full">
                    <div className="aspect-square relative">
                      <Image 
                        src={advisor.image}
                        alt={advisor.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <CardContent className="p-6">
                      <h3 className="mb-1 text-lg font-bold">{advisor.name}</h3>
                      <p className="mb-1 text-blue-600 dark:text-blue-400">{advisor.title}</p>
                      <p className="mb-3 text-sm text-gray-500 dark:text-gray-400">{advisor.organization}</p>
                      <p className="text-gray-600 dark:text-gray-400">{advisor.bio}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
        
        {/* Values Section */}
        <div className="mb-12 mt-16">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold">Our Team Values</h2>
            <p className="mx-auto max-w-3xl text-gray-600 dark:text-gray-400">
              These core principles guide how we work together and approach our mission.
            </p>
          </div>
          
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <div className="rounded-lg bg-white p-6 shadow-sm dark:bg-gray-800">
              <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400">
                <Globe className="h-6 w-6" />
              </div>
              <h3 className="mb-2 text-xl font-bold">Diversity & Inclusion</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We believe that diverse perspectives lead to better solutions. We celebrate our differences 
                and ensure that our team reflects the communities we serve.
              </p>
            </div>
            
            <div className="rounded-lg bg-white p-6 shadow-sm dark:bg-gray-800">
              <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400">
                <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M21 10H3M16 2V6M8 2V6M10.5 14L12 13V17.5M15.5 17C15.5 17.5523 15.0523 18 14.5 18C13.9477 18 13.5 17.5523 13.5 17C13.5 16.4477 13.9477 16 14.5 16C15.0523 16 15.5 16.4477 15.5 17ZM7 22H17C19.2091 22 21 20.2091 21 18V8C21 5.79086 19.2091 4 17 4H7C4.79086 4 3 5.79086 3 8V18C3 20.2091 4.79086 22 7 22Z" 
                    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="mb-2 text-xl font-bold">Continuous Learning</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We practice what we preach by continuously learning and growing. We embrace challenges as 
                opportunities to develop new skills and perspectives.
              </p>
            </div>
            
            <div className="rounded-lg bg-white p-6 shadow-sm dark:bg-gray-800">
              <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400">
                <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M22 11.0857V12.0057C21.9988 14.1621 21.3005 16.2604 20.0093 17.9875C18.7182 19.7147 16.9033 20.9782 14.8354 21.5896C12.7674 22.201 10.5573 22.1276 8.53447 21.3803C6.51168 20.633 4.78465 19.2518 3.61096 17.4428C2.43727 15.6338 1.87979 13.4938 2.02168 11.342C2.16356 9.19029 2.99721 7.14205 4.39828 5.5028C5.79935 3.86354 7.69279 2.72111 9.79619 2.24587C11.8996 1.77063 14.1003 1.98806 16.07 2.86572M22 4L12 14.01L9 11.01" 
                    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="mb-2 text-xl font-bold">Impact-Driven</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We measure our success by the positive impact we create in learners' lives. We're committed 
                to outcomes, not just outputs.
              </p>
            </div>
            
            <div className="rounded-lg bg-white p-6 shadow-sm dark:bg-gray-800">
              <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400">
                <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M15 10L11 14L9 12M12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12C21 16.9706 16.9706 21 12 21Z" 
                    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="mb-2 text-xl font-bold">Transparency</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We believe in open communication and sharing our successes and challenges. We're honest about 
                our progress and where we need to improve.
              </p>
            </div>
            
            <div className="rounded-lg bg-white p-6 shadow-sm dark:bg-gray-800">
              <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400">
                <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M17 21V19C17 17.9391 16.5786 16.9217 15.8284 16.1716C15.0783 15.4214 14.0609 15 13 15H5C3.93913 15 2.92172 15.4214 2.17157 16.1716C1.42143 16.9217 1 17.9391 1 19V21M23 21V19C22.9993 18.1137 22.7044 17.2528 22.1614 16.5523C21.6184 15.8519 20.8581 15.3516 20 15.13M16 3.13C16.8604 3.3503 17.623 3.8507 18.1676 4.55231C18.7122 5.25392 19.0078 6.11683 19.0078 7.005C19.0078 7.89317 18.7122 8.75608 18.1676 9.45769C17.623 10.1593 16.8604 10.6597 16 10.88M13 7C13 9.20914 11.2091 11 9 11C6.79086 11 5 9.20914 5 7C5 4.79086 6.79086 3 9 3C11.2091 3 13 4.79086 13 7Z" 
                    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="mb-2 text-xl font-bold">Collaboration</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We achieve more together than alone. We work closely with our partners, communities, and 
                each other to create better educational solutions.
              </p>
            </div>
            
            <div className="rounded-lg bg-white p-6 shadow-sm dark:bg-gray-800">
              <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-400">
                <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 3H5C3.89543 3 3 3.89543 3 5V9M9 21H5C3.89543 21 3 20.1046 3 19V15M21 9V5C21 3.89543 20.1046 3 19 3H15M21 15V19C21 20.1046 20.1046 21 19 21H15M12 12H12.01M8 12H8.01M16 12H16.01" 
                    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="mb-2 text-xl font-bold">Innovation</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We embrace creativity and new approaches to solve difficult problems. We're not afraid to 
                challenge conventional wisdom when it doesn't serve our mission.
              </p>
            </div>
          </div>
        </div>
        
        {/* CTA Section */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 p-8 rounded-xl text-white dark:from-blue-800 dark:to-blue-900">
          <div className="text-center">
            <h3 className="mb-4 text-2xl font-bold">Join Us in Our Mission</h3>
            <p className="mx-auto mb-6 max-w-3xl">
              Whether as a team member, partner, volunteer, or supporter, there are many ways to contribute to our mission of 
              democratizing education across Africa. Together, we can make quality education accessible to millions.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/careers">
                <Button className="bg-white text-blue-700 hover:bg-blue-50">
                  Join Our Team
                </Button>
              </Link>
              <Link href="/volunteer">
                <Button className="bg-transparent border border-white hover:bg-white/10">
                  Volunteer With Us
                </Button>
              </Link>
              <Link href="/partners">
                <Button className="bg-transparent border border-white hover:bg-white/10">
                  Partner With Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
} 